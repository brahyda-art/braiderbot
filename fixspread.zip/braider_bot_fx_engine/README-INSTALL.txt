BRAIDER BOT FX — complete current file set (re-verified)
============================================================
All 287 automated tests pass against this exact set of files, run just
now before packaging. Copy each file below over the same path inside your
engine folder (braider_bot_fx_engine) on the VPS.

    engine/app/config.py                      -> app/config.py
    engine/app/engine.py                      -> app/engine.py
    engine/app/risk/position_sizing.py        -> app/risk/position_sizing.py
    engine/app/risk/risk_engine.py            -> app/risk/risk_engine.py
    engine/app/strategy/confluence.py         -> app/strategy/confluence.py
    engine/app/strategy/scalp_smc.py          -> app/strategy/scalp_smc.py   (this is the
                                                  file that was missing and caused your
                                                  ModuleNotFoundError)
    engine/app/services/firebase_sync.py      -> app/services/firebase_sync.py
    engine/app/journal/journal.py             -> app/journal/journal.py
    engine/tests/test_position_sizing.py      -> tests/test_position_sizing.py
    engine/tests/test_confluence.py           -> tests/test_confluence.py
    engine/tests/test_scalp_smc.py            -> tests/test_scalp_smc.py
    engine/tests/test_web_config_contract.py  -> tests/test_web_config_contract.py
    engine/tests/test_automation_limits.py    -> tests/test_automation_limits.py
    engine/tests/test_firebase_sink.py        -> tests/test_firebase_sink.py

    website/BRAIDER-BOT-FX-MULTI-ACCOUNT-FIXED.html  -> deploy to Netlify

VERIFY ON THE VPS AFTER COPYING:
    cd braider_bot_fx_engine
    python -m pytest -q
Expect: 287 passed. If anything errors on import, a file above wasn't
copied to the exact path shown — check the filename and folder.

Then restart:
    python -m app.main

Watch the startup log for "Firebase connected" and, after your next
Settings save, "web config applied".


WHAT'S IN THIS SET (all previously delivered in this conversation)
----------------------------------------------------------------------
- Settings save reliably to Firebase and survive a page refresh
- Engine stays running and keeps scanning/signalling until you press
  Stop or Emergency Stop — daily/weekly loss and trade-count limits only
  pause new trades, they don't stop the bot
- Force Trade button to override those limits on purpose
- Lot-size calculator floors at 0.01 no matter what the broker reports,
  while still letting you set your own fixed or per-pair lot size
- Start/Stop status on the website now waits realistically for the
  engine to confirm instead of falsely reporting failure
- Email "I've verified" button retries a few times to handle Firebase's
  verification propagation delay
- New SMC-pullback Scalping mode as a fully separate strategy from the
  swing concepts (Supply & Demand, Support & Resistance, Fair Value
  Gaps, Liquidity sweeps), each individually enable/disable-able
- Firestore security rules reminder: Force Trade, config saves, and
  Start/Stop/Emergency all require the rules update sent earlier in
  this conversation. If you're not sure it's applied, ask me to resend it.
