"""Backtesting metrics (spec section 24).

Reports risk-quality metrics, not just profit: expectancy, profit factor,
max drawdown, consecutive losses, average R.  A strategy is NOT considered
viable on profit alone - the report flags destructive profiles.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List


@dataclass
class BacktestMetrics:
    trades: int = 0
    wins: int = 0
    losses: int = 0
    win_rate: float = 0.0
    avg_win: float = 0.0
    avg_loss: float = 0.0
    expectancy: float = 0.0          # per trade, account currency
    profit_factor: float = 0.0
    total_return: float = 0.0
    total_return_pct: float = 0.0
    max_drawdown_pct: float = 0.0
    max_consecutive_losses: int = 0
    avg_r: float = 0.0
    rejected_setups: int = 0
    notes: List[str] = field(default_factory=list)

    def summary(self) -> str:
        lines = [
            f"trades={self.trades} (wins={self.wins}, losses={self.losses})",
            f"win_rate={self.win_rate:.1f}%  avg_win={self.avg_win:.2f}  avg_loss={self.avg_loss:.2f}",
            f"expectancy={self.expectancy:.2f}  profit_factor={self.profit_factor:.2f}",
            f"return={self.total_return:.2f} ({self.total_return_pct:.2f}%)  "
            f"maxDD={self.max_drawdown_pct:.2f}%",
            f"max_consec_losses={self.max_consecutive_losses}  avg_r={self.avg_r:.2f}",
            f"rejected_setups={self.rejected_setups}",
        ]
        return "\n".join(["  " + l for l in lines])


def compute_metrics(closed_trades: List[dict], start_balance: float,
                    end_equity_curve: List[float] | None = None,
                    rejected: int = 0) -> BacktestMetrics:
    m = BacktestMetrics(rejected_setups=rejected)
    if not closed_trades:
        m.notes.append("no trades - check thresholds (engine may be correct to stay out)")
        return m
    m.trades = len(closed_trades)
    profits = [float(t.get("profit", 0)) for t in closed_trades]
    rs = [float(t["r"]) for t in closed_trades if t.get("r") is not None]
    wins = [p for p in profits if p > 0]
    losses = [p for p in profits if p <= 0]
    m.wins, m.losses = len(wins), len(losses)
    m.win_rate = 100.0 * len(wins) / m.trades if m.trades else 0.0
    m.avg_win = sum(wins) / len(wins) if wins else 0.0
    m.avg_loss = sum(losses) / len(losses) if losses else 0.0
    m.expectancy = sum(profits) / m.trades
    gross_loss = abs(sum(losses))
    m.profit_factor = (sum(wins) / gross_loss) if gross_loss > 0 else float("inf")
    m.total_return = sum(profits)
    m.total_return_pct = 100.0 * m.total_return / start_balance if start_balance else 0.0
    m.avg_r = sum(rs) / len(rs) if rs else 0.0

    # max drawdown from the equity curve (or synthesized from trade sequence)
    curve = end_equity_curve or _synth_curve(start_balance, profits)
    peak = curve[0] if curve else start_balance
    max_dd = 0.0
    for v in curve:
        peak = max(peak, v)
        if peak > 0:
            max_dd = max(max_dd, (peak - v) / peak * 100.0)
    m.max_drawdown_pct = max_dd

    streak = worst = 0
    for p in profits:
        if p <= 0:
            streak += 1
            worst = max(worst, streak)
        else:
            streak = 0
    m.max_consecutive_losses = worst

    # Risk-quality notes (never optimize for profit alone)
    if m.profit_factor < 1.0:
        m.notes.append("profit factor < 1.0: strategy loses money as configured")
    if m.max_drawdown_pct > 20:
        m.notes.append("max drawdown > 20%: risk settings too aggressive")
    if m.max_consecutive_losses >= 6:
        m.notes.append("long losing streaks: reduce size or raise confluence threshold")
    if m.trades < 30:
        m.notes.append("fewer than 30 trades: sample too small to trust (avoid curve fitting)")
    return m


def _synth_curve(start: float, profits: List[float]) -> List[float]:
    curve = [start]
    for p in profits:
        curve.append(curve[-1] + p)
    return curve
