"""Historical backtester for the BRAIDER BOT FX strategy engine.

Design (spec section 24):
* Replays OHLC bars from CSV (data/<SYMBOL>_<TF>.csv) bar by bar.
* Uses the SAME analysis + confluence modules as the live engine.
* Simulates: confirmation entries on bar close, limit-order pullback fills,
  SL/TP, spread & slippage costs, risk-based sizing, daily-loss limits.
* Walk-forward split: data is divided into TRAIN and VALIDATION segments;
  metrics are reported for each segment separately to expose curve fitting.

The backtester is an approximation of live conditions (bar-close
confirmation, no intrabar path except SL/TP priority rules).  Treat results
as a coarse filter, not proof of profitability.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

from app.constants import Direction
from app.liquidity.sweeps import detect_sweeps
from app.market.candles import Candle, atr
from app.market.data_feed import CsvFeed
from app.strategy.confluence import AnalysisBundle, build_setups
from app.strategy.fvg import analyze_fvgs
from app.strategy.htf_context import build_htf_context
from app.strategy.levels import analyze_sr
from app.strategy.structure import analyze_structure
from app.strategy.swings import find_swings
from app.strategy.trendlines import analyze_trendlines
from app.zones.detector import analyze_zones
from .metrics import BacktestMetrics, compute_metrics


@dataclass
class BTPosition:
    symbol: str
    direction: Direction
    lots: float
    entry: float
    sl: float
    tp: float
    risk_amount: float
    opened_index: int
    opened_time: int
    setup_id: str
    thesis: Dict = field(default_factory=dict)


@dataclass
class BTConfig:
    start_balance: float = 10000.0
    risk_pct: float = 1.0
    spread_points: float = 15.0
    slippage_points: float = 5.0
    point: float = 0.00001
    tick_value_per_unit: float = 1.0    # account currency per 1.0 price unit per lot
    max_trades_per_day: int = 6
    max_daily_loss_pct: float = 3.0
    min_rr: float = 1.5
    train_fraction: float = 0.7          # walk-forward split


class Backtester:
    """Replay one symbol's entry timeframe with the live confluence engine."""

    def __init__(self, cfg, symbol: str, data_dir: str = "data",
                 bt_cfg: Optional[BTConfig] = None):
        self.cfg = cfg
        self.symbol = symbol
        self.bt = bt_cfg or BTConfig()
        self.feed = CsvFeed(data_dir)

    # ------------------------------------------------------------------
    def run(self) -> Dict[str, BacktestMetrics]:
        st = self.cfg.effective_strategy(self.symbol)
        entry_tf = st.entry_timeframe
        print(f"[backtester] symbol={self.symbol} entry_timeframe={entry_tf} "
              f"confirmation_timeframe={st.confirmation_timeframe} "
              f"htf_bias_timeframes={st.htf_bias_timeframes}")
        candles = self.feed.get_rates(self.symbol, entry_tf, 0)
        if len(candles) < 400:
            raise SystemExit(
                f"not enough data for {self.symbol} {entry_tf}: {len(candles)} bars. "
                f"Export history from MT5 into data/{self.symbol}_{entry_tf}.csv "
                "(or generate synthetic data with scripts/generate_demo_data.py).")

        split = int(len(candles) * self.bt.train_fraction)
        segments = {"TRAIN": candles[:split], "VALIDATION": candles[split:]}
        out: Dict[str, BacktestMetrics] = {}
        rejected_total = 0
        for name, seg in segments.items():
            metrics, rejected = self._run_segment(seg, entry_tf)
            out[name] = metrics
            rejected_total += rejected
        return out

    # ------------------------------------------------------------------
    def _run_segment(self, candles: List[Candle], tf: str):
        cfg = self.cfg
        st = cfg.effective_strategy(self.symbol)
        balance = self.bt.start_balance
        equity_curve = [balance]
        open_pos: List[BTPosition] = []
        closed: List[dict] = []
        rejected = 0
        day = None
        day_trades = 0
        day_start_balance = balance

        # Analysis is recomputed on a rolling window (like the live engine).
        window = 400
        warmup = 200
        if len(candles) <= warmup + 1:
            print(f"[backtester] segment too short ({len(candles)} bars) for "
                  f"warmup={warmup} - skipping, this is NOT a real 0-trade result. "
                  f"Download more history (scripts/download_mt5_data.py) or lower "
                  f"train_fraction so validation gets more bars.")
            return compute_metrics([], self.bt.start_balance,
                                   [self.bt.start_balance], 0), 0
        i = warmup
        while i < len(candles) - 1:
            c = candles[i]
            this_day = candles[i].time // 86400
            if this_day != day:
                day = this_day
                day_trades = 0
                day_start_balance = balance

            # ---- manage open positions on this bar (SL first, then TP) ----
            still_open = []
            for pos in open_pos:
                exit_px, reason = None, None
                if pos.direction is Direction.LONG:
                    if c.low <= pos.sl:
                        exit_px, reason = pos.sl, "stop_loss"
                    elif c.high >= pos.tp:
                        exit_px, reason = pos.tp, "take_profit"
                else:
                    if c.high >= pos.sl:
                        exit_px, reason = pos.sl, "stop_loss"
                    elif c.low <= pos.tp:
                        exit_px, reason = pos.tp, "take_profit"
                if exit_px is None:
                    still_open.append(pos)
                    continue
                move = (exit_px - pos.entry) if pos.direction is Direction.LONG \
                    else (pos.entry - exit_px)
                profit = move * self.bt.tick_value_per_unit * pos.lots
                balance += profit
                risk = abs(pos.entry - pos.sl) * self.bt.tick_value_per_unit * pos.lots
                closed.append({"profit": profit, "r": profit / risk if risk else 0,
                               "reason": reason, "time": c.time})
            open_pos = still_open
            equity_curve.append(balance + self._floating(open_pos, c.close))

            # ---- daily risk limits ---------------------------------------
            if day_trades >= self.bt.max_trades_per_day or \
                    (balance - day_start_balance) / day_start_balance * 100 <= \
                    -self.bt.max_daily_loss_pct:
                i += 1
                continue

            # ---- analyze the window ending at i (inclusive) -----------------
            window_candles = candles[max(0, i - window + 1):i + 1]
            setups = self._analyze_window(window_candles, tf)
            executed_this_bar = False
            for setup in setups:
                if setup.gates_failed:
                    rejected += 1
                    continue
                if setup.score < st.min_confluence_score or \
                        setup.sl <= 0 or setup.tp <= 0:
                    rejected += 1
                    continue
                rr = abs(setup.tp - setup.entry) / max(1e-12, abs(setup.entry - setup.sl))
                if rr < self.bt.min_rr:
                    rejected += 1
                    continue
                if executed_this_bar:
                    continue
                # costs
                spread = self.bt.spread_points * self.bt.point
                slip = self.bt.slippage_points * self.bt.point
                if setup.direction is Direction.LONG:
                    entry = c.close + spread + slip
                else:
                    entry = c.close - slip
                risk_dist = abs(entry - setup.sl)
                if risk_dist <= 0:
                    rejected += 1
                    continue
                risk_amount = balance * self.bt.risk_pct / 100.0
                lots = risk_amount / (risk_dist * self.bt.tick_value_per_unit)
                if lots <= 0:
                    continue
                # risk-adjust TP so RR is preserved after entry costs
                tp = entry + (setup.tp - setup.entry) if setup.direction is Direction.LONG \
                    else entry + (setup.tp - setup.entry)
                open_pos.append(BTPosition(
                    self.symbol, setup.direction, lots, entry, setup.sl, tp,
                    risk_amount, i, c.time, setup.id, setup.thesis))
                day_trades += 1
                executed_this_bar = True
            i += 1

        # close remaining at the end (honest accounting)
        last = candles[-1]
        for pos in open_pos:
            move = (last.close - pos.entry) if pos.direction is Direction.LONG \
                else (pos.entry - last.close)
            balance += move * self.bt.tick_value_per_unit * pos.lots
            risk = abs(pos.entry - pos.sl) * self.bt.tick_value_per_unit * pos.lots
            closed.append({"profit": move * self.bt.tick_value_per_unit * pos.lots,
                           "r": (move * self.bt.tick_value_per_unit * pos.lots) / risk
                           if risk else 0, "reason": "end_of_backtest", "time": last.time})
        return compute_metrics(closed, self.bt.start_balance,
                               equity_curve, rejected), rejected

    # ------------------------------------------------------------------
    def _analyze_window(self, candles: List[Candle], tf: str):
        st = self.cfg.effective_strategy(self.symbol)
        swings = find_swings(candles, st.swing_strength)
        structure = analyze_structure(candles, st.swing_strength, st.atr_period)
        zones = analyze_zones(candles, tf, st)
        sr = analyze_sr(candles, swings, (), st.atr_period, 0.35, 2)
        sweeps = detect_sweeps(candles, swings, tf, st.sweep_min_penetration_atr,
                               atr_period=st.atr_period)
        trendlines = analyze_trendlines(candles, swings, st.atr_period, 3)
        # HTF context: resample the same window (backtest approximation).
        from app.market.data_feed import resample
        htf_data = {}
        for tfh in st.htf_bias_timeframes:
            try:
                htf_data[tfh] = resample(candles, tf, tfh)
            except ValueError:
                htf_data[tfh] = candles
        htf = build_htf_context(htf_data, st.htf_bias_timeframes,
                                st.swing_strength, st.atr_period)
        entry_atr = atr(candles, st.atr_period)
        fvgs = analyze_fvgs(candles, entry_atr, st)
        bundle = AnalysisBundle(
            symbol=self.symbol, entry_tf=tf, entry_candles=candles,
            htf_bias=htf.bias, zones=zones, sr=sr, entry_structure=structure,
            sweeps=sweeps, trendlines=trendlines, fvgs=fvgs.gaps,
            atr=entry_atr, point_size=self.bt.point,
        )
        return build_setups(bundle, self.cfg)

    def _floating(self, open_pos, price):
        total = 0.0
        for pos in open_pos:
            move = (price - pos.entry) if pos.direction is Direction.LONG \
                else (pos.entry - price)
            total += move * self.bt.tick_value_per_unit * pos.lots
        return total
