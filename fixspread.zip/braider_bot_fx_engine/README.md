# BRAIDER BOT FX — Trading Engine

**BRAIDERTECH · Mbale, Uganda**
The backend/trading-engine for the existing BRAIDER BOT FX website. This repo
contains **no frontend** — it is the brain + execution layer that your website
controls.

```
┌─────────────────────────────┐         ┌──────────────────────────────────┐
│  YOUR WEBSITE (exists)      │         │  LINUX VPS                        │
│  Firebase Auth + Firestore  │◄───────►│  braider-engine (this repo)       │
│  users/{uid}, commands,     │ Firebase│  · strategy/confluence engine     │
│  trades, logs, RTDB live/   │  admin  │  · risk engine + journal          │
└─────────────────────────────┘  SDK    │  · REST API (token auth)          │
                                        └───────────────┬──────────────────┘
                                                        │ HTTPS + Bearer token
                                        ┌───────────────▼──────────────────┐
                                        │  WINDOWS VPS (MT5 terminal)      │
                                        │  mt5_bridge/bridge.py            │
                                        │  → real MetaTrader 5 execution   │
                                        └──────────────────────────────────┘
```

## Why two machines?

The official `MetaTrader5` Python package **only runs on Windows**, attached
to a logged-in MT5 terminal. A Linux VPS cannot execute MT5 trades directly.
The strategy/risk engine therefore runs on your Linux VPS and sends orders to
a small authenticated bridge running on a Windows VPS next to the MT5
terminal. Both components are in this repo.

- Linux ARM (e.g. Oracle Ampere) **can** run the engine + API + Firebase sync.
- MT5 execution **requires** Windows x86/x64 (any cheap Windows VPS with 2 GB
  RAM is enough for terminal + bridge).

## Safety model (read this first)

| Rule | Where enforced |
|---|---|
| Default mode is **PAPER** (local simulator, no orders leave the machine) | `config.yaml execution.mode` |
| **LIVE** requires `execution.mode: live` **AND** `LIVE_TRADING_ENABLED=true` | `app/main.py` |
| Every order **must** have a structurally valid stop loss | confluence gate + pipeline + bridge (3 layers) |
| Risk engine runs before every order and re-verifies exposure after | `app/risk/risk_engine.py` |
| Duplicate orders suppressed by idempotency + similar-pending guard | `app/execution/executor.py` |
| Emergency stop cancels pendings and closes positions (configurable) | `app/engine.py` |
| Unknown positions found after a restart are adopted and journaled | `app/engine.py _reconcile` |
| Uncertainty ⇒ **do not trade** | every module fails closed |

## Project tree

```
braider_bot_fx_engine/
├── app/
│   ├── main.py                 entrypoint + safety gates
│   ├── config.py               YAML + env config, website-config merge
│   ├── logging_config.py       engine/trade/risk/security log files
│   ├── state_store.py          SQLite: trades, setups, orders, daily stats, idempotency
│   ├── constants.py            enums (states, zones, exit reasons…)
│   ├── engine.py               orchestrator loop + state machine + reconciliation
│   ├── market/                 candles, validation, CSV/bridge feeds
│   ├── strategy/               swings, structure (HH/HL/BOS/CHoCH/MSS), S/R,
│   │                           trendlines, HTF bias, pullback, confluence
│   ├── zones/detector.py       supply/demand zones + fresh/tested/respected/invalid lifecycle
│   ├── liquidity/sweeps.py     liquidity sweep detection
│   ├── risk/                   position sizing, SL validation, risk engine
│   ├── entries/pipeline.py     the full trade validation pipeline
│   ├── execution/              broker interface, bridge client, paper broker, executor
│   ├── portfolio/trade_manager.py  early exit, partials, break-even, structure trailing
│   ├── journal/journal.py      every setup & decision recorded (incl. rejections)
│   ├── api/server.py           token-authenticated REST API
│   └── services/firebase_sync.py   syncs with your existing website (Firestore + RTDB)
├── mt5_bridge/bridge.py        Windows MT5 REST bridge (run next to MT5 terminal)
├── backtest/                   historical tester + honest metrics (train/validation)
├── tests/                      124 automated tests
├── scripts/                    demo-data generator, bridge checker, backtest runner
├── config/config.yaml          ALL strategy/risk settings (no code edits needed)
├── deploy/                     systemd unit, VPS guide, firewall script
├── .env.example                secrets template (never commit .env)
├── Dockerfile / docker-compose.yml
└── requirements.txt
```

## Quick start (paper mode — safe, no broker needed)

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env                  # defaults are fine for paper

# synthetic data to exercise the pipeline (NOT for profit judging!)
python scripts/generate_demo_data.py --symbol EURUSD

python -m app.main                    # engine + API on :8000, paper mode
pytest tests/                         # 124 tests
```

The engine loop will scan, journal every decision (including why it did NOT
trade), simulate fills honestly, and expose status on the API.

## Connecting to your existing website (Firebase)

1. Firebase console → Project settings → **Service accounts** → Generate new
   private key → save as `firebase-service-account.json` on the VPS (never in
   the repo, never in the browser).
2. In `.env` set:
   ```
   FIREBASE_CREDENTIALS_PATH=/opt/braider/firebase-service-account.json
   FIREBASE_PROJECT_ID=braider-bot
   FIREBASE_USER_UID=<your website account uid>
   ```
3. Restart the engine. It then:
   - watches `users/{uid}/commands` (start / pause / stop / emergency) written
     by your website's **Start / Pause / Stop / Emergency** buttons and marks
     each command `done`/`rejected`,
   - writes trades to `users/{uid}/trades` (fields your site already renders:
     `side, symbol, lots, entry, setup, status, openedAt, closedAt, profit`),
   - writes logs to `users/{uid}/logs` (`{t, action, detail}`),
   - updates `users/{uid}` (bot status, `connected`, masked account) and the
     Realtime DB `live/{uid}` heartbeat for the dashboard header,
   - applies your website's saved config (risk %, limits, symbols, mapping,
     session) through `apply_web_config` — the safe subset only.

**Firestore rules:** the service account bypasses rules, so your existing
rules keep protecting browser access. Never put MT5 or Firebase credentials
in the frontend.

## Going to MT5 DEMO (and later live — only after demo works)

1. Get a **Windows VPS** (2 GB RAM, x64). Install MT5, log in to the **demo**
   account, enable **Algo Trading** (AutoTrading button).
2. On the Windows box:
   ```powershell
   pip install -r mt5_bridge/requirements.txt
   setx BRIDGE_TOKEN "<long random string>"
   python mt5_bridge/bridge.py        # listens on 127.0.0.1:8001
   ```
3. On the Linux VPS `.env`:
   ```
   BBFX_EXECUTION_MODE=demo
   BBFX_BRIDGE_URL=http://<windows-vps-ip>:8001
   BRIDGE_TOKEN=<same long random string>
   ```
   (If you keep the bridge localhost-only, run an SSH tunnel:
   `ssh -L 8001:127.0.0.1:8001 user@windows-vps` or use Tailscale.)
4. Verify: `python scripts/check_bridge.py --url $BBFX_BRIDGE_URL --token $BRIDGE_TOKEN`
5. Set the broker symbol mapping in `config/config.yaml` (e.g. `XAUUSD: XAUUSDm`).

LIVE mode additionally requires `LIVE_TRADING_ENABLED=true` — the engine
refuses to boot in live mode without it, by design. **Do not enable live
before weeks of stable demo operation.**

## Backtesting before demo

1. Export history from MT5 (Tools → Options → Charts → set max bars; then
   use a script/EA to export CSV, or any MT5-to-CSV exporter) into
   `data/EURUSD_M15.csv` etc. (columns: `time,open,high,low,close,volume`,
   time = epoch seconds).
2. `python scripts/run_backtest.py --symbol EURUSD`
3. Read the TRAIN vs VALIDATION reports. If validation is much worse than
   train → you are curve fitting; make thresholds stricter, not looser.
   The engine must NEVER be judged on profit alone: expectancy, drawdown and
   losing-streak behaviour matter more.

## Configuration

Everything lives in `config/config.yaml` (documented inline): symbols &
broker mapping, timeframes, risk limits, sessions, confluence weights & score
threshold, zone/sweep/pullback rules, scalping mode, partial-exit ladder,
break-even, structure trailing, emergency behaviour, API, logging. The
website can override the safe subset live (risk %, limits, symbols, mapping).

## API (for your website / admin tooling)

All reads are open on the LAN; all writes require `X-API-Token: $API_TOKEN`.

```
GET  /health /status /account /positions /orders
GET  /trades?limit= /setups?limit= /logs?limit= /risk/today
GET  /config
POST /command            {action: start|pause|stop|emergency|resume|close_all}
POST /config/sync        (website config payload → safe merge)
```

There is deliberately **no** endpoint that places an arbitrary order — every
trade must pass the full strategy/risk pipeline.

## Operations

- Logs: `logs/engine.log`, `logs/trades.log`, `logs/risk.log`,
  `logs/security.log` (rotating). Secrets are redacted automatically.
- State: `data/braider.db` (SQLite) — back this up. Delete it to start clean.
- Emergency stop: website button → command `emergency` → cancels pendings +
  closes positions (per config), requires explicit `resume` to trade again.
- See `deploy/VPS_SETUP.md` for full VPS installation, systemd, firewall,
  monitoring, backup and update procedures.

## Known limitations (honest list)

- Backtests approximate live conditions (bar-close confirmation; intrabar
  path modelled with SL-first priority). Treat them as a coarse filter.
- Paper mode uses approximate instrument specs; DEMO/LIVE always use live
  broker specs from the bridge.
- Swap/commission are not modelled in paper/backtest P/L.
- News-blackout filtering is a hook, not yet implemented (session/spread
  limits give partial protection).
- The MetaTrader5 package requires the terminal logged in; weekend/market
  closure = no ticks = engine correctly stands down (stale-data guard).
- Firebase sync requires a service account with Firestore + RTDB access.

## Development rules (from the spec, enforced in code)

1. Never claim connectivity/results that were not verified.
2. Never bypass the pipeline (not even via the API).
3. Never store or log credentials.
4. Demo-first: paper → backtest → demo → review → (only then) live.
```
