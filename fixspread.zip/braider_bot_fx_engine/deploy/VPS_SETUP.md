# BRAIDER BOT FX — Windows VPS Deployment Guide

## Recommended setup for your current VPS

The current codebase supports the strategy engine and MT5 bridge running on the **same Windows x64 VPS**. This is the simplest deployment for the setup you currently have:

```text
Windows VPS
├── BRAIDER BOT FX Python engine
├── MT5 Bridge (FastAPI)
├── MetaTrader 5 terminal
└── Exness account
```

The earlier two-machine design is still supported conceptually (Linux engine + Windows MT5 bridge), but it is **not required** for this deployment. On one Windows VPS the engine talks to the bridge through `http://127.0.0.1:8001`.

> **Safety:** start with `BBFX_EXECUTION_MODE=paper` or `demo`. Keep `LIVE_TRADING_ENABLED=false` until demo operation has been thoroughly validated.

## 1. Prerequisites

- Windows Server 2019/2022 x64 or Windows 10/11 x64
- MetaTrader 5 installed and logged into the intended **demo** account
- Algo Trading enabled in MT5
- Python 3.11 or 3.12 x64
- Git (optional)
- The project copied/cloned to a stable directory such as `C:\BraiderBotFX`

## 2. Install dependencies

Open PowerShell in the project directory:

```powershell
cd C:\BraiderBotFX\braider_bot_fx_engine
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m pip install -r mt5_bridge\requirements.txt
```

## 3. Configure `.env`

Copy `.env.example` to `.env` and set at least:

```text
BBFX_EXECUTION_MODE=demo
BBFX_BRIDGE_URL=http://127.0.0.1:8001
BRIDGE_TOKEN=<long-random-secret>
API_TOKEN=<different-long-random-secret>
MT5_LOGIN=<demo-login>
MT5_PASSWORD=<demo-password>
MT5_SERVER=<exact-MT5-server-name>
MT5_TERMINAL_PATH=C:\Program Files\MetaTrader 5\terminal64.exe
FIREBASE_CREDENTIALS_PATH=C:\BraiderBotFX\braider_bot_fx_engine\firebase-service-account.json
FIREBASE_PROJECT_ID=braider-bot
FIREBASE_USER_UID=<firebase-user-uid>
```

If MT5 is already logged in, `MT5_LOGIN`, `MT5_PASSWORD`, and `MT5_SERVER` can be left empty; the bridge will use the attached terminal.

The application now loads `.env` automatically on startup. Do not commit `.env` or the Firebase service-account JSON.

## 4. Configure broker symbols

Exness may use symbol suffixes. Confirm the exact names visible in MT5 and set the mappings in `config/config.yaml`, for example:

```yaml
symbols:
  mapping:
    EURUSD: EURUSDm
    GBPUSD: GBPUSDm
    USDCAD: USDCADm
    XAUUSD: XAUUSDm
    BTCUSD: BTCUSDm
```

Do not copy these suffixes blindly; use the names actually shown by your Exness MT5 account.

## 5. Test the MT5 bridge first

In PowerShell, from the project root:

```powershell
.\.venv\Scripts\python.exe mt5_bridge\bridge.py
```

Leave that window running. In another PowerShell window:

```powershell
$env:BRIDGE_TOKEN = '<same-token-as-.env>'
.\.venv\Scripts\python.exe scripts\check_bridge.py --url http://127.0.0.1:8001 --token $env:BRIDGE_TOKEN
```

The bridge must report MT5 as connected and trading allowed. If it says AutoTrading is disabled, enable Algo Trading in MT5.

## 6. Run the engine in DEMO mode

After the bridge passes:

```powershell
.\.venv\Scripts\python.exe -m app.main
```

The engine should perform its bridge health check, connect to MT5 through the local bridge, start its API, and begin its normal engine loop.

## 7. One-command startup

Use the supplied scripts:

```powershell
.\scripts\start_bridge.ps1
.\scripts\start_engine.ps1
```

Or start both from one PowerShell window:

```powershell
.\scripts\start_all_windows.ps1
```

For 24/7 operation, use Windows Task Scheduler to launch `start_all_windows.ps1` at startup under the dedicated VPS user. Keep the MT5 terminal available to that same Windows user/session.

## 8. Health checks

Bridge:

```powershell
$token = (Get-Content .env | Where-Object { $_ -match '^BRIDGE_TOKEN=' }) -replace '^BRIDGE_TOKEN=', ''
.\.venv\Scripts\python.exe scripts\check_bridge.py --url http://127.0.0.1:8001 --token $token
```

Engine API:

```powershell
Invoke-WebRequest http://127.0.0.1:8000/health
```

## 9. Rollout sequence

1. Run the automated tests: `pytest tests/`.
2. Run **paper** mode and inspect logs.
3. Run **demo** mode through the real MT5 terminal.
4. Verify symbols, spread checks, SL placement, position sizing, pending limit orders, trade management, emergency stop, and website synchronization.
5. Only after sustained demo validation consider live mode.

Live mode requires both:

```text
BBFX_EXECUTION_MODE=live
LIVE_TRADING_ENABLED=true
```

The engine intentionally refuses live mode unless both are explicitly enabled.

## 10. Why the original project mentioned Linux

The original architecture separated the strategy engine from MT5 because the official MetaTrader5 Python integration is Windows-specific. That remains a valid architecture if the project later grows to multiple machines. For your current setup, however, the strategy engine itself does not require Linux, so it can run on Windows alongside the bridge.
