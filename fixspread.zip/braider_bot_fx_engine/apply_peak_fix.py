"""Patch app/engine.py so account_peak_equity is re-baselined per account.

Run from the project folder (the one containing app\\engine.py):

    python apply_peak_fix.py

It only replaces the body of Engine._bootstrap_day. Everything else in your
engine.py (including the demo_test_order / close_position edits) is left
exactly as it is. It backs up first and refuses to touch the file if the
block it expects is not there exactly once.
"""
import pathlib
import shutil
import sys

TARGET = pathlib.Path("app") / "engine.py"

OLD = '''            self.store.init_daily(day, acc.balance, acc.equity)
            peak = self.store.kv_get("account_peak_equity")
            if not peak or acc.equity > peak:
                self.store.kv_set("account_peak_equity", acc.equity)
'''

NEW = '''            self.store.init_daily(day, acc.balance, acc.equity)
            # The account peak-to-trough baseline belongs to ONE specific
            # account. It is persisted across restarts, so without this a
            # peak recorded on a different account (e.g. the simulated 10,000
            # paper balance) survives a switch to a real demo account and
            # shows up as a bogus ~99% drawdown that blocks every trade.
            # Re-baseline whenever the account identity changes. The limit
            # itself (max_account_drawdown_pct) is not touched.
            owner = f"{acc.mode}:{acc.login}:{acc.server}"
            peak = self.store.kv_get("account_peak_equity")
            if self.store.kv_get("account_peak_owner") != owner:
                self.store.kv_set("account_peak_owner", owner)
                self.store.kv_set("account_peak_equity", acc.equity)
            elif not peak or acc.equity > peak:
                self.store.kv_set("account_peak_equity", acc.equity)
'''


def main() -> int:
    if not TARGET.exists():
        print(f"ERROR: {TARGET} not found. Run this from the project folder.")
        return 1
    text = TARGET.read_text(encoding="utf-8")
    if "account_peak_owner" in text:
        print("Already patched - nothing to do.")
        return 0
    if text.count(OLD) != 1:
        print(f"ERROR: expected block found {text.count(OLD)} times (need exactly 1).")
        print("Your engine.py differs from what this patch expects. No change made.")
        return 1
    backup = TARGET.with_suffix(".py.bak_peakfix")
    shutil.copy2(TARGET, backup)
    TARGET.write_text(text.replace(OLD, NEW), encoding="utf-8")
    print(f"Patched {TARGET}. Backup saved as {backup}.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
