"""BRAIDER BOT FX - MT5 symbol discovery / diagnostic (spec section 4 follow-up).

Run this ON THE WINDOWS MACHINE that has the MT5 terminal installed, with
MT5 open and logged into the DEMO account:

    cd braider_bot_fx_engine
    python scripts/check_mt5_symbols.py

What it does (READ-ONLY, no orders, no live trading):
    1. Initializes MT5 (using MT5_TERMINAL_PATH from .env if set).
    2. Prints terminal + account info.
    3. For every canonical symbol in config/config.yaml (symbols.watched),
       resolves the exact broker symbol name via live discovery against
       mt5.symbols_get() - it does NOT assume any suffix (not even "m").
    4. Prints bid/ask/spread for each resolved symbol.
    5. Prints ready-to-paste YAML for config/config.yaml symbols.mapping.

It never places an order, never modifies config.yaml itself, and never
prints your MT5 password (it isn't asked for - MT5 must already be open and
logged in).
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from dotenv import load_dotenv  # noqa: E402

load_dotenv()

from app.config import load_config  # noqa: E402
from app.market.symbol_resolution import resolve_symbol_name  # noqa: E402

try:
    import MetaTrader5 as mt5
except ImportError:
    print("ERROR: MetaTrader5 package not installed. Run: pip install MetaTrader5")
    raise SystemExit(2)

COMMON_MT5_PATHS = (
    r"C:\Program Files\MetaTrader 5\terminal64.exe",
    r"C:\Program Files\Exness MetaTrader 5\terminal64.exe",
    r"C:\Program Files (x86)\MetaTrader 5\terminal64.exe",
)


def initialize() -> bool:
    path = os.environ.get("MT5_TERMINAL_PATH", "").strip()
    if path:
        print(f"MT5 terminal path (from MT5_TERMINAL_PATH): {path}")
        ok = mt5.initialize(path=path, timeout=60000)
        print("MT5 initialize result:", ok)
        if not ok:
            print("last_error:", mt5.last_error())
        return ok

    print("MT5_TERMINAL_PATH not set - trying default attach, then common paths.")
    if mt5.initialize(timeout=60000):
        print("MT5 initialize result: True (default attach)")
        return True
    default_err = mt5.last_error()
    print("default attach failed:", default_err)

    for candidate in COMMON_MT5_PATHS:
        if Path(candidate).exists():
            print(f"Trying: {candidate}")
            if mt5.initialize(path=candidate, timeout=60000):
                print("MT5 initialize result: True")
                return True
            print("  failed:", mt5.last_error())

    print("MT5 initialize result: False")
    return False


def main() -> int:
    print("=" * 70)
    print("BRAIDER BOT FX - MT5 SYMBOL DISCOVERY (read-only)")
    print("=" * 70)

    if not initialize():
        print("\nCannot continue without a working MT5 connection.")
        print("Checklist: MT5 terminal open, logged into the demo account,")
        print("MT5_TERMINAL_PATH in .env pointing at the exact terminal64.exe.")
        return 1

    term = mt5.terminal_info()
    print("\nTerminal:", term._asdict() if term else None)

    acc = mt5.account_info()
    if acc is None:
        print("\nACCOUNT: None -", mt5.last_error())
        print("Account verification FAILED - not logged in?")
        mt5.shutdown()
        return 1
    print(f"\nAccount login:  {acc.login}")
    print(f"Account server: {acc.server}")
    print(f"Account balance:{acc.balance}")
    print(f"Trade mode:     {'DEMO' if acc.trade_mode == 0 else acc.trade_mode}")

    cfg = load_config()
    canonical_symbols = cfg.symbols.watched

    all_symbols = mt5.symbols_get() or []
    available_names = [s.name for s in all_symbols]
    print(f"\nTotal symbols visible in this MT5 installation: {len(available_names)}")

    print("\n" + "-" * 70)
    print(f"{'canonical':<10} {'->':<3} {'resolved':<14} {'status':<12} {'bid':<12} {'ask'}")
    print("-" * 70)

    discovered_mapping = {}
    any_failed = False
    for canonical in canonical_symbols:
        configured = cfg.symbols.mapping.get(canonical, canonical)
        # Try the configured mapping first (respects any manual override the
        # user already set), then fall back to live discovery.
        resolved = None
        if mt5.symbol_info(configured) is not None:
            resolved = configured
        else:
            resolved = resolve_symbol_name(canonical, available_names)

        if resolved is None:
            print(f"{canonical:<10} {'->':<3} {'NOT FOUND':<14} {'MISSING':<12}")
            any_failed = True
            continue

        mt5.symbol_select(resolved, True)
        info = mt5.symbol_info(resolved)
        tick = mt5.symbol_info_tick(resolved)

        if info is None or tick is None:
            print(f"{canonical:<10} {'->':<3} {resolved:<14} {'NO TICK':<12}")
            any_failed = True
            continue

        discovered_mapping[canonical] = resolved
        print(f"{canonical:<10} {'->':<3} {resolved:<14} {'AVAILABLE':<12} "
              f"{tick.bid:<12} {tick.ask}")

    print("-" * 70)

    print("\nPaste this into config/config.yaml under symbols.mapping if it")
    print("differs from what's already there:\n")
    print("  mapping:")
    for canonical in canonical_symbols:
        mapped = discovered_mapping.get(canonical, "# NOT FOUND - check manually")
        print(f"    {canonical}: {mapped}")

    mt5.shutdown()

    if any_failed:
        print("\nRESULT: one or more symbols could not be resolved. Do not")
        print("start the engine in demo mode until every watched symbol")
        print("shows AVAILABLE above.")
        return 1

    print("\nRESULT: all watched symbols resolved and have live tick data.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
