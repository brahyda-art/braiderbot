"""BRAIDER BOT FX - validate data/ has enough real candles for paper mode.

Checks every data/<SYMBOL>_<TF>.csv against the CURRENT strategy requirement
(config/config.yaml -> strategy.bars, plus the engine's hard 60-candle
minimum on the entry timeframe from app/engine.py). Does not touch MT5,
does not need the VPS/bridge - safe to run anywhere, including here.

Usage:
    python scripts/validate_data.py
    python scripts/validate_data.py --symbols EURUSD GBPUSD
"""

from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.config import load_config  # noqa: E402

DATA_DIR = Path(__file__).resolve().parent.parent / "data"
DEFAULT_SYMBOLS = ["EURUSD", "GBPUSD", "USDCAD", "XAUUSD", "BTCUSD"]
DEFAULT_TIMEFRAMES = ["M1", "M5", "M15", "M30", "H1", "H4", "D1"]
HARD_MIN_ENTRY_CANDLES = 60  # app/engine.py: len(entry_candles) < 60 -> reject


def count_rows(path: Path) -> int:
    if not path.exists():
        return -1
    with path.open(newline="", encoding="utf-8") as fh:
        return sum(1 for _ in csv.DictReader(fh))


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--symbols", nargs="+", default=DEFAULT_SYMBOLS)
    ap.add_argument("--timeframes", nargs="+", default=DEFAULT_TIMEFRAMES)
    args = ap.parse_args()

    cfg = load_config()
    required = dict(cfg.strategy.bars)

    print(f"{'symbol':<10}{'tf':<6}{'have':>7}{'need':>7}  status")
    print("-" * 45)

    all_ok = True
    for symbol in args.symbols:
        symbol = symbol.upper()
        entry_tf = cfg.effective_strategy(symbol).entry_timeframe
        for tf in args.timeframes:
            tf = tf.upper()
            path = DATA_DIR / f"{symbol}_{tf}.csv"
            have = count_rows(path)
            need = required.get(tf, 0)
            if tf == entry_tf:
                need = max(need, HARD_MIN_ENTRY_CANDLES)

            if have < 0:
                status, ok = "MISSING FILE", False
            elif have < need:
                status, ok = f"SHORT by {need - have}", False
            else:
                status, ok = "ok", True

            all_ok = all_ok and ok
            print(f"{symbol:<10}{tf:<6}{max(have, 0):>7}{need:>7}  {status}")

    print("-" * 45)
    if all_ok:
        print("RESULT: all symbols/timeframes meet the current strategy requirement.")
        return 0
    print("RESULT: one or more symbols/timeframes are missing or short on candles. "
          "Run scripts/download_mt5_data.py on the VPS to fix.")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
