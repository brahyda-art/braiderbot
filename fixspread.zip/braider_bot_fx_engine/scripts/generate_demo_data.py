"""Generate SYNTHETIC OHLC data for offline pipeline testing.

!! This data is FAKE (random walk + engineered swings). It exists ONLY to
exercise the engine mechanics (paper mode, backtester plumbing) WITHOUT a
broker. It must NEVER be used to judge strategy profitability. For that,
export REAL history from MT5 into data/<SYMBOL>_<TF>.csv.

Usage:
    python scripts/generate_demo_data.py --symbol EURUSD --timeframes M5 M15 H1 H4 D1
"""

from __future__ import annotations

import argparse
import csv
import math
import random
from datetime import datetime, timedelta, timezone
from pathlib import Path

DATA_DIR = Path(__file__).resolve().parent.parent / "data"

BASE_PRICES = {"EURUSD": 1.0850, "GBPUSD": 1.2650, "USDCAD": 1.3600,
               "XAUUSD": 2320.0, "BTCUSD": 64000.0}
BASE_VOLS = {"EURUSD": 0.0004, "GBPUSD": 0.0005, "USDCAD": 0.0004,
             "XAUUSD": 3.5, "BTCUSD": 250.0}
TF_MINUTES = {"M5": 5, "M15": 15, "M30": 30, "H1": 60, "H4": 240, "D1": 1440}


def gen(symbol: str, tf: str, bars: int, seed: int) -> None:
    rnd = random.Random(seed)
    px = BASE_PRICES.get(symbol, 1.1)
    vol = BASE_VOLS.get(symbol, 0.0005)
    step = TF_MINUTES[tf] * 60
    t0 = int((datetime.now(timezone.utc) - timedelta(seconds=step * bars))
             .replace(microsecond=0).timestamp())
    rows = []
    for i in range(bars):
        # regime shifts make swings/zones/structure detectable
        drift = vol * (0.35 * math.sin(i / 37.0) + 0.25 * math.sin(i / 11.0))
        shock = rnd.gauss(0, vol)
        o = px
        px = max(1e-6, px * (1 + drift + shock))
        c = px
        hi = max(o, c) * (1 + abs(rnd.gauss(0, vol * 0.6)))
        lo = min(o, c) * (1 - abs(rnd.gauss(0, vol * 0.6)))
        rows.append((t0 + i * step, o, hi, lo, c, int(abs(rnd.gauss(500, 200)))))
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    out = DATA_DIR / f"{symbol}_{tf}.csv"
    with out.open("w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["time", "open", "high", "low", "close", "volume"])
        w.writerows(rows)
    print(f"wrote {out} ({bars} bars, SYNTHETIC)")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--symbol", default="EURUSD")
    ap.add_argument("--timeframes", nargs="+", default=["M5", "M15", "H1", "H4", "D1"])
    ap.add_argument("--bars", type=int, default=500)
    ap.add_argument("--seed", type=int, default=42)
    a = ap.parse_args()
    for i, tf in enumerate(a.timeframes):
        gen(a.symbol.upper(), tf, a.bars, a.seed + i)
    print("\nNOTE: data is SYNTHETIC - for mechanics testing only.")


if __name__ == "__main__":
    main()
