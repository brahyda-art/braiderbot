"""BRAIDER BOT FX - export real MT5 history into data/<SYMBOL>_<TF>.csv.

Run this ON THE WINDOWS MACHINE that has the MT5 terminal installed, with
MT5 open and logged into the account you want to export from (the Exness
demo account, for this project):

    cd braider_bot_fx_engine
    python scripts/download_mt5_data.py

WHY THIS EXISTS
----------------
Paper mode (app/market/data_feed.py -> CsvFeed) reads local files at
data/<SYMBOL>_<TIMEFRAME>.csv instead of talking to MT5 directly. This
script fills that folder with REAL history pulled from MT5, replacing the
synthetic data from scripts/generate_demo_data.py.

REUSE, NOT DUPLICATION
-----------------------
This script does not reimplement MT5 connection or symbol-resolution logic:
 - MT5 initialization (MT5_TERMINAL_PATH / common install paths / login) is
   imported directly from mt5_bridge/bridge.py (_ensure_initialized).
 - Broker-symbol resolution (EURUSD -> EURUSDm etc.) is the same
   app/market/symbol_resolution.resolve_symbol_name used by the bridge and
   by scripts/check_mt5_symbols.py, applied in the same order: try the
   symbol already configured in config/config.yaml (symbols.mapping) first,
   then fall back to live discovery. It never guesses a suffix for an
   unconfirmed instrument.
 - The MT5 timeframe constants come from mt5_bridge.bridge.TIMEFRAME_MAP.

READ-ONLY / SAFE
-----------------
This script only calls mt5.copy_rates_from_pos() (historical data read).
It never places an order, never changes account/trading settings, and does
not touch LIVE_TRADING_ENABLED, execution mode, or any risk/strategy config.

OUTPUT
------
For every (symbol, timeframe) pair it writes data/<SYMBOL>_<TF>.csv with
columns: time,open,high,low,close,volume - time is the bar's UTC open time
in epoch seconds, matching what app/market/data_feed.py's CsvFeed already
parses (same format scripts/generate_demo_data.py produces).
"""

from __future__ import annotations

import argparse
import csv
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from dotenv import load_dotenv  # noqa: E402

load_dotenv()

from fastapi import HTTPException  # noqa: E402

from mt5_bridge.bridge import mt5, TIMEFRAME_MAP, _ensure_initialized  # noqa: E402
from app.config import load_config  # noqa: E402
from app.market.symbol_resolution import resolve_symbol_name  # noqa: E402

DATA_DIR = Path(__file__).resolve().parent.parent / "data"

DEFAULT_SYMBOLS = ["EURUSD", "GBPUSD", "USDCAD", "XAUUSD", "BTCUSD"]
DEFAULT_TIMEFRAMES = ["M5", "M15", "M30", "H1", "H4", "D1"]

# Current strategy minimum (config/config.yaml -> strategy.bars) is
# M1/M5/M15/M30=400, H1=500, H4=400, D1=120. These targets are a deliberate
# buffer above that minimum, not the bare minimum - comfortably under MT5's
# per-call limit so one copy_rates_from_pos() call per (symbol, timeframe)
# is enough; no pagination needed.
# M1 is not in DEFAULT_TIMEFRAMES (downloaded separately, on request, via
# --timeframes M1) but the buffer is defined here so that works out of the
# box when you do run it - M1 support itself needed no code change: the
# timeframe constant already exists in mt5_bridge.bridge.TIMEFRAME_MAP.
BARS_PER_TF: Dict[str, int] = {
    "M1": 3000,
    "M5": 3000, "M15": 3000, "M30": 3000,
    "H1": 3000, "H4": 2000, "D1": 1000,
}


class DownloadError(RuntimeError):
    pass


def resolve_broker_symbol(canonical: str, configured_mapping: Dict[str, str]) -> str:
    """Same resolution order as scripts/check_mt5_symbols.py: prefer whatever
    is already pinned in config.yaml's symbols.mapping, then fall back to
    live discovery against this MT5 installation's actual symbol list."""
    configured = configured_mapping.get(canonical, canonical)
    if mt5.symbol_info(configured) is not None:
        return configured
    all_symbols = mt5.symbols_get() or []
    resolved = resolve_symbol_name(canonical, (s.name for s in all_symbols))
    if resolved is None:
        raise DownloadError(
            f"could not resolve a broker symbol for {canonical} "
            f"(tried configured '{configured}' and live discovery)"
        )
    return resolved


def download_rates(broker_symbol: str, timeframe: str, bars: int) -> List[Dict[str, Any]]:
    tf_const = TIMEFRAME_MAP.get(timeframe.upper())
    if tf_const is None:
        raise DownloadError(f"unknown timeframe: {timeframe}")
    mt5.symbol_select(broker_symbol, True)
    if mt5.symbol_info(broker_symbol) is None:
        raise DownloadError(f"symbol_info failed for {broker_symbol} (not selectable)")
    rates = mt5.copy_rates_from_pos(broker_symbol, tf_const, 0, bars)
    if rates is None:
        raise DownloadError(f"copy_rates_from_pos returned None: {mt5.last_error()}")
    if len(rates) == 0:
        raise DownloadError(f"MT5 returned 0 candles for {broker_symbol} {timeframe} "
                            f"(market closed with no history cached locally?)")
    return rates


def write_csv(canonical: str, timeframe: str, rates) -> Path:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    out_path = DATA_DIR / f"{canonical}_{timeframe}.csv"
    with out_path.open("w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["time", "open", "high", "low", "close", "volume"])
        for r in rates:
            w.writerow([
                int(r["time"]), float(r["open"]), float(r["high"]),
                float(r["low"]), float(r["close"]), float(r["tick_volume"]),
            ])
    return out_path


def fmt_ts(ts: int) -> str:
    return datetime.fromtimestamp(int(ts), tz=timezone.utc).strftime("%Y-%m-%d %H:%M UTC")


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--symbols", nargs="+", default=DEFAULT_SYMBOLS,
                    help=f"canonical symbols (default: {DEFAULT_SYMBOLS})")
    ap.add_argument("--timeframes", nargs="+", default=DEFAULT_TIMEFRAMES,
                    help=f"timeframes (default: {DEFAULT_TIMEFRAMES})")
    args = ap.parse_args()

    if mt5 is None:
        print("ERROR: MetaTrader5 package not installed. Run: pip install MetaTrader5")
        return 2

    print("=" * 78)
    print("BRAIDER BOT FX - MT5 historical data export (read-only)")
    print("=" * 78)

    try:
        _ensure_initialized()
    except HTTPException as exc:
        print(f"ERROR: MT5 initialize failed: {exc.detail}")
        print("Checklist: MT5 terminal open, logged into the demo account,")
        print("MT5_TERMINAL_PATH in .env pointing at the exact terminal64.exe.")
        return 1

    acc = mt5.account_info()
    if acc is None:
        print(f"ERROR: account_info() is None - not logged in? ({mt5.last_error()})")
        return 1
    print(f"Connected: login={acc.login} server={acc.server} balance={acc.balance}\n")

    cfg = load_config()
    configured_mapping = cfg.symbols.mapping

    results: List[Dict[str, Any]] = []
    failures: List[str] = []

    for canonical in args.symbols:
        canonical = canonical.upper()
        try:
            broker_symbol = resolve_broker_symbol(canonical, configured_mapping)
        except DownloadError as exc:
            print(f"FAILED  {canonical}: {exc}")
            failures.append(f"{canonical}: {exc}")
            continue

        for tf in args.timeframes:
            tf = tf.upper()
            bars_wanted = BARS_PER_TF.get(tf, 1000)
            try:
                rates = download_rates(broker_symbol, tf, bars_wanted)
            except DownloadError as exc:
                print(f"FAILED  {canonical} {tf}: {exc}")
                failures.append(f"{canonical} {tf}: {exc}")
                continue

            out_path = write_csv(canonical, tf, rates)
            first_t, last_t = int(rates[0]["time"]), int(rates[-1]["time"])
            row = {
                "canonical": canonical, "broker_symbol": broker_symbol,
                "timeframe": tf, "count": len(rates),
                "first": fmt_ts(first_t), "last": fmt_ts(last_t),
                "file": out_path.name,
            }
            results.append(row)
            print(f"OK      {canonical:<8} -> {broker_symbol:<10} {tf:<4} "
                  f"{len(rates):>5} bars  [{row['first']} .. {row['last']}]  -> {out_path.name}")

    print("\n" + "=" * 78)
    print("SUMMARY")
    print("=" * 78)
    print(f"{'canonical':<10}{'broker':<12}{'tf':<6}{'bars':>7}  {'first':<19}  {'last':<19}  file")
    for row in results:
        print(f"{row['canonical']:<10}{row['broker_symbol']:<12}{row['timeframe']:<6}"
              f"{row['count']:>7}  {row['first']:<19}  {row['last']:<19}  {row['file']}")

    if failures:
        print(f"\n{len(failures)} FAILURE(S):")
        for f in failures:
            print(f"  - {f}")

    mt5.shutdown()

    if failures:
        print(f"\nRESULT: {len(results)} succeeded, {len(failures)} failed. "
              "Do not assume paper mode has full data until every pair above is OK.")
        return 1

    print(f"\nRESULT: all {len(args.symbols)} symbols x {len(args.timeframes)} "
          "timeframes downloaded successfully.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
