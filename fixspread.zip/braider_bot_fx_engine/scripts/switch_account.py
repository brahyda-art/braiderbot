"""Switch the MT5 DEMO account the bot trades - done ON THE VPS, not on the website.

    python scripts\\switch_account.py            <- just run this: it asks for login, server and
                                                  password, switches MT5 to that DEMO account and the
                                                  website picks the new account up by itself.

Optional (save accounts under a name so you can switch back without typing):
    python scripts\\switch_account.py add exness1 12345678 Exness-MT5Trial9   (asks for the password)
    python scripts\\switch_account.py list
    python scripts\\switch_account.py use exness1
    python scripts\\switch_account.py current
    python scripts\\switch_account.py remove exness1

Passwords live only in data\\mt5_accounts.json on this VPS (never in Firebase, the website or
the logs). `use` logs the MT5 terminal into the account, proves it landed on the right DEMO
account, and updates .env so the account survives a bridge restart. The website then shows the
new account automatically (the engine reports it). Real accounts are refused.
"""
from __future__ import annotations

import argparse
import getpass
import json
import os
import re
import sys
from pathlib import Path
from typing import Any, Dict, Optional

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

STORE = ROOT / "data" / "mt5_accounts.json"
ENV = ROOT / ".env"


def _mask(login: str) -> str:
    login = str(login)
    return (login[:2] + "***" + login[-2:]) if len(login) > 4 else "***"


def load_store(path: Path = STORE) -> Dict[str, Dict[str, str]]:
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8") or "{}")


def save_store(data: Dict[str, Dict[str, str]], path: Path = STORE) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")


def set_env_values(values: Dict[str, str], path: Path = ENV) -> None:
    """Set KEY=value lines in .env (replacing every existing line for that key)."""
    lines = path.read_text(encoding="utf-8-sig").splitlines() if path.exists() else []
    keys = set(values)
    kept = [ln for ln in lines if ln.split("=", 1)[0].strip() not in keys]
    kept += [f"{k}={v}" for k, v in values.items()]
    path.write_text("\n".join(kept) + "\n", encoding="utf-8")


def switch_to(broker: Any, acc: Dict[str, str], env_path: Path = ENV, force: bool = False,
              label: str = "") -> Dict[str, Any]:
    """Log MT5 into acc={login,server,password}, verify it, remember it in .env.
    Raises ValueError (message never contains the password) on any problem."""
    if not force:
        if broker.positions() or broker.pending_orders():
            raise ValueError("the current account still has open positions or pending orders - "
                             "stop the bot and close them first")
    try:
        broker.connect_account(acc["login"], acc["password"], acc["server"])
        info = broker.account()
    except Exception as exc:                         # bridge text never contains the password
        raise ValueError(f"MT5 login failed: {exc}")
    if str(info.login) != str(acc["login"]):
        raise ValueError("MT5 reported a different login than requested")
    if info.server and info.server.strip().lower() != acc["server"].strip().lower():
        raise ValueError("MT5 reported a different server than requested")
    if str(info.mode).lower() in ("real", "live", "2"):
        raise ValueError("this is a REAL account - only DEMO accounts are allowed")
    set_env_values({"MT5_LOGIN": acc["login"], "MT5_PASSWORD": acc["password"],
                    "MT5_SERVER": acc["server"]}, env_path)
    return {"name": label, "login": _mask(info.login), "server": info.server,
            "currency": info.currency, "balance": round(float(info.balance), 2), "mode": str(info.mode)}


def use_account(name: str, broker: Any, store_path: Path = STORE, env_path: Path = ENV,
                force: bool = False) -> Dict[str, Any]:
    """Switch to the saved account `name`."""
    store = load_store(store_path)
    if name not in store:
        raise ValueError(f"no saved account called '{name}' (try: list)")
    return switch_to(broker, store[name], env_path, force, label=name)


def _broker():
    from dotenv import load_dotenv
    load_dotenv(ENV)
    from app.config import load_config
    from app.execution.broker_client import BridgeBroker
    cfg = load_config()
    return BridgeBroker(cfg.execution.bridge_url, os.environ.get("BRIDGE_TOKEN", ""),
                        cfg.execution.bridge_timeout_seconds)


def main(argv: Optional[list] = None) -> int:
    ap = argparse.ArgumentParser(description="Switch the MT5 demo account on the VPS")
    sub = ap.add_subparsers(dest="cmd")
    a = sub.add_parser("add"); a.add_argument("name"); a.add_argument("login"); a.add_argument("server")
    sub.add_parser("list")
    u = sub.add_parser("use"); u.add_argument("name"); u.add_argument("--force", action="store_true")
    sub.add_parser("current")
    r = sub.add_parser("remove"); r.add_argument("name")
    args = ap.parse_args(argv)

    if args.cmd is None:                                   # plain `python scripts\\switch_account.py`
        print("Switch the MT5 DEMO account the bot trades.\n")
        login = input("MT5 login (account number): ").strip()
        if not re.fullmatch(r"\d{5,10}", login):
            print("NOT switched: login must be 5-10 digits"); return 1
        server = input("MT5 server (e.g. Exness-MT5Trial9): ").strip()
        if not server:
            print("NOT switched: server is required"); return 1
        pw = getpass.getpass("MT5 password (hidden): ")
        if not pw:
            print("NOT switched: password is required"); return 1
        try:
            res = switch_to(_broker(), {"login": login, "server": server, "password": pw})
        except ValueError as exc:
            print(f"NOT switched: {exc}"); return 1
        print(f"\nSwitched: {res['login']} on {res['server']} - {res['currency']} {res['balance']:.2f} ({res['mode']})")
        print("The website will show the new account within a few seconds.")
        return 0

    if args.cmd == "add":
        if not re.fullmatch(r"\d{5,10}", args.login):
            print("login must be 5-10 digits"); return 1
        pw = getpass.getpass("MT5 password (hidden): ")
        if not pw:
            print("password is required"); return 1
        store = load_store(); store[args.name] = {"login": args.login, "server": args.server, "password": pw}
        save_store(store)
        print(f"saved '{args.name}' ({_mask(args.login)} on {args.server}). Use it with: use {args.name}")
    elif args.cmd == "list":
        for n, v in load_store().items():
            print(f"  {n:15} {_mask(v['login'])}  {v['server']}")
        if not load_store():
            print("  (none yet - use: add <name> <login> <server>)")
    elif args.cmd == "remove":
        store = load_store()
        if store.pop(args.name, None) is None:
            print("no such account"); return 1
        save_store(store); print(f"removed '{args.name}' from this VPS (the broker account is untouched)")
    elif args.cmd == "current":
        i = _broker().account()
        print(f"{_mask(i.login)} on {i.server} - {i.currency} {i.balance:.2f} - {i.mode}")
    elif args.cmd == "use":
        try:
            res = use_account(args.name, _broker(), force=args.force)
        except ValueError as exc:
            print(f"NOT switched: {exc}"); return 1
        print(f"Switched to '{res['name']}': {res['login']} on {res['server']} - "
              f"{res['currency']} {res['balance']:.2f} ({res['mode']})")
        print("The website will show it within a few seconds.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
