"""Complete Phase 12 End-to-End DEMO Execution Test through the REST API.

Tests the full intended lifecycle:
WEBSITE/API -> AUTHENTICATED API -> BRAIDER BOT FX ENGINE -> RISK VALIDATION
-> EXECUTOR -> MT5 BRIDGE -> EXNESS DEMO
and then back:
MT5 -> ENGINE -> API -> WEBSITE/CONSUMER

All while LIVE_TRADING_ENABLED remains false.
"""

from __future__ import annotations

import os
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from dotenv import load_dotenv

load_dotenv()

from fastapi.testclient import TestClient

from app.api.server import create_app
from app.config import load_config
from app.engine import Engine
from app.execution.broker_client import BridgeBroker
from app.journal.journal import Journal
from app.market.data_feed import BridgeFeed
from app.services.account_manager import AccountManager
from app.state_store import StateStore

PROJECT_ROOT = Path(__file__).resolve().parent.parent


def run_e2e_test():
    print("=" * 70)
    print("BRAIDER BOT FX — PHASE 12 END-TO-END DEMO EXECUTION TEST (API PATH)")
    print("=" * 70)

    # Verify gates
    cfg = load_config()
    cfg.execution.mode = "demo"
    api_token = os.environ.get("API_TOKEN", "")
    bridge_token = os.environ.get("BRIDGE_TOKEN", "")
    cfg._api_token = api_token

    if os.environ.get("LIVE_TRADING_ENABLED", "").lower() == "true":
        print("CRITICAL: LIVE_TRADING_ENABLED is true! Aborting.")
        return 1

    print(f"Execution mode: {cfg.execution.mode} | LIVE_TRADING_ENABLED: false")

    # Connect broker & engine
    broker = BridgeBroker(cfg.execution.bridge_url, bridge_token, cfg.execution.bridge_timeout_seconds)
    feed = BridgeFeed(broker)
    store = StateStore(PROJECT_ROOT / "data" / "braider.db")
    journal = Journal(store)
    engine = Engine(cfg, broker, feed, store, journal)
    account_manager = AccountManager(PROJECT_ROOT / "data" / "accounts.json")

    app = create_app(cfg, store, get_engine=lambda: engine, account_manager=account_manager)
    client = TestClient(app)
    headers = {"X-API-Token": api_token}

    # Step 1: Health & Account check via API
    print("\n[Step 1] Checking API /health and /account endpoints...")
    r = client.get("/health")
    assert r.status_code == 200, f"/health failed: {r.text}"
    print("  /health OK:", r.json()["ok"])

    r = client.get("/account")
    assert r.status_code == 200, f"/account failed: {r.text}"
    acc_data = r.json()
    print("  /account data:", acc_data)

    # Step 2: Unauthenticated command must be rejected (Security check)
    print("\n[Step 2] Testing API security gate (unauthenticated command)...")
    r = client.post("/command", json={"action": "demo_test_order", "payload": {"symbol": "BTCUSD"}})
    assert r.status_code == 401, f"Expected 401, got {r.status_code}"
    print("  Unauthenticated command correctly refused with 401.")

    # Step 3: Authenticated test order command
    print("\n[Step 3] Sending authenticated test order command (BTCUSD, 0.01 lot)...")
    cmd_payload = {
        "action": "demo_test_order",
        "payload": {"symbol": "BTCUSD", "side": "buy", "lots": 0.01}
    }
    r = client.post("/command", json=cmd_payload, headers=headers)
    assert r.status_code == 200, f"Command failed: {r.text}"
    order_res = r.json()
    print("  /command response:", order_res)

    if not order_res.get("ok"):
        print("ERROR: Test order was not accepted:", order_res)
        return 1

    ticket = str(order_res["ticket"])
    print(f"\n[Step 4] MT5 DEMO ORDER CONFIRMED! Ticket: {ticket}")
    print(f"  Symbol: {order_res.get('symbol')} | Price: {order_res.get('price')}")
    print(f"  SL: {order_res.get('sl')} | TP: {order_res.get('tp')}")

    # Step 5: Verify position visible via API /positions
    time.sleep(1)
    print("\n[Step 5] Checking open positions via API /positions...")
    r = client.get("/positions")
    assert r.status_code == 200
    positions = r.json().get("positions", [])
    found_pos = next((p for p in positions if str(p.get("ticket")) == ticket), None)
    if found_pos:
        print(f"  Position {ticket} successfully returned by API:")
        print(f"    Symbol: {found_pos.get('symbol')}, Lots: {found_pos.get('lots')}, Profit: {found_pos.get('profit')}")
    else:
        print("  WARNING: Position not found in /positions!")

    # Step 6: Verify trade record visible via API /trades
    print("\n[Step 6] Checking recent trades via API /trades...")
    r = client.get("/trades")
    assert r.status_code == 200
    trades = r.json().get("trades", [])
    found_trade = next((t for t in trades if str(t.get("ticket")) == ticket), None)
    if found_trade:
        print(f"  Trade record {ticket} successfully returned by API:")
        print(f"    Side: {found_trade.get('side')}, Entry: {found_trade.get('entry')}, Status: {found_trade.get('status')}")

    # Step 7: Close position via authenticated API command
    print(f"\n[Step 7] Closing position ticket {ticket} via API command...")
    close_cmd = {
        "action": "close_position",
        "payload": {"ticket": ticket}
    }
    r = client.post("/command", json=close_cmd, headers=headers)
    assert r.status_code == 200, f"Close command failed: {r.text}"
    close_res = r.json()
    print("  Close command response:", close_res)

    # Step 8: Verify position is closed
    time.sleep(1)
    print("\n[Step 8] Verifying position is no longer in /positions...")
    r = client.get("/positions")
    rem_positions = r.json().get("positions", [])
    is_open = any(str(p.get("ticket")) == ticket for p in rem_positions)
    print(f"  Position {ticket} in /positions: {is_open}")

    # Step 9: Verify trade status in /trades is now closed
    print("\n[Step 9] Verifying trade status in /trades is updated to closed...")
    r = client.get("/trades")
    trades = r.json().get("trades", [])
    updated_trade = next((t for t in trades if str(t.get("ticket")) == ticket), None)
    if updated_trade:
        print(f"  Trade status: {updated_trade.get('status')} | Profit: {updated_trade.get('profit')}")

    print("\n" + "=" * 70)
    print(">>> SUCCESS: PHASE 12 END-TO-END DEMO TEST PASSED COMPLETELY! <<<")
    print("=" * 70)
    return 0


if __name__ == "__main__":
    sys.exit(run_e2e_test())
