"""Controlled single-trade DEMO order execution test for BRAIDER BOT FX.

Follows Phases 5, 6, and 7 of the Antigravity Master Instructions:
- Enforces all safety gates: DEMO only, LIVE_TRADING_ENABLED=false
- Checks live spread, volume bounds, mandatory SL and TP distance
- Places ONE 0.01 lot market order with comment BBFX:DEMO_TEST
- Verifies MT5 order and position tickets
- Verifies engine journal and state store records
- Tests position modification (SL/TP)
- Closes the position and verifies closure in MT5 and journal
"""

from __future__ import annotations

import argparse
import os
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from dotenv import load_dotenv

load_dotenv()

from app.config import load_config
from app.constants import Direction
from app.execution.broker_client import BridgeBroker, BrokerError
from app.execution.executor import Executor
from app.journal.journal import Journal
from app.state_store import StateStore, day_key, utc_now_ms

PROJECT_ROOT = Path(__file__).resolve().parent.parent


def run_demo_test(target_canonical: str = "BTCUSD"):
    print("=" * 70)
    print("BRAIDER BOT FX — PHASE 5/6/7 CONTROLLED DEMO EXECUTION TEST")
    print("=" * 70)

    # 1. Gate checks
    cfg = load_config()
    live_env = os.environ.get("LIVE_TRADING_ENABLED", "").lower() == "true"
    if live_env or cfg.execution.mode == "live":
        print("CRITICAL SAFETY BLOCK: LIVE trading is prohibited in this test!")
        return 1

    print(f"Safety gate: LIVE_TRADING_ENABLED=false (confirmed: {not live_env})")
    print(f"Execution mode: {cfg.execution.mode}")

    token = os.environ.get("BRIDGE_TOKEN", "").strip()
    if not token:
        print("ERROR: BRIDGE_TOKEN not set in environment or .env")
        return 1

    broker = BridgeBroker(cfg.execution.bridge_url, token, cfg.execution.bridge_timeout_seconds)

    # Verify bridge health and MT5 account
    health = broker.health()
    print("Bridge health:", health.get("detail"))
    if not health.get("ok"):
        print("ERROR: Bridge is not healthy:", health)
        return 1

    acc = broker.account()
    print(f"Account: {acc.broker} | Login: {acc.login} | Server: {acc.server}")
    print(f"Mode: {acc.mode} | Balance: {acc.balance} | Equity: {acc.equity}")

    if acc.mode.lower() not in ("demo", "unknown"):
        print(f"CRITICAL SAFETY BLOCK: Account mode '{acc.mode}' is not DEMO! Aborting.")
        return 1

    # 2. Broker symbol resolution & specs
    broker_sym = cfg.symbols.mapping.get(target_canonical, target_canonical)
    print(f"\nTarget symbol: canonical={target_canonical} -> broker={broker_sym}")

    specs = broker.symbol_specs(broker_sym)
    point = float(specs.get("point", 0.01))
    digits = int(specs.get("digits", 2))
    vol_min = float(specs.get("volume_min", 0.01))
    vol_step = float(specs.get("volume_step", 0.01))
    stops_level = float(specs.get("stops_level_points", 0))

    print(f"Specs: point={point}, digits={digits}, vol_min={vol_min}, vol_step={vol_step}, stops_level={stops_level}")

    tick = broker.tick(broker_sym)
    bid = tick["bid"]
    ask = tick["ask"]
    spread_pts = tick.get("spread_points", 0)
    print(f"Live tick: bid={bid}, ask={ask}, spread_points={spread_pts:.1f}")

    # 3. Order sizing & SL/TP
    lots = vol_min  # smallest allowable lot (0.01)
    if target_canonical == "BTCUSD":
        # Point = 0.01 ($1 = 100 points). $500 SL distance = 50000 points
        sl_points = max(50000.0, stops_level + 1000.0)
    else:
        sl_points = max(150.0, stops_level + 50.0)
    tp_points = sl_points * 2.0  # 1:2 RR

    sl_price = round(ask - sl_points * point, digits)
    tp_price = round(ask + tp_points * point, digits)

    print(f"\nOrder Parameters:")
    print(f"  Side: BUY | Lots: {lots}")
    print(f"  Entry approx: {ask}")
    print(f"  Mandatory SL: {sl_price} ({sl_points} pts)")
    print(f"  TP: {tp_price} ({tp_points} pts)")

    # 4. Engine storage & executor
    store = StateStore(PROJECT_ROOT / "data" / "braider.db")
    journal = Journal(store)
    executor = Executor(cfg, broker, store, journal)

    setup_id = f"demo-conn-{int(time.time())}"
    print(f"\nSubmitting DEMO test order (setup_id={setup_id})...")

    # 5. Execute order
    res = executor.place_market(
        setup_id=setup_id,
        symbol=broker_sym,
        direction=Direction.LONG,
        lots=lots,
        sl=sl_price,
        tp=tp_price,
        risk_context={"reason": "DEMO_CONNECTION_TEST"},
    )
    print("Executor result:", res)

    if not res.get("ok") or not res.get("ticket"):
        print("ERROR: Demo test order was rejected or returned no ticket:", res)
        return 1

    ticket = str(res["ticket"])
    entry_fill = res.get("price")
    print(f"\n>>> DEMO ORDER ACCEPTED! Ticket: {ticket}, Fill Price: {entry_fill} <<<")

    # 6. Verify independently via broker.positions()
    time.sleep(1)
    open_positions = broker.positions()
    found_pos = next((p for p in open_positions if str(p.ticket) == ticket), None)
    if found_pos:
        print(f"\n[PHASE 6 VERIFICATION - BROKER POSITION CONFIRMED IN MT5]")
        print(f"  Ticket: {found_pos.ticket}")
        print(f"  Symbol: {found_pos.symbol}")
        print(f"  Side: {found_pos.side}")
        print(f"  Lots: {found_pos.lots}")
        print(f"  Open price: {found_pos.open_price}")
        print(f"  SL: {found_pos.sl}")
        print(f"  TP: {found_pos.tp}")
        print(f"  Current profit: {found_pos.profit}")
    else:
        print("WARNING: Position not found in broker open positions list!")

    # 7. Verify journal & state store
    recent_events = store.query("SELECT * FROM events ORDER BY id DESC LIMIT 5")
    print(f"\nJournaled recent events:")
    for ev in recent_events:
        print(f"  [{ev['level']}] {ev['category']}: {ev['message']}")

    # 8. Phase 7: Test Position Management (Modify SL slightly to test management path)
    new_sl = round(sl_price + 100 * point, digits)
    print(f"\n[PHASE 7 TEST - POSITION MANAGEMENT]")
    print(f"Testing SL modification {sl_price} -> {new_sl}...")
    mod_ok = executor.modify_sl_tp(ticket, sl=new_sl, tp=tp_price)
    print("SL modify result:", mod_ok)

    time.sleep(2)
    # 9. Phase 7: Controlled Close
    print(f"\nClosing position ticket {ticket} to complete single-trade lifecycle...")
    close_res = executor.close_position(ticket, lots=None, reason="DEMO_TEST_COMPLETE")
    print("Close position result:", close_res)

    time.sleep(1)
    # 10. Verify position closed
    rem_positions = broker.positions()
    still_open = any(str(p.ticket) == ticket for p in rem_positions)
    print(f"Position ticket {ticket} still open on MT5? {still_open}")

    if not still_open and close_res.get("ok"):
        print("\n" + "=" * 70)
        print(">>> SUCCESS: DEMO ORDER EXECUTION & MANAGEMENT FULLY VERIFIED! <<<")
        print("=" * 70)
        return 0
    else:
        print("\nWARNING: Close verification incomplete.")
        return 1


if __name__ == "__main__":
    sym = sys.argv[1] if len(sys.argv) > 1 else "BTCUSD"
    sys.exit(run_demo_test(sym))
