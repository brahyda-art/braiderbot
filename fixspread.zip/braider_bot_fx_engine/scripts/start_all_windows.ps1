$ErrorActionPreference = "Stop"
Set-Location (Join-Path $PSScriptRoot "..")

$python = Join-Path (Get-Location) ".venv\Scripts\python.exe"
if (-not (Test-Path $python)) { throw "Virtual environment not found: $python" }

Write-Host "Starting BRAIDER BOT FX MT5 bridge..."
$bridge = Start-Process -FilePath $python -ArgumentList "mt5_bridge\bridge.py" -WorkingDirectory (Get-Location) -PassThru
Start-Sleep -Seconds 3

Write-Host "Starting BRAIDER BOT FX engine..."
$engine = Start-Process -FilePath $python -ArgumentList "-m","app.main" -WorkingDirectory (Get-Location) -PassThru

Write-Host "Bridge PID: $($bridge.Id)"
Write-Host "Engine PID: $($engine.Id)"
Write-Host "Press Ctrl+C to stop both processes."

try {
    while (-not $bridge.HasExited -and -not $engine.HasExited) { Start-Sleep -Seconds 2 }
} finally {
    if (-not $bridge.HasExited) { Stop-Process -Id $bridge.Id -Force }
    if (-not $engine.HasExited) { Stop-Process -Id $engine.Id -Force }
}
