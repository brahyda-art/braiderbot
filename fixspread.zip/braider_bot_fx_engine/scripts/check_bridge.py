"""Connectivity self-test for the MT5 bridge.

Run this ON the machine that hosts the engine, pointing at the bridge:

    python scripts/check_bridge.py --url http://WINDOWS_VPS:8001 --token XXXX

Checks: health, account read, symbol specs for all configured symbols,
rates freshness.  Safe - performs no orders.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from dotenv import load_dotenv

load_dotenv()

from app.config import load_config          # noqa: E402
from app.execution.broker_client import BridgeBroker, BrokerError  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", default=None)
    ap.add_argument("--token", default=None)
    a = ap.parse_args()
    cfg = load_config()
    url = a.url or cfg.execution.bridge_url
    token = a.token or __import__("os").environ.get("BRIDGE_TOKEN", "")
    if not token:
        print("ERROR: provide --token or set BRIDGE_TOKEN")
        return 2
    broker = BridgeBroker(url, token, cfg.execution.bridge_timeout_seconds)
    ok = True

    def step(name, fn):
        nonlocal ok
        try:
            result = fn()
            print(f"  [OK]   {name}: {result}")
        except BrokerError as exc:
            ok = False
            print(f"  [FAIL] {name}: {exc}")

    print(f"Bridge: {url}")
    step("health", lambda: broker.health().get("detail"))
    step("account", lambda: f"{broker.account().broker} "
                            f"{broker.account().currency} "
                            f"eq={broker.account().equity}")
    for sym in cfg.symbols.watched:
        mapped = cfg.symbols.mapping.get(sym, sym)
        step(f"symbol {sym} -> {mapped}",
             lambda s=mapped: broker.symbol_specs(s).get("symbol"))
        step(f"rates {sym}", lambda s=mapped, tf=cfg.effective_strategy(sym).entry_timeframe: len(
            broker.rates(s, tf, 50)) > 0)
    print("\nRESULT:", "bridge is READY" if ok else "bridge has FAILURES (do not trade)")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
