import MetaTrader5 as mt5

MT5_PATH = r"C:\Program Files\MetaTrader 5\terminal64.exe"

CANONICAL_SYMBOLS = [
    "EURUSD",
    "GBPUSD",
    "USDCAD",
    "XAUUSD",
    "BTCUSD",
]

TIMEFRAMES = {
    "M5": mt5.TIMEFRAME_M5,
    "M15": mt5.TIMEFRAME_M15,
    "M30": mt5.TIMEFRAME_M30,
    "H1": mt5.TIMEFRAME_H1,
    "H4": mt5.TIMEFRAME_H4,
    "D1": mt5.TIMEFRAME_D1,
}


def resolve_symbol(canonical):
    # First try exact canonical name.
    info = mt5.symbol_info(canonical)

    if info is not None:
        mt5.symbol_select(canonical, True)
        return canonical

    # Then look for broker suffix/prefix variants.
    all_symbols = mt5.symbols_get()

    if all_symbols:
        upper = canonical.upper()

        for symbol in all_symbols:
            name = symbol.name.upper()

            if name == upper:
                mt5.symbol_select(symbol.name, True)
                return symbol.name

            if name.startswith(upper):
                mt5.symbol_select(symbol.name, True)
                return symbol.name

            if name.endswith(upper):
                mt5.symbol_select(symbol.name, True)
                return symbol.name

    return None


print("========================================")
print(" BRAIDER BOT FX - MT5 CANDLE TEST")
print("========================================")

print("MT5 path:", MT5_PATH)

if not mt5.initialize(path=MT5_PATH):
    print("INIT FAILED")
    print("ERROR:", mt5.last_error())
    raise SystemExit(1)

print("INIT OK")

account = mt5.account_info()

if account is None:
    print("ACCOUNT INFO FAILED")
    print("ERROR:", mt5.last_error())
    mt5.shutdown()
    raise SystemExit(1)

print("Account login:", account.login)
print("Account server:", account.server)
print("Account balance:", account.balance)
print("Trade mode:", "DEMO" if account.trade_mode != 0 else "UNKNOWN")

print()
print("Testing historical candles...")
print()

all_passed = True

for canonical in CANONICAL_SYMBOLS:

    broker_symbol = resolve_symbol(canonical)

    print("----------------------------------------")
    print(f"{canonical} -> {broker_symbol}")

    if broker_symbol is None:
        print("SYMBOL RESOLUTION: FAILED")
        all_passed = False
        continue

    print("SYMBOL RESOLUTION: OK")

    tick = mt5.symbol_info_tick(broker_symbol)

    if tick is None:
        print("LIVE TICK: FAILED")
        print("ERROR:", mt5.last_error())
        all_passed = False
        continue

    print("LIVE TICK: OK")
    print("Bid:", tick.bid)
    print("Ask:", tick.ask)

    for tf_name, timeframe in TIMEFRAMES.items():

        rates = mt5.copy_rates_from_pos(
            broker_symbol,
            timeframe,
            0,
            100
        )

        if rates is None or len(rates) == 0:
            print(f"{tf_name}: FAILED")
            print("ERROR:", mt5.last_error())
            all_passed = False
            continue

        latest = rates[-1]

        print(
            f"{tf_name}: OK | candles={len(rates)} | "
            f"latest_close={latest['close']}"
        )

print()
print("========================================")

if all_passed:
    print("RESULT: ALL WATCHED SYMBOLS HAVE HISTORICAL CANDLE DATA.")
else:
    print("RESULT: SOME CANDLE TESTS FAILED.")

print("========================================")

mt5.shutdown()