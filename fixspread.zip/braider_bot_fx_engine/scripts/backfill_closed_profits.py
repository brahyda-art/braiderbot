"""The BRAIDER BOT FX engine orchestrator.

One cycle:
    fetch data -> validate freshness -> HTF context -> zones / SR / trendlines
    / liquidity -> confluence setups -> pipeline validation -> execute ->
    manage open positions & pendings -> journal -> push status

Default response to ANY uncertainty: DO NOT TRADE (spec section 31).
"""

from __future__ import annotations

import threading
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from .config import Config, apply_web_config
from .constants import BotState, Decision
from .entries.pipeline import TradePipeline
from .execution.broker_client import BrokerClient, BrokerError
from .execution.executor import Executor
from .execution.paper_broker import PaperBroker
from .journal.journal import Journal
from .liquidity.sweeps import detect_sweeps
from .market.candles import Candle, atr
from .market.data_feed import DataFeed
from .portfolio.trade_manager import TradeManager
from .risk.position_sizing import SymbolSpec
from .risk.risk_engine import RiskContext, RiskEngine
from .strategy.confluence import AnalysisBundle, Setup, build_setups
from .strategy.fvg import analyze_fvgs
from .strategy.htf_context import build_htf_context
from .strategy.levels import analyze_sr
from .strategy.structure import analyze_structure
from .strategy.swings import find_swings
from .strategy.trendlines import analyze_trendlines
from .zones.detector import analyze_zones
from .state_store import StateStore, TradeRecord, day_key, utc_now_ms


class Engine:
    def __init__(self, cfg: Config, broker: BrokerClient, feed: DataFeed,
                 store: StateStore, journal: Journal,
                 web_sink=None, external_status: Optional[Dict[str, Any]] = None):
        self.cfg = cfg
        self.broker = broker
        self.feed = feed
        self.store = store
        self.journal = journal
        self.web_sink = web_sink                      # services.firebase_sync sink
        self.external_status = external_status or {}  # live web pushes (commands)
        self.risk = RiskEngine(cfg, store)
        self.executor = Executor(cfg, broker, store, journal)
        self.manager = TradeManager(cfg, broker, self.executor, store, journal)
        self.pipeline = TradePipeline(
            cfg, self.risk, self._symbol_spec,
        )
        self._lock = threading.RLock()
        self._last_cycle_ms = 0
        self._cycle_count = 0

    # ------------------------------------------------------------------
    # state machine
    # ------------------------------------------------------------------
    @property
    def bot_state(self) -> BotState:
        value = self.store.kv_get("bot_state", BotState.STOPPED.value)
        try:
            return BotState(value)
        except ValueError:
            return BotState.STOPPED

    def set_bot_state(self, state: BotState, reason: str = "") -> None:
        prev = self.bot_state
        self.store.kv_set("bot_state", state.value)
        self.journal.log_event("engine", "INFO",
                               f"state change {prev.value} -> {state.value} ({reason})")
        if state is BotState.EMERGENCY_STOP:
            self._emergency_actions()
        self.push_status()

    def _emergency_actions(self) -> None:
        mg = self.cfg.management
        if mg.emergency_cancel_pending:
            self._cancel_all_pendings("emergency_stop")
        if mg.emergency_close_positions:
            try:
                positions = self.broker.positions()
            except BrokerError as exc:
                self.journal.log_risk("ERROR", f"emergency close aborted (no data): {exc}", {})
                return
            for p in positions:
                if p.magic == self.cfg.execution.magic or p.magic == 0:
                    self.executor.close_position(p.ticket, None, reason="emergency_stop")

    def _cancel_all_pendings(self, reason: str) -> None:
        try:
            pendings = self.broker.pending_orders()
        except BrokerError as exc:
            self.journal.log_risk("ERROR", f"cannot read pendings for cancel: {exc}", {})
            return
        for o in pendings:
            if o.magic == self.cfg.execution.magic:
                self.executor.cancel_pending(o.ticket, reason=reason)
                self.store.execute(
                    "UPDATE orders SET status='cancelled', cancel_reason=? "
                    "WHERE broker_ticket=? AND status='pending'", (reason, o.ticket))

    # ------------------------------------------------------------------
    # helpers
    # ------------------------------------------------------------------
    def _symbol_spec(self, symbol: str) -> SymbolSpec:
        raw = self.broker.symbol_specs(symbol)
        return SymbolSpec(
            symbol=str(raw.get("symbol", symbol)),
            tick_size=float(raw.get("tick_size", 0) or 0),
            tick_value=float(raw.get("tick_value", 0) or 0),
            volume_min=float(raw.get("volume_min", 0.01) or 0.01),
            volume_max=float(raw.get("volume_max", 100) or 100),
            volume_step=float(raw.get("volume_step", 0.01) or 0.01),
            contract_size=float(raw.get("contract_size", 0) or 0),
            point=float(raw.get("point", 0) or 0),
            stops_level_points=float(raw.get("stops_level_points", 0) or 0),
        )

    def broker_symbol(self, canonical: str) -> str:
        return self.cfg.symbols.mapping.get(canonical.upper(), canonical)

    def _account(self):
        return self.broker.account()

    def _spread_points(self, symbol: str) -> Optional[float]:
        try:
            t = self.broker.tick(symbol)
            return float(t.get("spread_points", 0) or 0)
        except BrokerError:
            return None

    # ------------------------------------------------------------------
    # web command handling (start/pause/stop/emergency from the website)
    # ------------------------------------------------------------------
    def handle_command(self, action: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        self.journal.log_security("INFO", f"web command received: {action}",
                                  {"payload_keys": list((payload or {}).keys())})
        if action == "start":
            if self.bot_state is BotState.EMERGENCY_STOP:
                return {"ok": False, "reason": "emergency stop active - resume required"}
            self.set_bot_state(BotState.RUNNING, "web command")
            return {"ok": True}
        if action == "resume":
            self.set_bot_state(BotState.RUNNING, "web command (resume)")
            return {"ok": True}
        if action == "pause":
            self.set_bot_state(BotState.PAUSED, "web command")
            return {"ok": True}
        if action == "stop":
            self.set_bot_state(BotState.STOPPED, "web command")
            return {"ok": True}
        if action == "emergency":
            self.set_bot_state(BotState.EMERGENCY_STOP, "web command")
            return {"ok": True}
        if action == "close_all":
            try:
                positions = self.broker.positions()
            except BrokerError as exc:
                return {"ok": False, "reason": str(exc)}
            for p in positions:
                if p.magic == self.cfg.execution.magic:
                    self.executor.close_position(p.ticket, None, reason="web_close_all")
            self._cancel_all_pendings("web_close_all")
            return {"ok": True}
        if action == "config_update" and isinstance(payload.get("web"), dict):
            applied = apply_web_config(self.cfg, payload["web"])
            self.journal.log_event("engine", "INFO", "web config applied",
                                   {"applied": applied})
            return {"ok": True, "applied": applied}
        return {"ok": False, "reason": f"unknown action {action}"}

    # ------------------------------------------------------------------
    # main loop
    # ------------------------------------------------------------------
    def run_forever(self, stop_event: threading.Event) -> None:
        self.journal.log_event("engine", "INFO",
                               f"engine loop starting mode={self.cfg.execution.mode}")
        self._bootstrap_day()
        while not stop_event.is_set():
            started = time.time()
            try:
                with self._lock:
                    self.run_cycle()
            except Exception as exc:  # never die on a cycle error
                self.journal.log_event("engine", "ERROR",
                                       f"cycle error: {exc}", {"cycle": self._cycle_count})
            self._last_cycle_ms = utc_now_ms()
            self._cycle_count += 1
            elapsed = time.time() - started
            delay = max(1.0, self.cfg.execution.cycle_seconds - elapsed)
            stop_event.wait(delay)

    def _bootstrap_day(self) -> None:
        try:
            acc = self._account()
            day = day_key()
            self.store.kv_set("current_day", day)
            self.store.init_daily(day, acc.balance, acc.equity)
            peak = self.store.kv_get("account_peak_equity")
            if not peak or acc.equity > peak:
                self.store.kv_set("account_peak_equity", acc.equity)
        except BrokerError as exc:
            self.journal.log_risk("ERROR", f"bootstrap failed: {exc}", {})

    def run_cycle(self) -> Dict[str, Any]:
        now_ms = utc_now_ms()
        self._roll_day_if_needed(now_ms)

        # 0. reconciliation with the broker (recovery after restart, spec 31)
        self._reconcile()

        state = self.bot_state
        if state in (BotState.STOPPED, BotState.EMERGENCY_STOP):
            self.push_status()
            return {"state": state.value, "traded": False}

        # Even when paused/running, manage what is open.
        managed = self._manage_open_trades(now_ms)
        self._manage_pendings(now_ms)

        if state is not BotState.RUNNING:
            self.push_status()
            return {"state": state.value, "managed": managed, "traded": False}

        # 1. per-symbol scan
        executed: List[Dict[str, Any]] = []
        for canonical in self.cfg.symbols.watched:
            try:
                results = self._scan_symbol(canonical, now_ms)
                executed.extend(results)
            except BrokerError as exc:
                self.journal.log_event("engine", "ERROR",
                                       f"data error for {canonical}: {exc}", {})
            except Exception as exc:
                self.journal.log_event("engine", "ERROR",
                                       f"scan error for {canonical}: {exc}", {})

        self.push_status()
        return {"state": state.value, "traded": bool(executed), "executed": executed}

    # ------------------------------------------------------------------
    def _roll_day_if_needed(self, now_ms: int) -> None:
        tz = self.cfg.timezone
        try:
            from zoneinfo import ZoneInfo
            now_local = datetime.fromtimestamp(now_ms / 1000, tz=ZoneInfo(tz))
        except Exception:
            now_local = datetime.fromtimestamp(now_ms / 1000, tz=timezone.utc)
        today = now_local.strftime("%Y-%m-%d")
        if self.store.kv_get("current_day") != today:
            self.store.kv_set("current_day", today)
            try:
                acc = self._account()
                self.store.init_daily(today, acc.balance, acc.equity)
                self.journal.log_event("risk", "INFO",
                                       f"new trading day {today} "
                                       f"balance={acc.balance:.2f} equity={acc.equity:.2f}")
            except BrokerError:
                pass

    # ------------------------------------------------------------------
    def _reconcile(self) -> None:
        """Match broker positions to journal entries; adopt unknown positions
        instead of silently ignoring them (restart safety)."""
        try:
            positions = self.broker.positions()
        except BrokerError as exc:
            self.journal.log_event("engine", "WARNING", f"reconcile skipped: {exc}", {})
            return
        known_tickets = {t.ticket for t in self.store.open_trades() if t.ticket}
        for p in positions:
            if p.magic != self.cfg.execution.magic:
                continue
            if p.ticket in known_tickets:
                continue
            recovered = self.store.get_trade_by_ticket(p.ticket)
            if recovered and recovered.status in ("open", "pending"):
                continue
            # Unknown bot position: adopt with minimal thesis so it gets managed.
            trade = TradeRecord(
                id=f"rec-{p.ticket}", setup_id=None, ticket=p.ticket,
                symbol=p.symbol, side=p.side, lots=p.lots,
                entry=p.open_price, sl=p.sl, tp=p.tp, status="open",
                opened_at=p.opened_at or utc_now_ms(), mode=self.cfg.execution.mode,
                thesis={"kind": "adopted_after_restart", "note":
                        "position found on broker without journal entry"},
            )
            self.store.upsert_trade(trade)
            self.journal.log_trade_event("WARNING",
                                         f"adopted unknown position {p.ticket} "
                                         f"({p.symbol} {p.side} {p.lots})", {})

    # ------------------------------------------------------------------
    def _scan_symbol(self, canonical: str, now_ms: int) -> List[Dict[str, Any]]:
        st = self.cfg.effective_strategy(canonical)
        symbol = self.broker_symbol(canonical)

        # --- data ---------------------------------------------------------
        data: Dict[str, List[Candle]] = {}
        needed = set(st.htf_bias_timeframes) | set(st.zone_timeframes) | \
            {st.entry_timeframe, st.confirmation_timeframe, "D1"}
        for tf in needed:
            if tf not in self.cfg.strategy.bars:
                continue
            candles = self.feed.get_rates(symbol, tf, self.cfg.strategy.bars[tf])
            data[tf] = candles

        entry_candles = data.get(st.entry_timeframe) or []
        fresh, age = self.feed.is_fresh(symbol, st.entry_timeframe, entry_candles,
                                        self.cfg.execution.data_max_age_bars)
        if len(entry_candles) < 60:
            self._journal_rejection(canonical, symbol, "data_validation",
                                    f"insufficient candles ({len(entry_candles)})")
            return []
        if not fresh:
            self._journal_rejection(canonical, symbol, "data_validation",
                                    f"stale data (age {age:.0f}s)")
            return []

        # --- analysis -------------------------------------------------------
        swings = find_swings(entry_candles, st.swing_strength)
        entry_structure = analyze_structure(
            entry_candles, st.swing_strength, st.atr_period)
        zones_by_tf = {}
        for tf in st.zone_timeframes:
            zc = data.get(tf) or []
            if len(zc) >= 30:
                zones_by_tf[tf] = analyze_zones(zc, tf, st)
        zone_analysis = self._merge_zones(zones_by_tf)
        sr = analyze_sr(entry_candles, swings, data.get("D1") or (),
                        st.atr_period,
                        tolerance_atr=0.35, min_touches=2)
        sweeps = detect_sweeps(entry_candles, swings, st.entry_timeframe,
                               st.sweep_min_penetration_atr,
                               atr_period=st.atr_period)
        trendlines = analyze_trendlines(entry_candles, swings,
                                        st.atr_period,
                                        min_touches=3)
        htf = build_htf_context(data, st.htf_bias_timeframes,
                                st.swing_strength,
                                st.atr_period)
        entry_atr = atr(entry_candles, st.atr_period)
        fvgs = analyze_fvgs(entry_candles, entry_atr, st)

        bundle = AnalysisBundle(
            symbol=symbol, entry_tf=st.entry_timeframe, entry_candles=entry_candles,
            htf_bias=htf.bias, zones=zone_analysis, sr=sr,
            entry_structure=entry_structure, sweeps=sweeps, trendlines=trendlines,
            fvgs=fvgs.gaps,
            atr=entry_atr,
            point_size=self._point_size(symbol),
        )

        # --- confluence setups (also records rejections) ---------------------
        setups = build_setups(bundle, self.cfg)
        results: List[Dict[str, Any]] = []
        for setup in setups:
            res = self._process_setup(setup, canonical, symbol, now_ms)
            if res:
                results.append(res)
        return results

    def _point_size(self, symbol: str) -> float:
        try:
            return float(self.broker.symbol_specs(symbol).get("point", 0.00001) or 0.00001)
        except BrokerError:
            return 0.00001

    def _merge_zones(self, zones_by_tf):
        from .zones.detector import ZoneAnalysis
        merged = ZoneAnalysis()
        for za in zones_by_tf.values():
            merged.zones.extend(za.zones)
        merged.zones.sort(key=lambda z: -z.strength)
        return merged

    # ------------------------------------------------------------------
    def _process_setup(self, setup: Setup, canonical: str, symbol: str,
                       now_ms: int) -> Optional[Dict[str, Any]]:
        # HARD GATE: setups that failed any confluence gate (built only for
        # journaling) must never be executed, regardless of score.
        st = self.cfg.effective_strategy(canonical)
        if setup.gates_failed or setup.score < st.min_confluence_score or \
                setup.sl <= 0 or setup.tp <= 0:
            self._journal_rejection(
                canonical, symbol,
                setup.gates_failed[0] if setup.gates_failed else "confluence_score",
                f"gates={setup.gates_failed} score={setup.score:.2f}", setup)
            return None

        spread = self._spread_points(symbol)
        if spread is None:
            self._journal_rejection(canonical, symbol, "spread_check",
                                    "tick unavailable", setup)
            return None
        ctx = self._risk_context(symbol, now_ms, spread)
        spec = self._symbol_spec(symbol)

        # Direction gate: pipeline first (hard checks) ...
        result = self.pipeline.run(setup, ctx, spread,
                                   spec.tick_size or spec.point, spec)
        setup_dict = setup.to_journal(
            Decision.APPROVED if result.approved else Decision.REJECTED,
            result.stage, result.reason)
        setup_dict["details"] = {"metrics": result.metrics, "spread": spread}
        sid = self.journal.record_setup({**setup_dict, "ts": now_ms,
                                         "id": setup.id})
        if not result.approved:
            self.journal.log_risk("INFO",
                                  f"setup rejected at {result.stage}: {result.reason}",
                                  {"setup": setup.id, "symbol": canonical,
                                   "score": setup.score})
            return None

        # ... then execute.
        lots = result.lots
        if self.cfg.execution.mode == "paper":
            trade = self._execute_paper(setup, symbol, lots, now_ms, result.metrics)
        else:
            trade = self._execute_live(setup, symbol, lots, now_ms)
        if trade:
            if self.web_sink:
                try:
                    self.web_sink.push_trade(trade.to_web())
                except Exception:
                    pass
            return {"setup": sid, "ticket": trade.ticket, "lots": trade.lots}
        return None

    def _risk_context(self, symbol: str, now_ms: int, spread: float) -> RiskContext:
        acc = self._account()
        day = self.store.kv_get("current_day") or day_key(now_ms // 1000)
        return RiskContext(
            bot_state=self.bot_state,
            balance=acc.balance, equity=acc.equity, day=day,
            open_positions=[{"symbol": p.symbol, "lots": p.lots}
                            for p in self.broker.positions()],
            open_pendings=[{"symbol": o.symbol} for o in self.broker.pending_orders()],
            spread_points=spread,
            consecutive_losses=self.risk.consecutive_losses(),
            last_loss_ts_ms=self.risk.last_loss_time(),
            now_ms=now_ms,
        )

    # ------------------------------------------------------------------
    def _execute_paper(self, setup: Setup, symbol: str, lots: float,
                       now_ms: int, metrics: Dict) -> Optional[TradeRecord]:
        assert isinstance(self.broker, PaperBroker)
        res = self.executor.place_market(setup.id, symbol, setup.direction, lots,
                                         setup.sl, setup.tp,
                                         risk_context=metrics)
        if not res.get("ok"):
            return None
        trade = TradeRecord(
            id=f"tr-{setup.id}", setup_id=setup.id, ticket=res["ticket"],
            symbol=symbol, side=setup.direction.value, lots=lots,
            entry=res.get("price") or setup.entry, sl=setup.sl, tp=setup.tp,
            status="open", opened_at=now_ms, mode="paper",
            thesis=setup.thesis,
            management={"kind": setup.kind.value},
            comment=f"score={setup.score}",
        )
        self.store.upsert_trade(trade)
        self.store.update_daily(self.store.kv_get("current_day") or day_key(),
                                trades=(self.store.get_daily(day_key()).get("trades", 0) or 0) + 1)
        self.journal.log_trade_event("INFO", "PAPER trade opened", {
            "symbol": symbol, "side": setup.direction.value, "lots": lots,
            "entry": trade.entry, "sl": setup.sl, "tp": setup.tp,
            "score": setup.score, "ticket": trade.ticket,
        })
        return trade

    def _execute_live(self, setup: Setup, symbol: str, lots: float,
                      now_ms: int) -> Optional[TradeRecord]:
        # Live/demo path: the pipeline already approved; place via bridge.
        res = self.executor.place_market(setup.id, symbol, setup.direction, lots,
                                         setup.sl, setup.tp,
                                         risk_context={})
        if not res.get("ok"):
            return None
        mode = self.cfg.execution.mode
        trade = TradeRecord(
            id=f"tr-{setup.id}", setup_id=setup.id, ticket=res["ticket"],
            symbol=symbol, side=setup.direction.value, lots=lots,
            entry=res.get("price") or setup.entry, sl=setup.sl, tp=setup.tp,
            status="open", opened_at=now_ms, mode=mode,
            thesis=setup.thesis, management={"kind": setup.kind.value},
            comment=f"score={setup.score}",
        )
        self.store.upsert_trade(trade)
        self.store.update_daily(self.store.kv_get("current_day") or day_key(),
                                trades=(self.store.get_daily(day_key()).get("trades", 0) or 0) + 1)
        self.journal.log_trade_event("INFO", f"{mode.upper()} trade opened", {
            "symbol": symbol, "side": setup.direction.value, "lots": lots,
            "entry": trade.entry, "sl": setup.sl, "tp": setup.tp,
            "ticket": trade.ticket,
        })
        return trade

    # ------------------------------------------------------------------
    def _manage_open_trades(self, now_ms: int) -> List[Dict[str, Any]]:
        summary = []
        # 1. broker-side events (paper simulator: SL/TP/limit fills)
        if isinstance(self.broker, PaperBroker):
            seen_symbols = set()
            for t in self.store.open_trades():
                if t.symbol not in seen_symbols:
                    seen_symbols.add(t.symbol)
            for symbol in seen_symbols:
                candles = self.feed.get_rates(symbol, "M5", 2)
                if candles:
                    for ev in self.broker.on_candle_close(symbol, candles[-1]):
                        self._handle_paper_event(ev, symbol)
        try:
            positions = {p.ticket: p for p in self.broker.positions()}
        except BrokerError as exc:
            self.journal.log_event("engine", "WARNING",
                                   f"management skipped (broker unreachable): {exc}", {})
            return summary

        for trade in self.store.open_trades():
            if trade.status != "open":
                continue
            pos = positions.get(trade.ticket)
            if pos is None:
                # Position no longer on broker: closed by SL/TP or manually.
                self._mark_closed_by_broker(trade)
                continue
            # refresh live values (profit = floating P/L while the trade is open)
            trade.lots = pos.lots
            self._refresh_floating(trade, float(pos.profit) + float(pos.swap or 0.0))
            canonical = self._canonical_or_same(trade.symbol)
            mgmt_tf = self.cfg.effective_strategy(canonical).entry_timeframe
            candles = self.feed.get_rates(canonical, mgmt_tf,
                                          self.cfg.strategy.bars.get(mgmt_tf, 400))
            try:
                actions = self.manager.evaluate_position(trade, candles, now_ms)
                self.manager.apply_actions(trade, actions)
                summary.append({"ticket": trade.ticket,
                                "actions": [a.kind for a in actions]})
            except Exception as exc:
                self.journal.log_event("engine", "ERROR",
                                       f"management error for {trade.ticket}: {exc}", {})
        return summary

    def _handle_paper_event(self, ev: Dict, symbol: str) -> None:
        ev_type = ev.get("type")
        if ev_type == "position_closed":
            trade = self.store.get_trade_by_ticket(ev.get("ticket", ""))
            if trade and trade.status == "open":
                trade.status = "closed"
                trade.closed_at = utc_now_ms()
                trade.exit_reason = f"broker_{ev.get('reason')}"
                trade.close_price = ev.get("price")
                trade.profit = float(ev.get("profit") or 0)
                risk = abs((trade.entry or 0) - (trade.sl or 0))
                if risk:
                    specs = self.broker.symbol_specs(symbol)
                    vpu = specs["tick_value"] / specs["tick_size"]
                    trade.r_multiple = round(trade.profit / (risk * vpu * trade.lots or 1), 3)
                self.store.upsert_trade(trade)
                self.store.update_daily(day_key(),
                                        realized_pnl=(self.store.get_daily(day_key())
                                                      .get("realized_pnl", 0) or 0) + trade.profit,
                                        wins=(self.store.get_daily(day_key()).get("wins", 0) or 0)
                                        + (1 if trade.profit > 0 else 0),
                                        losses=(self.store.get_daily(day_key()).get("losses", 0) or 0)
                                        + (1 if trade.profit <= 0 else 0))
                self.journal.log_trade_event("INFO", f"paper position closed ({ev.get('reason')})",
                                             {"ticket": trade.ticket, "profit": trade.profit})
                if self.web_sink:
                    try:
                        self.web_sink.push_trade(trade.to_web())
                    except Exception:
                        pass
        elif ev_type == "pending_filled":
            pending = self.store.query(
                "SELECT * FROM trades WHERE ticket=? AND status='pending'",
                (ev.get("ticket"),))
            if pending:
                trade = TradeRecord.from_row(pending[0])
                trade.status = "open"
                trade.ticket = ev.get("position_ticket")
                trade.entry = ev.get("price")
                trade.opened_at = utc_now_ms()
                self.store.upsert_trade(trade)
                self.journal.log_trade_event("INFO", "paper pending filled",
                                             {"ticket": trade.ticket, "price": trade.entry})
        elif ev_type == "pending_expired":
            self.store.execute(
                "UPDATE trades SET status='cancelled', exit_reason='pending_expired', "
                "closed_at=? WHERE ticket=? AND status='pending'",
                (utc_now_ms(), ev.get("ticket")))

    def _refresh_floating(self, trade: TradeRecord, floating: float) -> None:
        """Keep the open trade's live P/L current, and push it to the website at most
        every ~20 s per trade (and only when the value actually moved)."""
        floating = round(floating, 2)
        last = getattr(self, "_pl_pushed", None)
        if last is None:
            last = self._pl_pushed = {}
        prev_val, prev_t = last.get(trade.ticket, (None, 0.0))
        trade.profit = floating
        now = time.time()
        if prev_val == floating or now - prev_t < 20:
            return
        last[trade.ticket] = (floating, now)
        try:
            self.store.upsert_trade(trade)
            if self.web_sink:
                self.web_sink.push_trade(trade.to_web())
        except Exception:
            pass

    def _mark_closed_by_broker(self, trade: TradeRecord) -> None:
        trade.status = "closed"
        trade.closed_at = utc_now_ms()
        # Ask MT5 for what really happened (profit incl. swap/commission, price, SL/TP/manual).
        # Without this the trade was stored with profit 0 and the website showed NaN / 0% wins.
        try:
            res = self.broker.position_result(trade.ticket) if hasattr(self.broker, "position_result") else {}
        except Exception as exc:
            res = {}
            self.journal.log_event("engine", "WARNING",
                                   f"could not read deal history for {trade.ticket}: {exc}", {})
        if res.get("found"):
            trade.profit = float(res["profit"])
            trade.close_price = res.get("close_price")
            if res.get("closed_at"):
                trade.closed_at = int(res["closed_at"])
            trade.exit_reason = res.get("reason") or trade.exit_reason
            risk = abs((trade.entry or 0) - (trade.sl or 0))
            try:
                specs = self.broker.symbol_specs(self._canonical_or_same(trade.symbol))
                vpu = specs["tick_value"] / specs["tick_size"]
                if risk and vpu and trade.lots:
                    trade.r_multiple = round(trade.profit / (risk * vpu * trade.lots), 3)
            except Exception:
                pass
        if trade.exit_reason is None:
            trade.exit_reason = "closed_on_broker(sl_or_tp_or_manual)"
        self.store.upsert_trade(trade)
        self.journal.log_trade_event("INFO", "position no longer on broker - marked closed",
                                     {"ticket": trade.ticket, "exit_reason": trade.exit_reason})
        if self.web_sink:
            try:
                self.web_sink.push_trade(trade.to_web())
            except Exception:
                pass

    def _canonical_or_same(self, symbol: str) -> str:
        for canon, broker_sym in self.cfg.symbols.mapping.items():
            if broker_sym == symbol:
                return canon
        return symbol

    # ------------------------------------------------------------------
    def _manage_pendings(self, now_ms: int) -> None:
        """Cancel pending orders whose thesis died or which expired."""
        if not self.cfg.management.cancel_pending_on_thesis_invalidation:
            return
        for o in self.store.pending_orders():
            expires = o.get("expires_at")
            if expires and now_ms > int(expires):
                self.executor.cancel_pending(o["broker_ticket"], reason="expired")
                self.store.execute(
                    "UPDATE orders SET status='cancelled', cancel_reason='expired' "
                    "WHERE id=?", (o["id"],))
                self.store.execute(
                    "UPDATE trades SET status='cancelled', exit_reason='pending_expired', "
                    "closed_at=? WHERE ticket=? AND status='pending'",
                    (now_ms, o["broker_ticket"]))

    # ------------------------------------------------------------------
    def _journal_rejection(self, canonical: str, symbol: str, stage: str,
                           reason: str, setup: Optional[Setup] = None) -> None:
        payload = {
            "id": setup.id if setup else f"rej-{utc_now_ms()}",
            "ts": utc_now_ms(),
            "symbol": canonical, "direction": setup.direction.value if setup else "none",
            "kind": setup.kind.value if setup else "scan",
            "score": setup.score if setup else None,
            "decision": "rejected", "reject_stage": stage, "reject_reason": reason,
            "entry": setup.entry if setup else None,
            "sl": setup.sl if setup else None,
            "tp": setup.tp if setup else None,
            "details": {"broker_symbol": symbol},
        }
        self.journal.record_setup(payload)

    # ------------------------------------------------------------------
    # status for the website / API
    # ------------------------------------------------------------------
    def status_snapshot(self) -> Dict[str, Any]:
        state = self.bot_state
        try:
            acc = self._account()
            account = acc.masked()
            connected = True
        except BrokerError:
            account = None
            connected = False
        try:
            positions = self.broker.positions()
            pendings = self.broker.pending_orders()
        except BrokerError:
            positions, pendings = [], []
        floating = sum(p.profit for p in positions)
        day = self.store.kv_get("current_day") or day_key()
        stats = self.store.get_daily(day)
        return {
            "state": state.value,
            "mode": self.cfg.execution.mode,
            "connected": connected,
            "account": account,
            "open_positions": len(positions),
            "pending_orders": len(pendings),
            "floating_pl": round(floating, 2),
            "daily_pnl": round((stats.get("realized_pnl", 0) or 0) + floating, 2),
            "last_cycle_ms": self._last_cycle_ms,
            "cycles": self._cycle_count,
            "emergency": state is BotState.EMERGENCY_STOP,
        }

    def push_status(self) -> None:
        if self.web_sink is not None:
            try:
                self.web_sink.push_status(self.status_snapshot(), self.cfg)
            except Exception:
                pass
