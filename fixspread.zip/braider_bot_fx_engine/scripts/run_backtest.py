"""Run a backtest from the command line.

Examples:
    # export REAL history from MT5 first (see README), then:
    python scripts/run_backtest.py --symbol EURUSD
    python scripts/run_backtest.py --symbol XAUUSD --risk 0.5 --spread-points 25

Data: data/<SYMBOL>_<ENTRY_TF>.csv (see scripts/generate_demo_data.py for the
format). Results are reported separately for the TRAIN and VALIDATION
segments - if validation is much worse than train, you are curve fitting.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.config import load_config                      # noqa: E402
from backtest.backtester import Backtester, BTConfig    # noqa: E402


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--symbol", default="EURUSD")
    ap.add_argument("--data-dir", default="data")
    ap.add_argument("--risk", type=float, default=None, help="risk %% per trade")
    ap.add_argument("--spread-points", type=float, default=None)
    ap.add_argument("--slippage-points", type=float, default=None)
    ap.add_argument("--point", type=float, default=None,
                    help="point size (0.00001 forex, 0.01 XAU/BTC)")
    ap.add_argument("--tick-value-per-unit", type=float, default=None,
                    help="account currency per 1.0 price move per 1.0 lot")
    ap.add_argument("--train-fraction", type=float, default=0.7)
    a = ap.parse_args()

    cfg = load_config()
    bt = BTConfig(
        risk_pct=a.risk if a.risk is not None else cfg.risk.per_trade_risk_pct,
        spread_points=a.spread_points if a.spread_points is not None
        else cfg.execution.paper_spread_points.get(a.symbol.upper(), 15.0),
        slippage_points=a.slippage_points or cfg.execution.execution_slippage_points,
        train_fraction=a.train_fraction,
    )
    # sensible per-instrument defaults (approximations for backtests only)
    sym = a.symbol.upper()
    if a.point:
        bt.point = a.point
    elif sym in ("XAUUSD", "BTCUSD"):
        bt.point = 0.01
    if a.tick_value_per_unit:
        bt.tick_value_per_unit = a.tick_value_per_unit
    elif sym == "EURUSD":
        bt.tick_value_per_unit = 100000.0
    elif sym in ("GBPUSD", "USDCAD"):
        bt.tick_value_per_unit = 100000.0
    elif sym == "XAUUSD":
        bt.tick_value_per_unit = 100.0
    elif sym == "BTCUSD":
        bt.tick_value_per_unit = 1.0

    print(f"Backtesting {sym} ({cfg.effective_strategy(sym).entry_timeframe}) | "
          f"risk {bt.risk_pct}% | spread {bt.spread_points} pts | "
          f"slippage {bt.slippage_points} pts")
    results = Backtester(cfg, sym, a.data_dir, bt).run()
    for segment, metrics in results.items():
        print(f"\n=== {segment} ===")
        print(metrics.summary())
        for note in metrics.notes:
            print(f"  ! {note}")
    print("\nReminder: results on synthetic data mean NOTHING. Use real MT5 "
          "history, keep TRAIN/VALIDATION separated, and never optimize only "
          "for profit.")


if __name__ == "__main__":
    main()
