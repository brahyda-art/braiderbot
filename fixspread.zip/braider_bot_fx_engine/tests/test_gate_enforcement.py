"""Regression: setups that failed confluence gates must NEVER be executed."""

import logging
import tempfile
import time

import pytest

from app.config import load_config
from app.engine import Engine
from app.journal.journal import Journal
from app.state_store import StateStore
from app.strategy import confluence
from app.strategy.confluence import AnalysisBundle, Setup, SetupKind
from app.constants import Direction, Trend
from app.zones.detector import ZoneAnalysis
from app.strategy.levels import SRAnalysis
from app.strategy.structure import StructureAnalysis

logging.disable(logging.WARNING)

NOW_MS = int(time.time() * 1000)


def _cfg():
    return load_config("config/config.yaml")


def _engine(store):
    from app.market.data_feed import CsvFeed
    from app.execution.paper_broker import PaperBroker
    cfg = _cfg()
    cfg.risk.allowed_sessions = ["london", "newyork", "tokyo", "sydney"]
    feed = CsvFeed("data", require_fresh=False)
    broker = PaperBroker(feed, cfg.execution.paper_spread_points, 10000)
    return Engine(cfg, broker, feed, store, Journal(store)), broker, cfg


def _bundle():
    import os
    from app.market.candles import Candle
    closes = [1.0850 + i * 0.0001 for i in range(60)]
    candles = [Candle(time=1_700_000_000 + i * 900, open=p,
                      high=max(p, v) + 0.0002, low=min(p, v) - 0.0002, close=v)
               for i, (p, v) in enumerate(zip([1.0850] + closes[:-1], closes))]
    return AnalysisBundle(
        symbol="EURUSD", entry_tf="M15", entry_candles=candles,
        htf_bias=Trend.NEUTRAL, zones=ZoneAnalysis(), sr=SRAnalysis(),
        entry_structure=StructureAnalysis(), sweeps=[], trendlines=[],
        atr=0.0008, point_size=0.00001)


class TestGateEnforcement:
    def test_gates_failed_setup_never_executes(self, monkeypatch, tmp_path):
        store = StateStore(tmp_path / "g.db")
        eng, broker, cfg = _engine(store)
        eng.handle_command("start", {})
        eng._bootstrap_day()
        # craft a setup that passes hard checks but FAILED a confluence gate
        setup = Setup(
            id="su-gate", symbol="EURUSD", direction=Direction.LONG,
            kind=SetupKind.TREND_PULLBACK_ZONE, score=9.9,
            entry=1.0900, sl=1.0850, tp=1.1000, order_type="market",
            entry_tf="M15", gates_failed=["htf_bias_opposes"],
            thesis={"zone": {"lower": 1.0848, "upper": 1.0860},
                    "invalidation_level": 1.0848})
        monkeypatch.setattr(eng, "_scan_symbol", lambda *a, **k: [])
        res = eng._process_setup(setup, "EURUSD", "EURUSD", NOW_MS)
        assert res is None
        assert not broker.positions()

    def test_low_score_setup_never_executes(self, monkeypatch, tmp_path):
        store = StateStore(tmp_path / "g2.db")
        eng, broker, cfg = _engine(store)
        eng.handle_command("start", {})
        eng._bootstrap_day()
        st = cfg.strategy
        setup = Setup(
            id="su-low", symbol="EURUSD", direction=Direction.LONG,
            kind=SetupKind.TREND_PULLBACK_ZONE,
            score=st.min_confluence_score - 0.1,
            entry=1.0900, sl=1.0850, tp=1.1000, order_type="market",
            entry_tf="M15", gates_failed=[],
            thesis={"zone": {"lower": 1.0848, "upper": 1.0860},
                    "invalidation_level": 1.0848})
        monkeypatch.setattr(eng, "_scan_symbol", lambda *a, **k: [])
        res = eng._process_setup(setup, "EURUSD", "EURUSD", NOW_MS)
        assert res is None
        assert not broker.positions()

    def test_aligned_high_score_setup_executes(self, monkeypatch, tmp_path):
        store = StateStore(tmp_path / "g3.db")
        eng, broker, cfg = _engine(store)
        eng.handle_command("start", {})
        eng._bootstrap_day()
        st = cfg.strategy
        setup = Setup(
            id="su-ok", symbol="EURUSD", direction=Direction.LONG,
            kind=SetupKind.TREND_PULLBACK_ZONE,
            score=st.min_confluence_score + 2,
            entry=1.0900, sl=1.0850, tp=1.1000, order_type="market",
            entry_tf="M15", gates_failed=[],
            thesis={"zone": {"lower": 1.0848, "upper": 1.0860},
                    "invalidation_level": 1.0848})
        monkeypatch.setattr(eng, "_scan_symbol", lambda *a, **k: [])
        res = eng._process_setup(setup, "EURUSD", "EURUSD", NOW_MS)
        assert res is not None
        assert broker.positions()
