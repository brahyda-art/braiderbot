"""Shared fixtures for BRAIDER BOT FX engine tests (project root on sys.path)."""

from __future__ import annotations

import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(PROJECT_ROOT))

import pytest  # noqa: E402

from app.config import Config, load_config  # noqa: E402


@pytest.fixture(autouse=True)
def clean_env(monkeypatch):
    monkeypatch.delenv("BBFX_EXECUTION_MODE", raising=False)


@pytest.fixture
def base_cfg() -> Config:
    return load_config(PROJECT_ROOT / "config" / "config.yaml")
