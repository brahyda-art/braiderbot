"""Market data, daily win/loss stats, and lot-size config endpoints."""

import pytest
from fastapi.testclient import TestClient

from app.api.server import create_app
from app.state_store import StateStore, day_key
from app.execution.broker_client import BrokerError


class FakeBroker:
    def __init__(self):
        self.calls = []

    def tick(self, symbol):
        self.calls.append(symbol)
        if symbol == "BROKEN":
            raise BrokerError("feed down")
        return {"bid": 1.2345, "ask": 1.2347, "spread": 2}


class DummyEngine:
    def __init__(self):
        from app.config import Config
        self.cfg = Config()
        self.cfg.symbols.watched = ["EURUSD", "XAUUSD"]
        self.cfg.symbols.mapping = {"EURUSD": "EURUSDm", "XAUUSD": "XAUUSDm"}
        self.broker = FakeBroker()

    def status_snapshot(self):
        return {"state": "RUNNING", "mode": "paper", "connected": True,
                "account": {"balance": 1}, "open_positions": 0,
                "pending_orders": 0, "floating_pl": 0, "daily_pnl": 0,
                "last_cycle_ms": 0, "cycles": 0, "emergency": False}

    def handle_command(self, action, payload):
        return {"ok": True, "action": action, "payload": payload}


@pytest.fixture
def env(tmp_path):
    store = StateStore(tmp_path / "api.db")
    engine = DummyEngine()
    engine.cfg._api_token = "test-token-123"
    app = create_app(engine.cfg, store, lambda: engine)
    return TestClient(app), store, engine


class TestMarketPrices:
    def test_returns_tick_per_watched_symbol_using_broker_mapping(self, env):
        c, store, engine = env
        r = c.get("/market/prices")
        assert r.status_code == 200
        body = r.json()
        assert body["prices"]["EURUSD"]["ok"] is True
        assert body["prices"]["EURUSD"]["symbol"] == "EURUSDm"
        assert body["prices"]["EURUSD"]["bid"] == 1.2345
        assert engine.broker.calls == ["EURUSDm", "XAUUSDm"]

    def test_one_broken_symbol_does_not_break_the_rest(self, env):
        c, store, engine = env
        engine.cfg.symbols.mapping["XAUUSD"] = "BROKEN"
        r = c.get("/market/prices")
        assert r.status_code == 200
        body = r.json()["prices"]
        assert body["EURUSD"]["ok"] is True
        assert body["XAUUSD"]["ok"] is False
        assert "feed down" in body["XAUUSD"]["error"]


class TestDailyStats:
    def test_risk_today_includes_win_rate(self, env):
        c, store, engine = env
        day = day_key()
        store.init_daily(day, 100.0, 100.0)
        store.update_daily(day, trades=4, wins=3, losses=1, realized_pnl=12.5)
        r = c.get("/risk/today")
        assert r.status_code == 200
        stats = r.json()["stats"]
        assert stats["trades"] == 4
        assert stats["wins"] == 3
        assert stats["losses"] == 1
        assert stats["win_rate"] == 75.0

    def test_win_rate_is_none_with_no_decided_trades(self, env):
        c, store, engine = env
        day = day_key()
        store.init_daily(day, 100.0, 100.0)
        r = c.get("/risk/today")
        assert r.json()["stats"]["win_rate"] is None

    def test_stats_daily_returns_history_newest_first(self, env):
        c, store, engine = env
        store.init_daily("2026-09-20", 100.0, 100.0)
        store.update_daily("2026-09-20", trades=2, wins=1, losses=1)
        store.init_daily("2026-09-22", 100.0, 100.0)
        store.update_daily("2026-09-22", trades=3, wins=3, losses=0)
        r = c.get("/stats/daily?days=10")
        assert r.status_code == 200
        days = r.json()["days"]
        assert days[0]["day"] == "2026-09-22"
        assert days[0]["win_rate"] == 100.0
        assert days[1]["day"] == "2026-09-20"
        assert days[1]["win_rate"] == 50.0

    def test_stats_overall_aggregates_every_closed_trade_not_just_today(self, env):
        c, store, engine = env
        from app.state_store import TradeRecord
        # three trades closed on three different days: 2 wins, 1 loss overall
        for i, (day_ms, profit) in enumerate([
            (1_695_000_000_000, 10.0),
            (1_695_100_000_000, -5.0),
            (1_695_200_000_000, 7.5),
        ]):
            store.upsert_trade(TradeRecord(
                id=f"t{i}", symbol="EURUSD", side="buy", lots=0.1,
                status="closed", closed_at=day_ms, profit=profit))
        # today's daily_stats only reflects today, but overall must cover all 3
        store.init_daily(day_key(), 100.0, 100.0)
        store.update_daily(day_key(), trades=1, wins=1, losses=0, realized_pnl=7.5)
        r = c.get("/stats/overall")
        assert r.status_code == 200
        body = r.json()
        assert body["trades"] == 3
        assert body["wins"] == 2
        assert body["losses"] == 1
        assert body["win_rate"] == pytest.approx(66.7, abs=0.1)
        assert body["realized_pnl"] == pytest.approx(12.5)

    def test_stats_overall_ignores_open_trades(self, env):
        c, store, engine = env
        from app.state_store import TradeRecord
        store.upsert_trade(TradeRecord(id="open1", symbol="EURUSD", side="buy",
                                       lots=0.1, status="open"))
        r = c.get("/stats/overall")
        assert r.json()["trades"] == 0
        assert r.json()["win_rate"] is None



class TestLotSizeConfigSync:
    def test_fixed_lot_size_requires_token(self, env):
        c, store, engine = env
        r = c.post("/config/sync", json={"config": {"risk": {
            "lotSizingMode": "fixed_lot", "fixedLotSize": 0.05}}})
        assert r.status_code == 401

    def test_fixed_lot_size_applied_with_token(self, env):
        c, store, engine = env
        r = c.post("/config/sync",
                   json={"config": {"risk": {"lotSizingMode": "fixed_lot",
                                              "fixedLotSize": 0.05}}},
                   headers={"X-API-Token": "test-token-123"})
        assert r.status_code == 200
        assert r.json()["ok"] is True

    def test_per_symbol_lot_sizes_payload_reaches_engine(self, env):
        c, store, engine = env
        r = c.post("/config/sync",
                   json={"config": {"risk": {
                       "lotSizingMode": "per_symbol",
                       "fixedLotSizes": {"EURUSD": 0.1, "XAUUSD": 0.02}}}},
                   headers={"X-API-Token": "test-token-123"})
        assert r.status_code == 200
        assert r.json()["payload"]["web"]["config"]["risk"]["fixedLotSizes"] == {
            "EURUSD": 0.1, "XAUUSD": 0.02}
