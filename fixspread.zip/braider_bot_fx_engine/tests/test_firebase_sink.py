"""Firebase sink behaviour against an in-memory fake Firestore/RTDB."""

import pytest

from app.config import Config
from app.constants import BotState
from app.engine import Engine
from app.journal.journal import Journal
from app.services import firebase_sync as fs
from app.state_store import StateStore, utc_now_ms
from tests.fakes import FakeBroker


class FakeDocRef:
    def __init__(self, store, path):
        self.store, self.path = store, path

    def set(self, data, merge=False):
        self.store.writes.append((self.path, dict(data), merge))
        cur = self.store.docs.setdefault(self.path, {})
        cur.update(data) if merge else (cur.clear(), cur.update(data))

    def collection(self, name):
        return FakeCollection(self.store, f"{self.path}/{name}")


class FakeCollection:
    def __init__(self, store, path):
        self.store, self.path = store, path

    def document(self, doc_id):
        return FakeDocRef(self.store, f"{self.path}/{doc_id}")

    def add(self, data):
        self.store.writes.append((self.path + "/<auto>", dict(data), False))


class FakeFirestore:
    def __init__(self):
        self.writes, self.docs = [], {}

    def collection(self, name):
        return FakeCollection(self, name)

    def count(self, prefix):
        return sum(1 for p, _, _ in self.writes if p.startswith(prefix))


class FakeRtdbRef:
    def __init__(self, sink, path):
        self.sink, self.path = sink, path

    def set(self, data):
        self.sink.rtdb[self.path] = data


class FakeRtdb:
    def __init__(self):
        self.rtdb = {}

    def reference(self, path):
        return FakeRtdbRef(self, path)


class FakeCmdDoc:
    def __init__(self, doc_id, data):
        self.id, self._data = doc_id, data
        self.updated = None

        class Ref:
            def set(_, payload, merge=False):
                self.updated = payload
        self.reference = Ref()

    def to_dict(self):
        return dict(self._data)


@pytest.fixture
def rig(tmp_path):
    cfg = Config()
    store = StateStore(tmp_path / "s.db")
    broker = FakeBroker()
    eng = Engine(cfg, broker, None, store, Journal(store))
    store.kv_set("current_day", "2026-01-15")
    store.init_daily("2026-01-15", 10000, 10000)
    sink = fs.FirebaseSink("x.json", "proj", "uid123")
    sink._db = FakeFirestore()
    sink._rtdb = FakeRtdb()
    sink.engine = eng
    eng.web_sink = sink
    return sink, eng, cfg


def cmd(action, age_ms=0, payload=None, cid=None):
    return FakeCmdDoc(cid or f"c-{action}-{age_ms}",
                      {"action": action, "payload": payload or {},
                       "status": "pending", "createdAt": utc_now_ms() - age_ms})


class TestCommands:
    def test_fresh_start_runs_and_is_marked_done(self, rig):
        sink, eng, _ = rig
        d = cmd("start")
        sink._process_command_doc(d)
        assert eng.bot_state is BotState.RUNNING
        assert d.updated["status"] == "done"

    def test_stale_start_is_expired_not_executed(self, rig):
        sink, eng, _ = rig
        d = cmd("start", age_ms=fs.COMMAND_MAX_AGE_MS + 60_000)
        sink._process_command_doc(d)
        assert eng.bot_state is BotState.STOPPED
        assert d.updated["status"] == "expired"

    def test_stale_force_trade_and_close_all_expire(self, rig):
        sink, eng, _ = rig
        eng.handle_command("start", {})
        for a in ("force_trade", "close_all", "resume", "config_update"):
            d = cmd(a, age_ms=10 * 60_000)
            sink._process_command_doc(d)
            assert d.updated["status"] == "expired", a
        assert not eng.override_active()

    @pytest.mark.parametrize("action,state", [("stop", BotState.STOPPED),
                                              ("pause", BotState.PAUSED),
                                              ("emergency", BotState.EMERGENCY_STOP)])
    def test_stale_safe_commands_still_execute(self, rig, action, state):
        sink, eng, _ = rig
        eng.handle_command("start", {})
        d = cmd(action, age_ms=3 * 3600_000)
        sink._process_command_doc(d)
        assert eng.bot_state is state and d.updated["status"] == "done"

    def test_rejected_command_is_marked_rejected(self, rig):
        sink, eng, _ = rig
        d = cmd("force_trade", payload={"enabled": True})     # bot not running
        sink._process_command_doc(d)
        assert d.updated["status"] == "rejected"
        assert "start" in d.updated["result"].lower()

    def test_same_command_never_executed_twice(self, rig):
        sink, eng, _ = rig
        d = cmd("start", cid="dup")
        sink._process_command_doc(d)
        eng.handle_command("stop", {})
        sink._process_command_doc(cmd("start", cid="dup"))
        assert eng.bot_state is BotState.STOPPED

    def test_force_trade_via_command(self, rig):
        sink, eng, _ = rig
        eng.handle_command("start", {})
        sink._process_command_doc(cmd("force_trade", payload={"enabled": True}))
        assert eng.override_active()

    def test_status_pushed_right_after_a_command(self, rig):
        sink, eng, _ = rig
        sink._process_command_doc(cmd("start"))
        assert sink._rtdb.rtdb["live/uid123"]["status"] == "running"


class TestConfigAutoSync:
    DOC = {"config": {"symbols": ["EURUSD", "GBPUSD"], "mode": "aggressive",
                      "risk": {"perTrade": 10, "session": "all", "maxTrades": 12,
                               "lotSizingMode": "per_symbol",
                               "fixedLotSizes": {"EURUSD": 0.05}}, "version": 7},
           "mapping": {"EURUSD": "EURUSDm"}}

    def test_saved_settings_reach_the_engine(self, rig):
        sink, eng, cfg = rig
        assert sink.sync_config_doc(self.DOC) is True
        assert cfg.symbols.watched == ["EURUSD", "GBPUSD"]
        assert cfg.risk.per_trade_risk_pct == 10
        assert cfg.risk.max_trades_per_day == 12
        assert set(cfg.risk.allowed_sessions) == {"sydney", "tokyo", "london", "newyork"}
        assert cfg.risk.fixed_lot_sizes == {"EURUSD": 0.05}
        assert cfg.web_config_version == 7

    def test_unchanged_settings_not_reapplied(self, rig):
        sink, eng, cfg = rig
        sink.sync_config_doc(self.DOC)
        cfg.risk.per_trade_risk_pct = 1.0      # someone edits at runtime
        assert sink.sync_config_doc(self.DOC) is False
        assert cfg.risk.per_trade_risk_pct == 1.0

    def test_changed_settings_applied_again(self, rig):
        sink, eng, cfg = rig
        sink.sync_config_doc(self.DOC)
        newer = {**self.DOC, "config": {**self.DOC["config"], "version": 8,
                 "risk": {**self.DOC["config"]["risk"], "perTrade": 2}}}
        assert sink.sync_config_doc(newer) is True
        assert cfg.risk.per_trade_risk_pt if False else cfg.risk.per_trade_risk_pct == 2
        assert cfg.web_config_version == 8

    def test_empty_or_missing_config_ignored(self, rig):
        sink, *_ = rig
        assert sink.sync_config_doc({}) is False
        assert sink.sync_config_doc(None) is False
        assert sink.sync_config_doc({"config": {}}) is False

    def test_bad_values_never_weaken_limits(self, rig):
        sink, eng, cfg = rig
        before = (cfg.risk.max_daily_loss_pct, cfg.risk.max_trades_per_day)
        sink.sync_config_doc({"config": {"risk": {"maxDailyLoss": 0, "maxTrades": -3,
                                                  "perTrade": "abc", "minRR": float("nan")}}})
        assert (cfg.risk.max_daily_loss_pct, cfg.risk.max_trades_per_day) == before

    def test_config_update_command_also_applies(self, rig):
        sink, eng, cfg = rig
        d = cmd("config_update", payload={"web": self.DOC})
        sink._process_command_doc(d)
        assert cfg.risk.per_trade_risk_pct == 10 and d.updated["status"] == "done"

    def test_scalping_toggle_and_trade_limits_propagate(self, rig):
        sink, eng, cfg = rig
        sink.sync_config_doc({"config": {"scalpingEnabled": True,
                                         "risk": {"maxTrades": 20, "maxSimul": 3}}})
        assert cfg.scalping.enabled
        assert cfg.scalping.max_trades_per_day == 20
        assert cfg.scalping.max_simultaneous_positions == 3


class TestWriteThrottling:
    def snap(self, eng):
        return eng.status_snapshot()

    def test_unchanged_status_not_rewritten_every_beat(self, rig):
        sink, eng, cfg = rig
        for _ in range(30):
            sink.push_status(self.snap(eng), cfg)
        assert sink._db.count("users/uid123") <= 1

    def test_state_change_is_written_immediately(self, rig):
        sink, eng, cfg = rig
        sink.push_status(self.snap(eng), cfg)
        eng.handle_command("start", {})
        sink.push_status(self.snap(eng), cfg)
        writes = [w for w in sink._db.writes if w[0] == "users/uid123"]
        assert writes[-1][1]["bot"]["status"] == "running"

    def test_live_numbers_go_to_rtdb_every_time(self, rig):
        sink, eng, cfg = rig
        sink.push_status(self.snap(eng), cfg)
        assert sink._rtdb.rtdb["live/uid123"]["balance"] == 10000.0

    def test_rtdb_carries_signals_limits_override(self, rig):
        sink, eng, cfg = rig
        eng.handle_command("start", {})
        from tests.test_automation_limits import mk_setup
        eng._record_signal(mk_setup(), "EURUSD", "blocked", "limit", "daily_loss_check", 1)
        sink.push_status(self.snap(eng), cfg)
        live = sink._rtdb.rtdb["live/uid123"]
        assert live["signals"][0]["symbol"] == "EURUSD"
        assert live["limits"] is not None
        assert live["scanning"] is True and live["override"] is False


class TestLogFiltering:
    def test_noise_is_not_written(self, rig):
        sink, *_ = rig
        for i in range(50):
            sink.push_log("INFO", f"setup rejected at spread_check #{i}", {"_cat": "risk"})
        assert sink._db.count("users/uid123/logs") == 0

    def test_important_lines_are_written(self, rig):
        sink, *_ = rig
        sink.push_log("WARNING", "data error", {"_cat": "engine"})
        sink.push_log("INFO", "state change STOPPED -> RUNNING", {"_cat": "engine"})
        sink.push_log("INFO", "order filled", {"_cat": "trade"})
        sink.push_log("INFO", "config", {"action": "CONFIG_APPLIED", "_cat": "engine"})
        assert sink._db.count("users/uid123/logs") == 4

    def test_identical_warning_deduplicated(self, rig):
        sink, *_ = rig
        for _ in range(40):
            sink.push_log("ERROR", "bridge unreachable", {"_cat": "engine"})
        assert sink._db.count("users/uid123/logs") == 1

    def test_hard_rate_cap(self, rig):
        sink, *_ = rig
        for i in range(200):
            sink.push_log("ERROR", f"distinct failure {i}", {"_cat": "engine"})
        assert sink._db.count("users/uid123/logs") == fs.LOG_MAX_PER_MINUTE

    def test_action_is_kept_for_the_website_feed(self, rig):
        sink, *_ = rig
        sink.push_log("WARNING", "daily loss limit", {"action": "LIMIT_REACHED",
                                                      "stage": "daily_loss_check", "_cat": "risk"})
        _, doc, _ = sink._db.writes[-1]
        assert doc["action"] == "LIMIT_REACHED" and "daily loss limit" in doc["detail"]


class TestStatusMapping:
    @pytest.mark.parametrize("cmd_name,expected", [("start", "running"), ("pause", "paused"),
                                                   ("stop", "stopped"), ("emergency", "emergency")])
    def test_every_state_is_reported_correctly(self, rig, cmd_name, expected):
        sink, eng, cfg = rig
        eng.handle_command(cmd_name, {})
        sink.push_status(eng.status_snapshot(), cfg)
        assert sink._rtdb.rtdb["live/uid123"]["status"] == expected
