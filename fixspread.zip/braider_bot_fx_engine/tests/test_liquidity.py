"""Liquidity sweep detection tests (spec section 10).

Not every wick is a sweep: need penetration >= threshold AND a close back.
"""

import pytest

from app.constants import Direction
from app.liquidity.sweeps import detect_sweeps, latest_sweep
from app.market.candles import Candle
from app.strategy.swings import find_swings


CLOSES = [105, 104, 103, 102, 101, 100, 99.5, 99.0,     # low A
          99.8, 100.5, 101.2,                            # high
          100.4, 99.8, 99.2,                             # low B (higher low)
          100.0, 100.8, 101.5]


def build():
    candles = []
    prev = CLOSES[0]
    for i, v in enumerate(CLOSES):
        o = prev
        candles.append(Candle(time=1_700_000_000 + i * 900, open=o,
                              high=max(o, v) + 0.1, low=min(o, v) - 0.1, close=v))
        prev = v
    return candles


def with_sweep(candles, close_above=99.6, dip=0.5):
    lowest_swing = 99.0
    last = candles[-1]
    candles.append(Candle(time=last.time + 900, open=last.close,
                          high=last.close + 0.3, low=lowest_swing - dip,
                          close=close_above))
    return candles


class TestSweepDetection:
    def test_sweep_of_lows_is_bullish(self):
        candles = with_sweep(build())
        swings = find_swings(candles, 2)
        assert len(swings) >= 2, "test data must contain confirmed swings"
        sweeps = detect_sweeps(candles, swings, "M15", min_penetration_atr=0.05)
        assert sweeps, "expected a sweep to be detected"
        assert any(s.direction is Direction.LONG for s in sweeps)
        s = [x for x in sweeps if x.direction is Direction.LONG][-1]
        assert s.sweep_price <= 99.0
        assert s.penetration > 0

    def test_breakdown_close_below_level_is_not_a_bullish_sweep(self):
        candles = build()
        last = candles[-1]
        breakdown = Candle(time=last.time + 900, open=last.close,
                           high=last.close + 0.1, low=98.5, close=98.4)
        candles.append(breakdown)
        swings = find_swings(candles, 2)
        sweeps = detect_sweeps(candles, swings, "M15", min_penetration_atr=0.05)
        bullish = [s for s in sweeps if s.direction is Direction.LONG]
        assert all(s.time != breakdown.time for s in bullish)

    def test_sweep_of_highs_is_bearish(self):
        candles = build()
        last = candles[-1]
        # sweep above the swing high 101.2+0.1 wick = 101.3, close back below
        sweep = Candle(time=last.time + 900, open=last.close,
                       high=101.8, low=last.close - 0.2, close=101.1)
        candles.append(sweep)
        swings = find_swings(candles, 2)
        sweeps = detect_sweeps(candles, swings, "M15", min_penetration_atr=0.05)
        assert any(s.direction is Direction.SHORT and s.swept_level >= 101.2
                   for s in sweeps)


class TestSweepQuery:
    def test_latest_sweep_filters_direction_and_time(self):
        candles = with_sweep(build())
        swings = find_swings(candles, 2)
        sweeps = detect_sweeps(candles, swings, "M15", min_penetration_atr=0.05)
        future = candles[-1].time + 1
        got = latest_sweep(sweeps, Direction.LONG, since_time=future)
        assert got is None or got.time >= future
        past = 0
        assert latest_sweep(sweeps, Direction.LONG, since_time=past) is not None
