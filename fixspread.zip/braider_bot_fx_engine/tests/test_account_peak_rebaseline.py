"""account_peak_equity belongs to one specific account.

Reproduces a real VPS failure: the engine ran in PAPER mode (simulated
10,000 balance), persisted account_peak_equity=10000, then was switched to a
real ~111 USD demo account. The stale peak was kept, so every setup that got
past position sizing died at account_dd_check with 'account drawdown 98.89%'.
"""

from app.config import load_config
from app.constants import BotState
from app.engine import Engine
from app.journal.journal import Journal
from app.risk.risk_engine import RiskContext, RiskEngine
from app.state_store import StateStore
from tests.fakes import FakeBroker


def _engine(tmp_path, equity):
    cfg = load_config()
    store = StateStore(tmp_path / "peak.db")
    broker = FakeBroker()
    broker.balance = equity
    broker.equity = equity
    engine = Engine(cfg, broker, None, store, Journal(store))
    return engine, store, broker, cfg


def test_stale_peak_from_other_account_is_rebaselined(tmp_path):
    engine, store, broker, cfg = _engine(tmp_path, equity=111.40)
    try:
        store.kv_set("account_peak_equity", 10000.0)   # left over from paper
        engine._bootstrap_day()
        assert store.kv_get("account_peak_equity") == 111.40
        risk = RiskEngine(cfg, store)
        dd = risk.account_drawdown_pct(RiskContext(bot_state=BotState.RUNNING, balance=111.40, equity=111.40, day='d'))
        assert dd == 0.0
    finally:
        store.close()


def test_real_drawdown_on_same_account_is_still_measured(tmp_path):
    engine, store, broker, cfg = _engine(tmp_path, equity=1000.0)
    try:
        engine._bootstrap_day()                       # peak 1000 recorded
        broker.balance = broker.equity = 850.0        # same account loses 15%
        engine._bootstrap_day()
        assert store.kv_get("account_peak_equity") == 1000.0   # NOT reset
        risk = RiskEngine(cfg, store)
        dd = risk.account_drawdown_pct(RiskContext(bot_state=BotState.RUNNING, balance=850.0, equity=850.0, day='d'))
        assert round(dd, 1) == 15.0
        assert dd >= cfg.effective_risk().max_account_drawdown_pct  # still blocks
    finally:
        store.close()


def test_peak_still_rises_on_same_account(tmp_path):
    engine, store, broker, cfg = _engine(tmp_path, equity=1000.0)
    try:
        engine._bootstrap_day()
        broker.balance = broker.equity = 1200.0
        engine._bootstrap_day()
        assert store.kv_get("account_peak_equity") == 1200.0
    finally:
        store.close()
