"""Account API tests against a FAKE MT5 bridge (no real MT5, no orders)."""
import json
import logging
import tempfile
from pathlib import Path
from types import SimpleNamespace

import pytest
from fastapi.testclient import TestClient

from app.api.server import create_app
from app.execution.broker_client import AccountInfo, BrokerError
from app.services.account_manager import AccountManager

PW1, PW2 = "S3cretPass-one", "S3cretPass-two"
H = {"X-API-Token": "tok"}


class FakeBroker:
    """Mimics the bridge: only logins in `accounts` succeed with the right pw."""
    def __init__(self):
        self.accounts = {"12345678": (PW1, "Exness-MT5Trial9", "demo"),
                         "87654321": (PW2, "Exness-MT5Trial9", "demo"),
                         "55555555": ("realpw", "Exness-Real9", "real")}
        self.cur = None
        self.calls = []

    def connect_account(self, login, password, server):
        self.calls.append(("connect", login))
        rec = self.accounts.get(str(login))
        if not rec or rec[0] != password or rec[1].lower() != server.lower():
            raise BrokerError("bridge error 400: invalid account credentials")
        self.cur = str(login)
        return {"ok": True}

    def disconnect_account(self):
        self.calls.append(("disconnect", self.cur)); self.cur = None
        return {"ok": True}

    def account(self):
        if not self.cur:
            raise BrokerError("not connected")
        pw, srv, mode = self.accounts[self.cur]
        return AccountInfo(login=self.cur, server=srv, currency="USD", mode=mode)


class FakeEngine:
    def __init__(self, broker):
        self.broker = broker
        self.snap = {"state": "STOPPED", "open_positions": 0, "pending_orders": 0}

    def status_snapshot(self):
        return dict(self.snap)


@pytest.fixture()
def env(monkeypatch, tmp_path):
    monkeypatch.setenv("FIREBASE_USER_UID", "uid-braider")
    monkeypatch.setattr("app.api.server._firebase_uid_from_request", lambda r: None, raising=False)
    cfg = SimpleNamespace(api=SimpleNamespace(rate_limit_per_minute=10000), _api_token="tok")
    broker = FakeBroker(); eng = FakeEngine(broker)
    mgr = AccountManager(tmp_path / "accounts.json")
    app = create_app(cfg, store=None, get_engine=lambda: eng, account_manager=mgr)
    return SimpleNamespace(c=TestClient(app), broker=broker, eng=eng, mgr=mgr, path=tmp_path / "accounts.json")


def connect(env, login="12345678", pw=PW1, **kw):
    body = {"broker": "Exness (Demo)", "server": "Exness-MT5Trial9", "login": login, "password": pw, "type": "Demo"}
    body.update(kw)
    return env.c.post("/accounts/connect", json=body, headers=H)


def test_requires_auth(env):
    assert env.c.get("/accounts").status_code == 401
    assert env.c.post("/accounts/connect", json={}).status_code == 401
    assert env.c.post("/accounts/select", json={"account_id": "x"}).status_code == 401


def test_connect_returns_frontend_shape_and_no_password(env):
    r = connect(env)
    assert r.status_code == 200, r.text
    d = r.json()
    assert d["connected"] is True and d["currency"] == "USD" and d["type"] == "Demo"
    assert d["masked"] == "12••••678" and d["account_id"]
    assert PW1 not in r.text and "12345678" not in r.text


def test_password_never_on_disk(env):
    connect(env)
    assert PW1 not in env.path.read_text()
    assert "password" not in json.loads(env.path.read_text())["accounts"][0]


def test_password_not_in_logs_or_422(env, caplog):
    caplog.set_level(logging.DEBUG)
    r = env.c.post("/accounts/connect", headers=H,
                   json={"broker": "x", "server": "s", "login": 5, "password": PW1, "type": {"bad": 1}})
    assert r.status_code == 422 and PW1 not in r.text
    connect(env, pw="wrong-pass-1")  # failure path
    assert PW1 not in caplog.text and "wrong-pass-1" not in caplog.text


def test_wrong_password_fails_and_offline(env):
    r = connect(env, pw="nope-nope")
    assert r.status_code == 400 and "nope-nope" not in r.text
    assert env.c.get("/accounts", headers=H).json()["accounts"][0]["connected"] is False


def test_live_and_real_accounts_refused(env):
    assert connect(env, type="Live").status_code == 403
    r = connect(env, login="55555555", pw="realpw", server="Exness-Real9")
    assert r.status_code == 403 and env.broker.cur is None      # logged back out


def test_bad_login_format(env):
    assert connect(env, login="12ab").status_code == 422


def test_two_accounts_select_switches_terminal(env):
    a1 = connect(env).json()["account_id"]
    a2 = connect(env, login="87654321", pw=PW2).json()["account_id"]
    assert a1 != a2 and env.broker.cur == "87654321"
    lst = env.c.get("/accounts", headers=H).json()
    assert lst["active_account_id"] == a2
    assert {a["account_id"]: a["connected"] for a in lst["accounts"]} == {a1: False, a2: True}
    r = env.c.post("/accounts/select", json={"account_id": a1}, headers=H)
    assert r.status_code == 200 and r.json()["switched"] and env.broker.cur == "12345678"
    assert env.c.get("/accounts", headers=H).json()["active_account_id"] == a1


def test_select_needs_password_after_restart(env):
    a1 = connect(env).json()["account_id"]
    connect(env, login="87654321", pw=PW2)
    mgr2 = AccountManager(env.path)              # simulate engine restart
    assert mgr2.password_for(a1) is None and mgr2.list_accounts("uid-braider")["active_account_id"] is None


def test_disconnect_then_reconnect_same_id(env):
    a1 = connect(env).json()["account_id"]
    r = env.c.post(f"/accounts/{a1}/disconnect", headers=H)
    assert r.status_code == 200 and r.json()["connected"] is False and env.broker.cur is None
    assert env.c.post("/accounts/select", json={"account_id": a1}, headers=H).status_code == 409  # pw forgotten
    again = connect(env).json()
    assert again["account_id"] == a1 and again["connected"] is True                     # no duplicate


def test_delete_removes_from_workspace_only(env):
    a1 = connect(env).json()["account_id"]
    r = env.c.delete(f"/accounts/{a1}", headers=H)
    assert r.status_code == 200 and env.c.get("/accounts", headers=H).json()["accounts"] == []
    assert ("disconnect", "12345678") in env.broker.calls          # only the terminal session, not the broker account


def test_switch_blocked_while_bot_running_or_positions_open(env):
    a1 = connect(env).json()["account_id"]
    connect(env, login="87654321", pw=PW2)
    env.eng.snap["state"] = "RUNNING"
    assert env.c.post("/accounts/select", json={"account_id": a1}, headers=H).status_code == 409
    env.eng.snap.update(state="STOPPED", open_positions=1)
    assert env.c.post("/accounts/select", json={"account_id": a1}, headers=H).status_code == 409
    assert env.broker.cur == "87654321"


def test_owner_isolation(env):
    a1 = connect(env).json()["account_id"]
    # a second user's view of the same store
    assert env.mgr.list_accounts("uid-someone-else")["accounts"] == []
    assert env.mgr.get(a1, "uid-someone-else") is None
    assert env.mgr.public(a1, "uid-someone-else") is None
    assert env.mgr.get(a1, "uid-braider") is not None
