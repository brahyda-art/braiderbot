"""Per-symbol entry-timeframe map (spec: EURUSD/USDCAD=M5, GBPUSD/BTCUSD=M1,
XAUUSD=M1 entry + M5 higher-timeframe bias)."""

import pytest

from app.config import load_config
from app.state_store import StateStore, TradeRecord


@pytest.fixture
def cfg():
    return load_config()


class TestEffectiveStrategyPerSymbol:
    def test_eurusd_resolves_to_m5(self, cfg):
        assert cfg.effective_strategy("EURUSD").entry_timeframe == "M5"

    def test_usdcad_resolves_to_m5(self, cfg):
        assert cfg.effective_strategy("USDCAD").entry_timeframe == "M5"

    def test_gbpusd_resolves_to_m1(self, cfg):
        assert cfg.effective_strategy("GBPUSD").entry_timeframe == "M1"

    def test_btcusd_resolves_to_m1(self, cfg):
        assert cfg.effective_strategy("BTCUSD").entry_timeframe == "M1"

    def test_xauusd_entry_is_m1_bias_is_m5(self, cfg):
        st = cfg.effective_strategy("XAUUSD")
        assert st.entry_timeframe == "M1"
        assert st.htf_bias_timeframes == ["M5"]

    def test_lowercase_canonical_still_matches(self, cfg):
        # config.yaml keys symbol_overrides by canonical upper-case symbol;
        # callers may pass either case.
        assert cfg.effective_strategy("eurusd").entry_timeframe == "M5"

    def test_unmapped_symbol_keeps_default_m15(self, cfg):
        # M15 must not be silently selected for the 5 mapped symbols, but an
        # unmapped one should still fall back to the configured default.
        assert cfg.effective_strategy("EURJPY").entry_timeframe == "M15"

    def test_no_symbol_keeps_old_global_behaviour(self, cfg):
        # Backward compatibility: callers with no specific symbol (existing
        # behaviour before this change) still get the plain default.
        assert cfg.effective_strategy().entry_timeframe == "M15"

    def test_m15_is_not_selected_for_any_of_the_five_mapped_symbols(self, cfg):
        for symbol in ("EURUSD", "USDCAD", "GBPUSD", "BTCUSD", "XAUUSD"):
            assert cfg.effective_strategy(symbol).entry_timeframe != "M15"

    def test_symbol_override_does_not_mutate_shared_config(self, cfg):
        # effective_strategy() must return a copy, not the live object -
        # otherwise one symbol's override would leak into another's.
        cfg.effective_strategy("GBPUSD")
        assert cfg.strategy.entry_timeframe == "M15"
        assert cfg.effective_strategy("EURUSD").entry_timeframe == "M5"
        assert cfg.effective_strategy("USDCAD").entry_timeframe == "M5"

    def test_m1_bars_requirement_present(self, cfg):
        # Without this, engine._scan_symbol's `if tf not in cfg.strategy.bars:
        # continue` would silently skip fetching M1 candles entirely.
        assert cfg.strategy.bars.get("M1", 0) >= 60

    def test_symbol_override_applied_after_scalping_mode(self, cfg):
        # Global scalping mode substitutes entry_timeframe from
        # ScalpingConfig first; a symbol override must still win afterwards.
        cfg.scalping.enabled = True
        cfg.scalping.entry_timeframe = "M15"
        st = cfg.effective_strategy("GBPUSD")
        assert st.entry_timeframe == "M1"  # override beats scalping default
        # a symbol with no override falls through to the scalping value
        st_other = cfg.effective_strategy("EURJPY")
        assert st_other.entry_timeframe == "M15"


class TestBacktesterUsesPerSymbolTimeframe:
    def test_backtester_error_message_reports_correct_entry_tf(self, cfg, tmp_path):
        """With no CSV data present, Backtester.run() raises SystemExit whose
        message names the ACTUAL per-symbol entry timeframe - proving it
        reads effective_strategy(symbol), not the raw global cfg.strategy
        (which would always say M15)."""
        from backtest.backtester import Backtester

        with pytest.raises(SystemExit) as exc:
            Backtester(cfg, "GBPUSD", str(tmp_path)).run()
        assert "GBPUSD M1" in str(exc.value)
        assert "M15" not in str(exc.value)

        with pytest.raises(SystemExit) as exc:
            Backtester(cfg, "EURUSD", str(tmp_path)).run()
        assert "EURUSD M5" in str(exc.value)

        with pytest.raises(SystemExit) as exc:
            Backtester(cfg, "XAUUSD", str(tmp_path)).run()
        assert "XAUUSD M1" in str(exc.value)

    def test_short_validation_segment_is_flagged_not_silently_zero(self, cfg, tmp_path, capsys):
        """Regression: with train_fraction=0.7 and warmup=200 hard-coded in
        _run_segment, a symbol with only ~600 bars gets a VALIDATION segment
        of ~180 bars - below warmup, so the loop body never runs even once.
        That used to come back as an ordinary-looking 'no trades' result,
        indistinguishable from the strategy genuinely finding nothing. It
        must now say clearly that the segment was too short."""
        import csv as _csv
        from backtest.backtester import Backtester

        path = tmp_path / "EURUSD_M5.csv"
        with path.open("w", newline="") as fh:
            w = _csv.writer(fh)
            w.writerow(["time", "open", "high", "low", "close", "volume"])
            for i in range(600):
                px = 1.10 + (i % 20) * 0.0001
                w.writerow([1_700_000_000 + i * 300, px, px + 0.0002,
                           px - 0.0002, px, 100])

        metrics = Backtester(cfg, "EURUSD", str(tmp_path)).run()
        assert metrics["VALIDATION"].trades == 0
        out = capsys.readouterr().out
        assert "segment too short" in out
        assert "NOT a real 0-trade result" in out

    def test_normal_length_segment_runs_without_the_short_segment_warning(
            self, cfg, tmp_path, capsys):
        """A VALIDATION segment comfortably above warmup must NOT print the
        short-segment warning - only genuinely too-short segments should."""
        import csv as _csv
        from backtest.backtester import Backtester

        path = tmp_path / "EURUSD_M5.csv"
        with path.open("w", newline="") as fh:
            w = _csv.writer(fh)
            w.writerow(["time", "open", "high", "low", "close", "volume"])
            for i in range(3000):
                px = 1.10 + (i % 20) * 0.0001
                w.writerow([1_700_000_000 + i * 300, px, px + 0.0002,
                           px - 0.0002, px, 100])

        Backtester(cfg, "EURUSD", str(tmp_path)).run()
        out = capsys.readouterr().out
        assert "segment too short" not in out


class TestManageOpenTradesUsesPerSymbolTimeframe:
    """app/engine.py _manage_open_trades() previously fetched management
    candles at the raw global cfg.strategy.entry_timeframe (always M15),
    even after the per-symbol map was added - an open GBPUSD trade would
    have been managed against M15 candles instead of its own M1. Verifies
    the fix: it now asks for the trade's own symbol's entry timeframe."""

    def _engine(self, tmp_path, cfg):
        from app.engine import Engine
        from app.journal.journal import Journal
        from tests.fakes import FakeBroker
        store = StateStore(tmp_path / "mgmt.db")
        broker = FakeBroker()
        engine = Engine(cfg, broker, RecordingFeed(), store, Journal(store))
        return engine, broker, store

    def _open_trade_and_position(self, engine, broker, store, canonical, ticket):
        from app.execution.broker_client import Position
        broker_symbol = engine.cfg.symbols.mapping.get(canonical, canonical)
        trade = TradeRecord(id=f"tr-{ticket}", symbol=broker_symbol, side="buy",
                            lots=0.1, entry=1.0, sl=0.9, tp=1.2, status="open",
                            ticket=ticket, opened_at=1_700_000_000_000,
                            thesis={}, management={})
        store.upsert_trade(trade)
        broker._positions[ticket] = Position(ticket=ticket, symbol=broker_symbol,
                                             side="buy", lots=0.1, open_price=1.0,
                                             sl=0.9, tp=1.2)

    def test_gbpusd_open_trade_managed_with_m1_not_m15(self, cfg, tmp_path):
        engine, broker, store = self._engine(tmp_path, cfg)
        self._open_trade_and_position(engine, broker, store, "GBPUSD", "501")
        engine._manage_open_trades(1_700_100_000_000)
        assert engine.feed.calls, "get_rates was never called for the open trade"
        symbol, tf, _ = engine.feed.calls[-1]
        assert symbol == "GBPUSD"
        assert tf == "M1"

    def test_eurusd_open_trade_managed_with_m5_not_m15(self, cfg, tmp_path):
        engine, broker, store = self._engine(tmp_path, cfg)
        self._open_trade_and_position(engine, broker, store, "EURUSD", "502")
        engine._manage_open_trades(1_700_100_000_000)
        symbol, tf, _ = engine.feed.calls[-1]
        assert symbol == "EURUSD"
        assert tf == "M5"

    def test_xauusd_open_trade_managed_with_m1(self, cfg, tmp_path):
        engine, broker, store = self._engine(tmp_path, cfg)
        self._open_trade_and_position(engine, broker, store, "XAUUSD", "503")
        engine._manage_open_trades(1_700_100_000_000)
        symbol, tf, _ = engine.feed.calls[-1]
        assert symbol == "XAUUSD"
        assert tf == "M1"


class RecordingFeed:
    """Minimal DataFeed double that just records get_rates() calls."""

    def __init__(self):
        self.calls = []

    def get_rates(self, symbol, timeframe, count):
        self.calls.append((symbol, timeframe, count))
        return []

    def is_fresh(self, symbol, timeframe, candles, max_age_bars):
        return True, 0


class TestScanSymbolUsesPerSymbolStructureParams:
    """Regression: app/engine.py _scan_symbol computed the correct
    per-symbol `st` but then called find_swings/analyze_structure/
    detect_sweeps/analyze_trendlines/build_htf_context with the RAW global
    self.cfg.strategy.swing_strength/atr_period instead of st.swing_strength/
    st.atr_period - so a per-symbol swing_strength override (e.g. GBPUSD=3,
    to reduce M1 fractal noise) was silently ignored by every one of those
    calls even though the backtester already honoured it correctly."""

    def test_find_swings_called_with_symbols_own_swing_strength(self, tmp_path):
        import csv as _csv
        from unittest.mock import patch
        from app.config import load_config
        from app.engine import Engine
        from app.journal.journal import Journal
        from tests.fakes import FakeBroker

        cfg = load_config()
        assert cfg.effective_strategy("GBPUSD").swing_strength == 3  # sanity

        data_dir = tmp_path / "data"
        data_dir.mkdir()
        path = data_dir / "GBPUSD_M1.csv"
        with path.open("w", newline="") as fh:
            w = _csv.writer(fh)
            w.writerow(["time", "open", "high", "low", "close", "volume"])
            for i in range(120):
                px = 1.25 + (i % 15) * 0.0001
                w.writerow([1_700_000_000 + i * 60, px, px + 0.0003,
                           px - 0.0003, px, 100])

        from app.market.data_feed import CsvFeed
        feed = CsvFeed(data_dir)
        store = StateStore(tmp_path / "engine.db")
        broker = FakeBroker()
        engine = Engine(cfg, broker, feed, store, Journal(store))

        import app.engine as engine_module
        with patch.object(engine_module, "find_swings",
                          wraps=engine_module.find_swings) as spy:
            engine._scan_symbol("GBPUSD", 1_700_100_000_000)
            assert spy.called
            called_swing_strength = spy.call_args[0][1]
            assert called_swing_strength == 3, (
                "find_swings was called with the wrong swing_strength - "
                "_scan_symbol is bypassing the per-symbol override again")
