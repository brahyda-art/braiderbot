"""Symbol mapping (broker names differ, spec section 4)."""

from app.config import Config


class TestMapping:
    def test_default_mapping(self, base_cfg):
        assert base_cfg.symbols.mapping["EURUSD"] == "EURUSD"

    def test_custom_mapping_applied(self):
        cfg = Config()
        cfg.symbols.mapping["XAUUSD"] = "XAUUSDm"
        cfg.symbols.mapping["BTCUSD"] = "BTCUSD.a"
        assert cfg.symbols.mapping["XAUUSD"] == "XAUUSDm"

    def test_engine_maps_canonical_to_broker(self, base_cfg):
        from app.engine import Engine
        from tests.fakes import FakeBroker
        from app.state_store import StateStore
        from app.journal.journal import Journal
        import tempfile, os
        with tempfile.TemporaryDirectory() as td:
            store = StateStore(os.path.join(td, "t.db"))
            try:
                broker = FakeBroker()
                broker.symbol_specs = lambda s: {"symbol": s, "point": 0.01,
                                                 "tick_size": 0.01, "tick_value": 1.0}
                base_cfg.symbols.mapping["XAUUSD"] = "XAUUSDm"
                eng = Engine(base_cfg, broker, None, store, Journal(store))
                assert eng.broker_symbol("XAUUSD") == "XAUUSDm"
                assert eng.broker_symbol("EURUSD") == "EURUSD"
            finally:
                # StateStore keeps a live sqlite3 connection open; on Windows
                # (unlike POSIX) TemporaryDirectory's cleanup can't delete a
                # file that's still open, so it must be closed before the
                # `with` block exits or this fails with WinError 32 there
                # while passing everywhere else.
                store.close()

    def test_web_mapping_merge(self, base_cfg):
        from app.config import apply_web_config
        applied = apply_web_config(base_cfg, {
            "mapping": {"XAUUSD": "XAUUSDm", "": "ignore-me", 5: "nope"},
        })
        assert base_cfg.symbols.mapping["XAUUSD"] == "XAUUSDm"
        assert "symbols.mapping" in applied

    def test_web_risk_merge(self, base_cfg):
        from app.config import apply_web_config
        apply_web_config(base_cfg, {"config": {
            "mode": "conservative",
            "risk": {"perTrade": 0.5, "maxDailyLoss": 2, "maxSpread": 30,
                     "session": "london", "junk": "x"},
            "symbols": ["EURUSD", "XAUUSD"],
        }})
        assert base_cfg.risk.per_trade_risk_pct == 0.5
        assert base_cfg.risk.max_daily_loss_pct == 2.0
        assert base_cfg.risk.max_spread_points == 30
        assert base_cfg.strategy.mode == "conservative"
        assert base_cfg.symbols.watched == ["EURUSD", "XAUUSD"]

    def test_web_config_ignores_junk(self, base_cfg):
        from app.config import apply_web_config
        before = base_cfg.execution.mode
        apply_web_config(base_cfg, {"config": {"mode": "<script>x</script>",
                                               "risk": {"perTrade": "banana"}}})
        assert base_cfg.execution.mode == before
        assert base_cfg.risk.per_trade_risk_pct == 1.0
