"""SMC-pullback scalping: structure shift + OTE retracement + resting limit
order. This method must stay fully separate from the swing confluence
engine (no zone/SR/FVG/general-sweep involvement) and must place a resting
buy_limit/sell_limit at the OTE price, never a market order, whenever price
hasn't reached the zone yet."""

from dataclasses import dataclass

import pytest

from app.config import ScalpingConfig
from app.constants import Direction, StructureEventKind
from app.market.candles import Candle
from app.strategy.scalp_smc import (OTE_MAX_RETRACEMENT, OTE_MIN_RETRACEMENT,
                                    build_scalp_setups, find_scalp_candidate)
from app.strategy.structure import StructureAnalysis, StructureEvent


def candles_from(vals, start=1_700_000_000, tf=300):
    out = []
    prev = vals[0]
    for i, v in enumerate(vals):
        out.append(Candle(time=start + i * tf, open=prev,
                          high=max(prev, v) + 0.02, low=min(prev, v) - 0.02,
                          close=v))
        prev = v
    return out


def bullish_impulse_then_pullback(retracement=0.70, n_impulse=20):
    """Impulse from 100 -> 120 (leg = 20), then pull back `retracement` of
    that leg on the final candle."""
    vals = [100 + i * (20.0 / n_impulse) for i in range(n_impulse)]
    impulse_end = vals[-1]
    impulse_start = vals[0]
    leg = impulse_end - impulse_start
    pulled = impulse_end - retracement * leg
    vals.append(pulled)
    return candles_from(vals)


def mss_event(direction, index, time_, level=110.0):
    return StructureEvent(kind=StructureEventKind.MSS, direction=direction,
                          level=level, index=index, time=time_, close=level + 0.5)


class TestOTEDetection:
    def test_ote_pullback_with_recent_mss_is_detected(self):
        candles = bullish_impulse_then_pullback(retracement=0.70)
        structure = StructureAnalysis(
            events=[mss_event(Direction.LONG, len(candles) - 4, candles[-4].time)],
            protected_low=candles[0].low,
        )
        cand = find_scalp_candidate(candles, Direction.LONG, structure)
        assert cand is not None
        assert OTE_MIN_RETRACEMENT <= cand.retracement <= OTE_MAX_RETRACEMENT
        # OTE price must sit BETWEEN impulse_start and impulse_end, closer to
        # the start side for a deep (0.70) retracement.
        assert cand.impulse_start < cand.ote_price < cand.impulse_end

    def test_pullback_outside_ote_band_rejected(self):
        # Only 30% retracement - far too shallow for OTE (needs 62-79%).
        candles = bullish_impulse_then_pullback(retracement=0.30)
        structure = StructureAnalysis(
            events=[mss_event(Direction.LONG, len(candles) - 4, candles[-4].time)],
            protected_low=candles[0].low,
        )
        cand = find_scalp_candidate(candles, Direction.LONG, structure)
        assert cand is None

    def test_no_structure_shift_no_candidate(self):
        candles = bullish_impulse_then_pullback(retracement=0.70)
        structure = StructureAnalysis(events=[], protected_low=candles[0].low)
        cand = find_scalp_candidate(candles, Direction.LONG, structure)
        assert cand is None

    def test_stale_structure_shift_rejected(self):
        # MSS fired far too long ago (older than the freshness window) -
        # the pullback happening now isn't causally connected to it.
        candles = bullish_impulse_then_pullback(retracement=0.70)
        structure = StructureAnalysis(
            events=[mss_event(Direction.LONG, 0, candles[0].time)],
            protected_low=candles[0].low,
        )
        cand = find_scalp_candidate(candles, Direction.LONG, structure)
        assert cand is None

    def test_bos_alone_does_not_qualify(self):
        # A plain continuation BOS is not a change of character - scalping
        # requires an actual structure SHIFT, not trend continuation.
        candles = bullish_impulse_then_pullback(retracement=0.70)
        bos = StructureEvent(kind=StructureEventKind.BOS, direction=Direction.LONG,
                             level=110.0, index=len(candles) - 4,
                             time=candles[-4].time, close=110.5)
        structure = StructureAnalysis(events=[bos], protected_low=candles[0].low)
        cand = find_scalp_candidate(candles, Direction.LONG, structure)
        assert cand is None


class TestScalpSetupConstruction:
    def test_resting_limit_order_when_price_above_ote(self):
        # Price pulled back to the OTE level but the LAST close (used as
        # `last.close` reference) should still be above the OTE entry for a
        # long, since the OTE price is deeper than the current pullback low.
        candles = bullish_impulse_then_pullback(retracement=0.70)
        structure = StructureAnalysis(
            events=[mss_event(Direction.LONG, len(candles) - 4, candles[-4].time)],
            protected_low=candles[0].low,
        )
        setups = build_scalp_setups(candles, "EURUSD", "M5", structure,
                                    atr_value=0.5, scalp_cfg=ScalpingConfig())
        longs = [s for s in setups if s.direction is Direction.LONG]
        assert longs
        setup = longs[0]
        assert not setup.gates_failed
        assert setup.order_type in ("buy_limit", "market")
        assert setup.sl > 0 and setup.tp > 0
        assert setup.kind.value == "scalp_confirmation"
        # thesis must record the SMC method distinctly from swing setups.
        assert setup.thesis["method"] == "smc_scalp_pullback"

    def test_no_candidate_produces_gate_failure_not_crash(self):
        candles = bullish_impulse_then_pullback(retracement=0.30)  # outside OTE
        structure = StructureAnalysis(events=[], protected_low=candles[0].low)
        setups = build_scalp_setups(candles, "EURUSD", "M5", structure,
                                    atr_value=0.5, scalp_cfg=ScalpingConfig())
        assert len(setups) == 2  # one candidate per direction, both rejected
        assert all(s.gates_failed for s in setups)
        assert all(s.sl == 0.0 and s.tp == 0.0 for s in setups)

    def test_scalp_setup_never_references_zones_or_sr(self):
        # The Setup object from this module must never carry a `zone` or
        # general liquidity-sweep field the way swing setups do - it is a
        # deliberately separate thesis shape so the two methods can never
        # be confused downstream (journal, website signals feed, etc).
        candles = bullish_impulse_then_pullback(retracement=0.70)
        structure = StructureAnalysis(
            events=[mss_event(Direction.LONG, len(candles) - 4, candles[-4].time)],
            protected_low=candles[0].low,
        )
        setups = build_scalp_setups(candles, "EURUSD", "M5", structure,
                                    atr_value=0.5, scalp_cfg=ScalpingConfig())
        longs = [s for s in setups if s.direction is Direction.LONG]
        assert longs[0].zone is None
        assert longs[0].sweep is None
        assert "zone" not in longs[0].thesis

    def test_stop_loss_beyond_impulse_origin(self):
        candles = bullish_impulse_then_pullback(retracement=0.70)
        structure = StructureAnalysis(
            events=[mss_event(Direction.LONG, len(candles) - 4, candles[-4].time)],
            protected_low=candles[0].low,
        )
        setups = build_scalp_setups(candles, "EURUSD", "M5", structure,
                                    atr_value=0.5, scalp_cfg=ScalpingConfig())
        longs = [s for s in setups if s.direction is Direction.LONG]
        setup = longs[0]
        # SL must be below entry for a long, and below the impulse origin
        # (the invalidation point), never an arbitrary fixed distance.
        assert setup.sl < setup.entry
