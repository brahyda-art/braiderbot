"""Broker symbol discovery (spec section 4 follow-up: Exness suffix fix)."""

from app.market.symbol_resolution import resolve_symbol_name, strip_to_known_base


AVAILABLE = [
    "EURUSDm", "GBPJPYm", "USDCADm", "XAUUSDm", "BTCUSDm",
    "GBPUSDm", "EURJPYm", "USDJPYm",
]


class TestResolveSymbolName:
    def test_exact_match(self):
        assert resolve_symbol_name("EURUSDm", AVAILABLE) == "EURUSDm"

    def test_case_insensitive_exact_match(self):
        assert resolve_symbol_name("eurusdm", AVAILABLE) == "EURUSDm"

    def test_canonical_resolves_to_m_suffix(self):
        assert resolve_symbol_name("EURUSD", AVAILABLE) == "EURUSDm"
        assert resolve_symbol_name("GBPJPY", AVAILABLE) == "GBPJPYm"
        assert resolve_symbol_name("GBPUSD", AVAILABLE) == "GBPUSDm"

    def test_gold_and_btc_resolved_not_guessed(self):
        # Regression: earlier logic hard-coded suffixes per-symbol. This
        # must work purely from what the broker actually returns.
        assert resolve_symbol_name("XAUUSD", AVAILABLE) == "XAUUSDm"
        assert resolve_symbol_name("BTCUSD", AVAILABLE) == "BTCUSDm"

    def test_does_not_cross_match_different_instrument(self):
        # GBPUSD must never resolve to GBPJPY just because both start with GBP.
        assert resolve_symbol_name("GBPUSD", AVAILABLE) != "GBPJPYm"

    def test_unknown_symbol_returns_none(self):
        assert resolve_symbol_name("NOTREAL", AVAILABLE) is None

    def test_empty_available_returns_none(self):
        assert resolve_symbol_name("EURUSD", []) is None

    def test_empty_requested_returns_none(self):
        assert resolve_symbol_name("", AVAILABLE) is None

    def test_dot_a_suffix_variant(self):
        assert resolve_symbol_name("EURUSD", ["EURUSD.a"]) == "EURUSD.a"

    def test_prefers_exact_over_suffix(self):
        assert resolve_symbol_name("EURUSD", ["EURUSD", "EURUSDm"]) == "EURUSD"


class TestStripToKnownBase:
    def test_exact_base_match(self):
        assert strip_to_known_base("EURUSD", ["EURUSD", "GBPUSD"]) == "EURUSD"

    def test_broker_suffix_strips_back_to_base(self):
        assert strip_to_known_base("EURUSDm", ["EURUSD", "GBPUSD"]) == "EURUSD"
        assert strip_to_known_base("EURUSDM", ["EURUSD", "GBPUSD"]) == "EURUSD"

    def test_plain_symbol_matches_plain_base(self):
        assert strip_to_known_base("EURUSD", ["EURUSD"]) == "EURUSD"

    def test_no_match_returns_none(self):
        assert strip_to_known_base("GBPJPY", ["EURUSD", "GBPUSD"]) is None

    def test_does_not_cross_match_different_instrument(self):
        # GBPUSDm must not resolve to EURUSD just because both exist.
        assert strip_to_known_base("GBPUSDm", ["EURUSD", "GBPUSD"]) == "GBPUSD"

    def test_empty_available_returns_none(self):
        assert strip_to_known_base("EURUSDm", []) is None

