"""Always-on automation: Start keeps the bot running and scanning; loss /
drawdown / trade-count limits only PAUSE new trades (signals keep flowing);
Force Trade bypasses exactly those soft limits; hard stops are never bypassed;
and the lot size can never fall below 0.01."""

import pytest

from app.config import Config
from app.constants import BotState, Direction, SetupKind
from app.engine import Engine
from app.entries.pipeline import TradePipeline
from app.journal.journal import Journal
from app.risk.position_sizing import (ABSOLUTE_MIN_LOT, SymbolSpec, compute_lot_size,
                                      fixed_lot_size, min_volume)
from app.risk.risk_engine import RiskContext, RiskEngine
from app.state_store import StateStore
from app.strategy.confluence import Setup
from tests.fakes import FakeBroker

DAY = "2026-01-15"


def spec(**kw):
    base = dict(symbol="EURUSD", tick_size=0.00001, tick_value=1.0, volume_min=0.01,
                volume_max=100, volume_step=0.01, contract_size=100000,
                point=0.00001, stops_level_points=0)
    base.update(kw)
    return SymbolSpec(**base)


def mk_setup(sym="EURUSD", direction=Direction.LONG, kind=SetupKind.TREND_PULLBACK_ZONE):
    return Setup(id="su-x", symbol=sym, direction=direction, kind=kind, score=8.0,
                 entry=1.1000, sl=1.0950, tp=1.1100, order_type="market", entry_tf="M15",
                 reasons=[], gates_failed=[],
                 thesis={"zone": {"lower": 1.0948, "upper": 1.0960},
                         "invalidation_level": 1.0948})


def ctx(**kw):
    d = dict(bot_state=BotState.RUNNING, balance=10000.0, equity=10000.0, day=DAY,
             open_positions=[], open_pendings=[], spread_points=10.0,
             consecutive_losses=0, last_loss_ts_ms=None, now_ms=1_768_467_600_000)
    d.update(kw)
    return RiskContext(**d)


@pytest.fixture
def risk(tmp_path):
    cfg = Config()
    store = StateStore(tmp_path / "r.db")
    store.init_daily(DAY, 10000, 10000)
    store.kv_set("account_peak_equity", 10000)
    store.kv_set("week_peak_equity", 10000)
    store.kv_set("current_day", DAY)
    return RiskEngine(cfg, store), cfg, store


# --------------------------------------------------------------- lot floor
class TestMinimumLot:
    def test_floor_is_point_zero_one_even_if_broker_reports_smaller(self):
        s = spec(volume_min=0.001, volume_step=0.001)
        assert min_volume(s) == pytest.approx(ABSOLUTE_MIN_LOT)

    def test_broker_minimum_above_floor_is_respected(self):
        assert min_volume(spec(volume_min=0.10)) == pytest.approx(0.10)

    def test_garbage_broker_minimum_falls_back_to_floor(self):
        assert min_volume(spec(volume_min=0)) == pytest.approx(0.01)
        assert min_volume(spec(volume_min=float("nan"))) == pytest.approx(0.01)

    def test_calculated_size_never_below_point_zero_one(self):
        # 0.008 raw lots on a broker that reports min 0.001: must NOT send 0.008.
        s = spec(volume_min=0.001, volume_step=0.001)
        r = compute_lot_size(20, 50.0, 2000.0, 1992.0,
                             spec(symbol="XAUUSD", tick_size=0.01, tick_value=1.0,
                                  contract_size=100, point=0.01,
                                  volume_min=0.001, volume_step=0.001))
        assert r.ok and r.lots >= 0.01
        assert r.actual_risk_amount <= r.risk_amount + 1e-9

    def test_fixed_lot_below_floor_is_refused_never_sent(self):
        # A fixed lot under 0.01 is refused rather than silently raised
        # (raising it would change the user's stated exposure).
        r = fixed_lot_size(0.001, spec(volume_min=0.001, volume_step=0.001))
        assert not r.ok

    def test_fixed_lot_at_floor_accepted(self):
        r = fixed_lot_size(0.01, spec(volume_min=0.001, volume_step=0.001))
        assert r.ok and r.lots == pytest.approx(0.01)

    def test_normal_size_unchanged(self):
        r = compute_lot_size(10000, 1.0, 1.1000, 1.0950, spec())
        assert r.ok and r.lots == pytest.approx(0.20, abs=0.01)


# ------------------------------------------------------ soft limits pause
class TestSoftLimitsPauseNotStop:
    def test_daily_loss_blocks_new_trades(self, risk):
        eng, cfg, store = risk
        d = eng.pre_trade_check(ctx(equity=9600.0), "EURUSD", 0.1)
        assert not d.allowed and d.stage == "daily_loss_check"

    def test_max_trades_per_day_blocks(self, risk):
        eng, cfg, store = risk
        store.update_daily(DAY, trades=cfg.risk.max_trades_per_day)
        d = eng.pre_trade_check(ctx(), "EURUSD", 0.1)
        assert not d.allowed and d.stage == "trade_count_check"

    def test_weekly_drawdown_blocks(self, risk):
        eng, cfg, store = risk
        cfg.risk.max_weekly_drawdown_pct = 5.0
        cfg.risk.max_daily_loss_pct = 50.0          # isolate the weekly rule
        cfg.risk.max_daily_drawdown_pct = 50.0
        store.kv_set("week_peak_equity", 10000)
        d = eng.pre_trade_check(ctx(equity=9400.0), "EURUSD", 0.1)
        assert not d.allowed and d.stage == "weekly_dd_check"

    def test_weekly_limit_can_be_disabled_with_zero(self, risk):
        eng, cfg, store = risk
        cfg.risk.max_weekly_drawdown_pct = 0
        cfg.risk.max_daily_loss_pct = 50.0
        cfg.risk.max_daily_drawdown_pct = 50.0
        d = eng.pre_trade_check(ctx(equity=9400.0), "EURUSD", 0.1)
        assert d.stage != "weekly_dd_check"


class TestForceTrade:
    def test_override_bypasses_daily_loss(self, risk):
        eng, cfg, store = risk
        d = eng.pre_trade_check(ctx(equity=9600.0, override_limits=True), "EURUSD", 0.1)
        assert d.allowed
        assert "daily_loss_check" in d.metrics["override_bypassed"]

    def test_override_bypasses_trade_count(self, risk):
        eng, cfg, store = risk
        store.update_daily(DAY, trades=cfg.risk.max_trades_per_day)
        d = eng.pre_trade_check(ctx(override_limits=True), "EURUSD", 0.1)
        assert d.allowed

    def test_override_bypasses_weekly_and_daily_drawdown_together(self, risk):
        eng, cfg, store = risk
        cfg.risk.max_weekly_drawdown_pct = 3.0
        d = eng.pre_trade_check(ctx(equity=9400.0, override_limits=True), "EURUSD", 0.1)
        assert d.allowed
        assert {"daily_loss_check", "weekly_dd_check"} <= set(d.metrics["override_bypassed"])

    def test_override_does_not_bypass_account_drawdown(self, risk):
        eng, cfg, store = risk
        cfg.risk.max_account_drawdown_pct = 5.0
        store.kv_set("account_peak_equity", 10000)
        d = eng.pre_trade_check(ctx(equity=9400.0, override_limits=True), "EURUSD", 0.1)
        assert not d.allowed and d.stage == "account_dd_check"

    def test_override_does_not_bypass_emergency_stop(self, risk):
        eng, cfg, store = risk
        d = eng.pre_trade_check(ctx(bot_state=BotState.EMERGENCY_STOP, override_limits=True), "EURUSD", 0.1)
        assert not d.allowed

    def test_override_does_not_bypass_stopped_bot(self, risk):
        eng, cfg, store = risk
        d = eng.pre_trade_check(ctx(bot_state=BotState.STOPPED, override_limits=True), "EURUSD", 0.1)
        assert not d.allowed

    def test_override_does_not_bypass_spread(self, risk):
        eng, cfg, store = risk
        d = eng.pre_trade_check(ctx(spread_points=99999, override_limits=True), "EURUSD", 0.1)
        assert not d.allowed

    def test_override_does_not_disable_position_sizing_floor(self, risk):
        eng, cfg, store = risk
        d = eng.pre_trade_check(ctx(equity=9600.0, override_limits=True), "EURUSD", 0.1)
        assert d.allowed


class TestLimitStatus:
    def test_reports_blocked_limit(self, risk):
        eng, cfg, store = risk
        st = eng.limit_status(ctx(equity=9600.0))
        assert st["blocked"] and st["limit"] == "daily_loss" and st["message"]

    def test_reports_trade_count(self, risk):
        eng, cfg, store = risk
        store.update_daily(DAY, trades=cfg.risk.max_trades_per_day)
        st = eng.limit_status(ctx())
        assert st["blocked"] and st["limit"] == "max_trades"
        assert st["tradesToday"] == cfg.risk.max_trades_per_day

    def test_clear_when_within_limits(self, risk):
        eng, *_ = risk
        st = eng.limit_status(ctx())
        assert not st["blocked"] and st["hardStop"] is None


# ------------------------------------------------------- engine behaviour
@pytest.fixture
def engine(tmp_path):
    cfg = Config()
    store = StateStore(tmp_path / "e.db")
    broker = FakeBroker()
    eng = Engine(cfg, broker, None, store, Journal(store))
    store.kv_set("current_day", DAY)
    store.init_daily(DAY, 10000, 10000)
    return eng, cfg, broker, store


class TestEngineCommands:
    def test_start_stays_running(self, engine):
        eng, *_ = engine
        eng.handle_command("start", {})
        assert eng.bot_state is BotState.RUNNING
        # nothing but an explicit stop / emergency changes it
        for _ in range(3):
            eng._track_equity(1_768_467_600_000)
        assert eng.bot_state is BotState.RUNNING

    def test_force_trade_requires_running_bot(self, engine):
        eng, *_ = engine
        res = eng.handle_command("force_trade", {"enabled": True})
        assert not res["ok"] and "start" in res["reason"].lower()
        assert not eng.override_active()

    def test_force_trade_on_then_off(self, engine):
        eng, *_ = engine
        eng.handle_command("start", {})
        assert eng.handle_command("force_trade", {"enabled": True})["ok"]
        assert eng.override_active()
        eng.handle_command("force_trade", {"enabled": False})
        assert not eng.override_active()

    @pytest.mark.parametrize("cmd", ["stop", "pause", "emergency"])
    def test_stopping_clears_force_trade(self, engine, cmd):
        eng, *_ = engine
        eng.handle_command("start", {})
        eng.handle_command("force_trade", {"enabled": True})
        eng.handle_command(cmd, {})
        assert not eng.override_active()

    def test_force_trade_refused_during_emergency(self, engine):
        eng, *_ = engine
        eng.handle_command("emergency", {})
        assert not eng.handle_command("force_trade", {"enabled": True})["ok"]

    def test_force_trade_expires_when_the_day_rolls(self, engine):
        eng, _, _, store = engine
        eng.handle_command("start", {})
        eng.handle_command("force_trade", {"enabled": True})
        store.kv_set("current_day", "2026-01-16")
        assert not eng.override_active()


class TestEquityPeaks:
    def test_peaks_rise_with_equity(self, engine):
        eng, _, broker, store = engine
        broker.equity = 10500.0
        eng._track_equity(1_768_467_600_000)
        assert store.kv_get("account_peak_equity") == 10500.0
        assert store.kv_get("week_peak_equity") == 10500.0
        assert store.get_daily(DAY)["peak_equity"] == 10500.0

    def test_peaks_never_fall(self, engine):
        eng, _, broker, store = engine
        broker.equity = 10500.0
        eng._track_equity(1_768_467_600_000)
        broker.equity = 10100.0
        eng._track_equity(1_768_467_660_000)
        assert store.kv_get("week_peak_equity") == 10500.0

    def test_new_week_resets_weekly_peak(self, engine):
        eng, _, broker, store = engine
        broker.equity = 10500.0
        eng._track_equity(1_768_467_600_000)                 # Thu 15 Jan 2026
        broker.equity = 10200.0
        eng._track_equity(1_768_467_600_000 + 5 * 86400_000)  # next week
        assert store.kv_get("week_peak_equity") == 10200.0


class TestSignals:
    def test_blocked_signal_recorded_and_deduplicated(self, engine):
        eng, *_ = engine
        s = mk_setup()
        for i in range(5):
            eng._record_signal(s, "EURUSD", "blocked", "daily loss limit hit",
                               "daily_loss_check", 1_000 + i)
        sigs = eng.signals_snapshot()
        assert len(sigs) == 1
        assert sigs[0]["status"] == "blocked" and sigs[0]["count"] == 5
        assert "key" not in sigs[0]

    def test_executed_signal_not_downgraded_by_later_block(self, engine):
        eng, *_ = engine
        s = mk_setup()
        eng._record_signal(s, "EURUSD", "executed", "", "", 1_000, lots=0.05)
        eng._record_signal(s, "EURUSD", "blocked", "max positions", "risk", 2_000)
        sig = eng.signals_snapshot()[0]
        assert sig["status"] == "executed" and sig["lots"] == 0.05

    def test_blocked_upgrades_to_executed(self, engine):
        eng, *_ = engine
        s = mk_setup()
        eng._record_signal(s, "EURUSD", "blocked", "limit", "daily_loss_check", 1_000)
        eng._record_signal(s, "EURUSD", "executed", "", "", 2_000, lots=0.01)
        assert len(eng.signals_snapshot()) == 1
        assert eng.signals_snapshot()[0]["status"] == "executed"

    def test_list_is_capped(self, engine):
        eng, *_ = engine
        for i in range(60):
            eng._record_signal(mk_setup(sym=f"S{i}"), f"S{i}", "blocked", "x", "y", i)
        assert len(eng.signals_snapshot()) == 30

    def test_limit_notice_logged_once_per_day_per_stage(self, engine):
        eng, _, _, store = engine
        eng._notify_limit_once("daily_loss_check", "daily loss limit hit")
        eng._notify_limit_once("daily_loss_check", "daily loss limit hit")
        eng._notify_limit_once("trade_count_check", "max trades")
        eng._notify_limit_once("spread_check", "not a limit")
        assert len(eng._limit_logged) == 2

    def test_status_snapshot_contains_automation_fields(self, engine):
        eng, *_ = engine
        eng.handle_command("start", {})
        snap = eng.status_snapshot()
        for k in ("signals", "limits", "override", "config_version", "scanning"):
            assert k in snap
        assert snap["scanning"] is True


# ---------------------------------------------- end to end through the engine
class TestEndToEndLimitAndForceTrade:
    """Same setup, same account. Limit hit -> blocked SIGNAL and no order.
    Force Trade -> the identical setup is traded. Stop -> not traded."""

    @pytest.fixture
    def live(self, tmp_path):
        cfg = Config()
        cfg.execution.mode = "demo"          # exercise the real executor path
        store = StateStore(tmp_path / "live.db")
        broker = FakeBroker(balance=10000.0, equity=9600.0)   # -4%: over daily-loss cap
        eng = Engine(cfg, broker, None, store, Journal(store))
        store.kv_set("current_day", DAY)
        store.init_daily(DAY, 10000, 10000)
        store.kv_set("account_peak_equity", 10000)
        store.kv_set("week_peak_equity", 10000)
        cfg.risk.max_daily_loss_pct = 3.0
        eng.handle_command("start", {})
        return eng, broker

    NOW = 1_768_467_600_000        # 09:00 UTC, inside the London session

    def test_limit_hit_records_blocked_signal_and_places_no_order(self, live):
        eng, broker = live
        out = eng._process_setup(mk_setup(), "EURUSD", "EURUSD", self.NOW)
        assert out is None
        assert not broker.sent_market and not broker.sent_limits
        sig = eng.signals_snapshot()[0]
        assert sig["status"] == "blocked" and sig["stage"] == "daily_loss_check"
        assert eng.bot_state is BotState.RUNNING        # still running/scanning

    def test_force_trade_lets_the_same_setup_through(self, live):
        eng, broker = live
        eng.handle_command("force_trade", {"enabled": True})
        out = eng._process_setup(mk_setup(), "EURUSD", "EURUSD", self.NOW)
        assert out is not None
        assert len(broker.sent_market) == 1
        assert broker.sent_market[0]["lots"] >= 0.01
        assert broker.sent_market[0]["sl"] > 0          # stop-loss still mandatory
        assert eng.signals_snapshot()[0]["status"] == "executed"

    def test_force_trade_off_blocks_again(self, live):
        eng, broker = live
        eng.handle_command("force_trade", {"enabled": True})
        eng.handle_command("force_trade", {"enabled": False})
        assert eng._process_setup(mk_setup(), "EURUSD", "EURUSD", self.NOW) is None
        assert not broker.sent_market

    def test_stopped_bot_never_trades_even_with_stale_override(self, live):
        eng, broker = live
        eng.handle_command("force_trade", {"enabled": True})
        eng.handle_command("stop", {})
        assert eng._process_setup(mk_setup(), "EURUSD", "EURUSD", self.NOW) is None
        assert not broker.sent_market

    def test_trade_count_limit_then_force(self, live):
        eng, broker = live
        broker.equity = 10000.0                          # clear the loss limit
        eng.store.update_daily(DAY, trades=eng.cfg.risk.max_trades_per_day)
        assert eng._process_setup(mk_setup(), "EURUSD", "EURUSD", self.NOW) is None
        assert eng.signals_snapshot()[0]["stage"] == "trade_count_check"
        eng.handle_command("force_trade", {"enabled": True})
        assert eng._process_setup(mk_setup(), "EURUSD", "EURUSD", self.NOW) is not None
