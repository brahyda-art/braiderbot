"""Position sizing tests - the math must differ per instrument (spec 16)."""

import pytest

from app.risk.position_sizing import (SymbolSpec, compute_lot_size,
                                      normalize_volume, sl_respects_broker_stops)


def spec(**kw):
    base = dict(symbol="EURUSD", tick_size=0.00001, tick_value=1.0,
                volume_min=0.01, volume_max=100, volume_step=0.01,
                contract_size=100000, point=0.00001, stops_level_points=0)
    base.update(kw)
    return SymbolSpec(**base)


class TestForex:
    def test_eurusd_basic(self):
        # $10,000 equity, 1% risk = $100. SL 50 pips (0.0050).
        # loss_per_lot = 0.0050 / 0.00001 * 1.0 = $500 -> lots = 0.20
        r = compute_lot_size(10000, 1.0, 1.1000, 1.0950, spec())
        assert r.ok
        assert r.lots == pytest.approx(0.20, abs=1e-9)
        assert r.actual_risk_amount == pytest.approx(100.0, abs=0.01)

    def test_eurusd_risk_amount_doubled_for_larger_sl(self):
        r1 = compute_lot_size(10000, 1.0, 1.1000, 1.0950, spec())
        r2 = compute_lot_size(10000, 1.0, 1.1000, 1.0900, spec())
        assert r2.lots == pytest.approx(r1.lots / 2)

    def test_wider_risk_pct_increases_lots(self):
        r = compute_lot_size(10000, 2.0, 1.1000, 1.0950, spec())
        assert r.lots == pytest.approx(0.40)


class TestMetalsAndCrypto:
    def test_xauUSD_differs_from_forex(self):
        # XAUUSD: tick 0.01, tick value $1 -> $100 per $1 move per lot.
        # $100 risk, $5.00 stop -> loss/lot = 5.00/0.01*1.0 = $500 -> 0.20 lots
        g = spec(symbol="XAUUSD", tick_size=0.01, tick_value=1.0,
                 contract_size=100, point=0.01)
        r = compute_lot_size(10000, 1.0, 2000.0, 1995.0, g)
        assert r.ok
        assert r.lots == pytest.approx(0.20, abs=1e-9)

    def test_btcUSD_differs_again(self):
        # BTCUSD: tick 0.01, tick value $0.01 -> $1 per $1 move per lot.
        # $100 risk, $500 stop -> 100/500 = 0.2 lots
        b = spec(symbol="BTCUSD", tick_size=0.01, tick_value=0.01,
                 contract_size=1, point=0.01)
        r = compute_lot_size(10000, 1.0, 30000.0, 29500.0, b)
        assert r.ok
        assert r.lots == pytest.approx(0.20, abs=1e-9)


class TestRefusals:
    def test_missing_tick_data_refuses(self):
        r = compute_lot_size(10000, 1.0, 1.1, 1.095, spec(tick_value=0))
        assert not r.ok and r.lots == 0

    def test_zero_stop_refuses(self):
        r = compute_lot_size(10000, 1.0, 1.1, 1.1, spec())
        assert not r.ok

    def test_bad_equity_refuses(self):
        r = compute_lot_size(0, 1.0, 1.1, 1.095, spec())
        assert not r.ok

    def test_below_broker_min_uses_min_when_actual_risk_fits(self):
        # $0.05 configured risk with a 1-pip stop computes ~0.005 lots ->
        # below 0.01 min. loss_per_lot here = 0.0001/0.00001*1.0 = $10, so
        # actual risk at the 0.01 broker minimum is $0.10, which EXCEEDS the
        # $0.05 configured budget -> must still refuse.
        r = compute_lot_size(50, 0.1, 1.1000, 1.0999, spec())
        assert not r.ok
        assert "exceeds configured risk budget" in r.reason

    def test_below_broker_min_uses_min_when_it_fits_budget(self):
        # $20 equity, 50% configured risk -> $10 risk budget. A wide but
        # structurally valid stop makes the raw calculated size < 0.01.
        # loss_per_lot = 20.0 (price) * vpu(=100000) ... use a spec whose
        # actual risk at 0.01 lots is under $10, so the broker minimum must
        # be ALLOWED, not refused (this is the exact scenario from the spec).
        g = spec(symbol="XAUUSD", tick_size=0.01, tick_value=1.0,
                 contract_size=100, point=0.01)
        # loss_per_lot at 0.01 = stop_distance/0.01*1.0 * 0.01(min) ...
        # pick a stop distance so actual risk at min (0.01 lots) is $8 (<= $10).
        # loss_per_lot_per_1_lot = stop_distance/tick_size*tick_value
        # actual_risk_at_min = 0.01 * loss_per_lot_per_1_lot <= 10
        # => loss_per_lot_per_1_lot <= 1000 => stop_distance/0.01*1.0 <= 1000
        # => stop_distance <= 10.0. Use stop_distance = 8.0 (well under raw-min).
        r = compute_lot_size(20, 50.0, 2000.0, 1992.0, g)
        assert r.ok
        assert r.lots == pytest.approx(0.01)
        assert r.actual_risk_amount == pytest.approx(8.0, abs=0.01)
        assert r.actual_risk_amount <= 10.0

    def test_below_broker_min_refuses_when_min_exceeds_budget(self):
        # Same setup, but stop is wide enough that even 0.01 lots would risk
        # MORE than the $10 configured ceiling -> must refuse.
        g = spec(symbol="XAUUSD", tick_size=0.01, tick_value=1.0,
                 contract_size=100, point=0.01)
        r = compute_lot_size(20, 50.0, 2000.0, 1985.0, g)  # stop_distance=15 -> risk@min=$15
        assert not r.ok
        assert "exceeds configured risk budget" in r.reason


class TestNormalization:
    def test_volume_step_floor(self):
        assert normalize_volume(0.137, spec()) == pytest.approx(0.13)

    def test_normalize_volume_floors_below_min_to_zero(self):
        # normalize_volume() itself never clamps up - a too-small raw size
        # floors to 0.0. Whether the broker minimum gets used instead is a
        # risk decision made one level up, in compute_lot_size, based on the
        # ACTUAL monetary risk at that minimum (see TestRefusals above).
        assert normalize_volume(0.001, spec()) == pytest.approx(0.0)

    def test_volume_max_clamp(self):
        assert normalize_volume(1000, spec(volume_max=5)) == pytest.approx(5.0)


class TestBrokerStops:
    def test_buy_respects_stops_level(self):
        s = spec(stops_level_points=100, point=0.00001)
        assert sl_respects_broker_stops(1.1000, 1.0990, s, "buy")
        assert not sl_respects_broker_stops(1.1000, 1.09995, s, "buy")


def test_fixed_lot_size_respects_broker_step_and_minimum():
    from app.risk.position_sizing import fixed_lot_size
    r = fixed_lot_size(0.037, spec())
    assert r.ok and r.lots == 0.03


def test_fixed_lot_size_rejects_below_minimum():
    from app.risk.position_sizing import fixed_lot_size
    r = fixed_lot_size(0.005, spec())
    assert not r.ok
