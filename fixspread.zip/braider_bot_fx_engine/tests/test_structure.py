"""Market structure detection: swings, HH/HL labels, trend, BOS/CHoCH/MSS."""

from app.constants import Direction, StructureEventKind, Trend
from app.market.candles import Candle
from app.strategy.structure import (analyze_structure, detect_structure_events,
                                    label_swings, detect_trend)
from app.strategy.swings import find_swings


def staircase(highs, lows, start=100.0, tf_minutes=15, steps_per_leg=4):
    """Build OHLC candles that walk: up to highs[i], pull back to lows[i], ...
    Each leg has `steps_per_leg` bars so fractal(2) swings confirm."""
    points = [start]
    for h, l in zip(highs, lows):
        # walk up to h
        for k in range(1, steps_per_leg + 1):
            points.append(points[-1] + (h - points[-1]) * 0.5 if k < steps_per_leg else h)
        # pull back to l
        for k in range(1, steps_per_leg + 1):
            points.append(points[-1] - (points[-1] - l) * 0.5 if k < steps_per_leg else l)
    candles = []
    prev = start
    for i, v in enumerate(points):
        o = prev
        candles.append(Candle(time=1_700_000_000 + i * tf_minutes * 60,
                              open=o, high=max(o, v), low=min(o, v), close=v))
        prev = v
    return candles


BULL_HIGHS = [103.0, 105.0, 107.0, 109.0, 111.0]
BULL_LOWS = [101.0, 102.0, 103.5, 105.0, 106.5]


class TestSwings:
    def test_finds_swing_high_and_low(self):
        candles = staircase(BULL_HIGHS, BULL_LOWS)
        swings = find_swings(candles, strength=2)
        highs = [s.price for s in swings if s.kind == "high"]
        lows = [s.price for s in swings if s.kind == "low"]
        assert 103.0 in highs and 101.0 in lows

    def test_no_swings_in_short_series(self):
        candles = staircase([101], [100.5])
        assert find_swings(candles[:4], strength=2) == []


class TestLabelsTrend:
    def test_uptrend_labels(self):
        candles = staircase(BULL_HIGHS, BULL_LOWS)
        swings = find_swings(candles, 2)
        labels = label_swings(swings)
        labs = [l.label for l in labels]
        assert "HH" in labs and "HL" in labs
        assert detect_trend(labels) is Trend.BULLISH

    def test_downtrend_labels(self):
        highs = [100.0 - x for x in [3.0, 5.0, 7.0, 9.0]]
        lows = [100.0 - x for x in [1.0, 2.0, 3.5, 5.0]]
        candles = staircase(highs, lows, start=97.0)
        swings = find_swings(candles, 2)
        labels = label_swings(swings)
        assert detect_trend(labels) is Trend.BEARISH


class TestBreaks:
    def test_choch_after_uptrend(self):
        # uptrend then a decisive collapse below the last higher low
        candles = staircase(BULL_HIGHS, BULL_LOWS)
        extra = []
        prev = candles[-1].close
        for i in range(1, 9):
            v = prev - i * 1.5
            extra.append(Candle(time=candles[-1].time + i * 900,
                                open=prev, high=prev, low=v - 0.5, close=v))
            prev = v
        candles = candles + extra
        swings = find_swings(candles, 2)
        trend = detect_trend(label_swings(swings))
        assert trend is Trend.BULLISH
        events = detect_structure_events(candles, swings, trend, atr_value=1.5)
        assert any(e.direction is Direction.SHORT and
                   e.kind in (StructureEventKind.CHOCH, StructureEventKind.MSS)
                   for e in events)

    def test_bos_continuation(self):
        candles = staircase(BULL_HIGHS, BULL_LOWS)
        swings = find_swings(candles, 2)
        trend = detect_trend(label_swings(swings))
        events = detect_structure_events(candles, swings, trend, atr_value=1.0)
        assert any(e.direction is Direction.LONG and e.kind is StructureEventKind.BOS
                   for e in events)

    def test_wick_below_level_is_not_choch(self):
        candles = staircase(BULL_HIGHS, BULL_LOWS)
        n_before = len(candles)
        # wick candle: dips below the last swing low but closes above it
        last_low = min(c.low for c in candles[-6:])
        wick = Candle(time=candles[-1].time + 900,
                      open=candles[-1].close, high=candles[-1].close + 0.5,
                      low=last_low - 1.0, close=candles[-1].close)
        candles.append(wick)
        swings = find_swings(candles, 2)
        trend = detect_trend(label_swings(swings))
        events = detect_structure_events(candles, swings, trend, atr_value=1.0)
        for e in events:
            if e.direction is Direction.SHORT:
                assert e.index < n_before   # not emitted from the wick candle


class TestFullAnalysis:
    def test_analyze_structure_report(self):
        a = analyze_structure(staircase(BULL_HIGHS, BULL_LOWS), strength=2)
        assert a.trend is Trend.BULLISH
        assert a.last_swing_high is not None
        assert a.protected_low is not None
