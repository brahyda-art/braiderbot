"""API authentication & authorization (spec section 30)."""

import pytest
from fastapi.testclient import TestClient

from app.api.server import create_app
from app.state_store import StateStore


class DummyEngine:
    def __init__(self):
        from app.config import Config
        self.cfg = Config()

    def status_snapshot(self):
        return {"state": "RUNNING", "mode": "paper", "connected": True,
                "account": {"balance": 1}, "open_positions": 0,
                "pending_orders": 0, "floating_pl": 0, "daily_pnl": 0,
                "last_cycle_ms": 0, "cycles": 0, "emergency": False}

    def handle_command(self, action, payload):
        return {"ok": True, "action": action}


@pytest.fixture
def client(tmp_path):
    cfg_token = "test-token-123"
    store = StateStore(tmp_path / "api.db")
    app = create_app(DummyEngine().cfg, store, lambda: DummyEngine())
    app.state.engine = DummyEngine()
    # inject token the same way main.py does
    DummyEngine().cfg._api_token = cfg_token
    # create_app closes over cfg; emulate by monkeypatching the captured cfg
    from app.api import server as srv
    # simpler: rebuild app with a cfg that already has _api_token
    cfg = DummyEngine().cfg
    cfg._api_token = cfg_token
    app2 = create_app(cfg, store, lambda: DummyEngine())
    return TestClient(app2), cfg_token


class TestAuth:
    def test_public_reads_work(self, client):
        c, _ = client
        assert c.get("/health").status_code == 200
        assert c.get("/status").status_code == 200

    def test_command_without_token_refused(self, client):
        c, _ = client
        r = c.post("/command", json={"action": "start"})
        assert r.status_code == 401

    def test_command_with_bad_token_refused(self, client):
        c, _ = client
        r = c.post("/command", json={"action": "start"},
                   headers={"X-API-Token": "wrong"})
        assert r.status_code == 401

    def test_command_with_token_allowed(self, client):
        c, tok = client
        r = c.post("/command", json={"action": "start"},
                   headers={"X-API-Token": tok})
        assert r.status_code == 200 and r.json()["ok"]

    def test_trading_via_api_impossible(self, client):
        # There is no endpoint that places an order; arbitrary actions are refused.
        c, tok = client
        r = c.post("/command", json={"action": "buy", "payload": {"symbol": "EURUSD"}},
                   headers={"X-API-Token": tok})
        assert r.status_code == 400

    def test_missing_token_config_blocks_writes(self, tmp_path):
        store = StateStore(tmp_path / "api2.db")
        cfg = DummyEngine().cfg
        cfg._api_token = ""
        c = TestClient(create_app(cfg, store, lambda: DummyEngine()))
        r = c.post("/command", json={"action": "start"})
        assert r.status_code == 503


class TestReadEndpoints:
    def test_trades_setups_logs(self, client):
        c, _ = client
        assert c.get("/trades").status_code == 200
        assert c.get("/setups").status_code == 200
        assert c.get("/logs").status_code == 200
        assert c.get("/risk/today").status_code == 200
