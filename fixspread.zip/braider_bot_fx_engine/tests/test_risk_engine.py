"""Risk engine: daily-loss, drawdown, exposure, spread, cooldown, session."""

from datetime import datetime, timezone

import pytest

from app.config import Config
from app.constants import BotState
from app.risk.risk_engine import RiskContext, RiskEngine
from app.state_store import StateStore


@pytest.fixture
def engine(tmp_path):
    cfg = Config()
    store = StateStore(tmp_path / "risk.db")
    store.init_daily("2026-01-15", 10000, 10000)
    store.kv_set("account_peak_equity", 10000)
    # 09:00 UTC = inside london window
    return RiskEngine(cfg, store), cfg, store


def ctx(engine_tuple, **kw):
    engine, cfg, store = engine_tuple
    defaults = dict(
        bot_state=BotState.RUNNING, balance=10000.0, equity=10000.0,
        day="2026-01-15", open_positions=[], open_pendings=[],
        spread_points=10.0, consecutive_losses=0, last_loss_ts_ms=None,
        now_ms=int(datetime(2026, 1, 15, 9, 0, tzinfo=timezone.utc).timestamp() * 1000),
    )
    defaults.update(kw)
    return RiskContext(**defaults)


class TestStateGate:
    def test_stopped_bot_rejects(self, engine):
        eng, *_ = engine
        d = eng.pre_trade_check(ctx(engine, bot_state=BotState.STOPPED), "EURUSD", 0.1)
        assert not d.allowed

    def test_emergency_rejects(self, engine):
        eng, *_ = engine
        d = eng.pre_trade_check(ctx(engine, bot_state=BotState.EMERGENCY_STOP),
                                "EURUSD", 0.1)
        assert not d.allowed


class TestDailyLoss:
    def test_daily_loss_limit_blocks(self, engine):
        eng, cfg, store = engine
        store.update_daily("2026-01-15", realized_pnl=-350.0)  # -3.5%
        d = eng.pre_trade_check(ctx(engine, equity=9650.0), "EURUSD", 0.1)
        assert not d.allowed
        assert d.stage == "daily_loss_check"

    def test_daily_pnl_uncertain_blocks(self, engine):
        eng, *_ = engine
        d = eng.pre_trade_check(ctx(engine, equity=None), "EURUSD", 0.1)
        assert not d.allowed


class TestDrawdown:
    def test_daily_drawdown_blocks(self, engine):
        eng, cfg, store = engine
        store.update_daily("2026-01-15", peak_equity=10200.0)
        d = eng.pre_trade_check(ctx(engine, equity=9750.0), "EURUSD", 0.1)  # -4.4%
        assert not d.allowed
        assert d.stage == "daily_dd_check"

    def test_account_drawdown_blocks(self, engine):
        eng, cfg, store = engine
        # isolate account drawdown: daily start/peak equal current equity,
        # account peak far above -> only the account DD limit trips.
        store.update_daily("2026-01-15", start_balance=9500, start_equity=9500,
                           peak_equity=9500)
        store.kv_set("account_peak_equity", 11000.0)
        d = eng.pre_trade_check(ctx(engine, equity=9500.0, balance=9500.0),
                                "EURUSD", 0.1)  # -13.6% from account peak
        assert not d.allowed
        assert d.stage == "account_dd_check"


class TestExposure:
    def test_max_trades_per_day(self, engine):
        eng, cfg, store = engine
        store.update_daily("2026-01-15", trades=cfg.risk.max_trades_per_day)
        d = eng.pre_trade_check(ctx(engine), "EURUSD", 0.1)
        assert not d.allowed and d.stage == "trade_count_check"

    def test_max_simultaneous(self, engine):
        eng, cfg, _ = engine
        positions = [{"symbol": "XAUUSD", "lots": 0.1}
                     for _ in range(cfg.risk.max_simultaneous_positions)]
        d = eng.pre_trade_check(ctx(engine, open_positions=positions), "EURUSD", 0.1)
        assert not d.allowed and d.stage == "exposure_check"

    def test_max_per_symbol(self, engine):
        eng, *_ = engine
        d = eng.pre_trade_check(ctx(engine, open_positions=[
            {"symbol": "EURUSD", "lots": 0.1}]), "EURUSD", 0.1)
        assert not d.allowed

    def test_exposure_cap(self, engine):
        eng, cfg, _ = engine
        lots = cfg.risk.max_exposure_lots
        d = eng.pre_trade_check(ctx(engine, open_positions=[
            {"symbol": "XAUUSD", "lots": lots}]), "EURUSD", 0.1)
        assert not d.allowed


class TestCooldown:
    def test_consecutive_losses_trigger_cooldown(self, engine):
        eng, cfg, _ = engine
        now = int(datetime(2026, 1, 15, 9, 0, tzinfo=timezone.utc).timestamp() * 1000)
        d = eng.pre_trade_check(ctx(
            engine,
            consecutive_losses=cfg.risk.max_consecutive_losses,
            last_loss_ts_ms=now - 10 * 60000,   # lost 10 minutes ago
            now_ms=now,
        ), "EURUSD", 0.1)
        assert not d.allowed and d.stage == "cooldown_check"

    def test_cooldown_expires(self, engine):
        eng, cfg, _ = engine
        now = int(datetime(2026, 1, 15, 9, 0, tzinfo=timezone.utc).timestamp() * 1000)
        d = eng.pre_trade_check(ctx(
            engine,
            consecutive_losses=cfg.risk.max_consecutive_losses,
            last_loss_ts_ms=now - (cfg.risk.cooldown_minutes_after_losses + 5) * 60000,
            now_ms=now,
        ), "EURUSD", 0.1)
        assert d.allowed


class TestSpreadAndSession:
    def test_wide_spread_blocks(self, engine):
        eng, cfg, _ = engine
        d = eng.pre_trade_check(ctx(engine, spread_points=cfg.risk.max_spread_points + 1),
                                "EURUSD", 0.1)
        assert not d.allowed and d.stage == "spread_check"

    def test_missing_spread_blocks(self, engine):
        eng, *_ = engine
        d = eng.pre_trade_check(ctx(engine, spread_points=None), "EURUSD", 0.1)
        assert not d.allowed and d.stage == "spread_check"

    def test_outside_session_blocks(self, engine):
        eng, *_ = engine
        late = int(datetime(2026, 1, 15, 22, 30, tzinfo=timezone.utc).timestamp() * 1000)
        d = eng.pre_trade_check(ctx(engine, now_ms=late), "EURUSD", 0.1)
        assert not d.allowed and d.stage == "session_check"

    def test_inside_session_passes(self, engine):
        eng, *_ = engine
        d = eng.pre_trade_check(ctx(engine), "EURUSD", 0.1)
        assert d.allowed


class TestSessionWindows:
    def test_overnight_window(self, engine):
        _, cfg, _ = engine
        cfg.risk.allowed_sessions = ["sydney"]
        now = int(datetime(2026, 1, 15, 23, 0, tzinfo=timezone.utc).timestamp() * 1000)
        assert cfg and RiskEngine(cfg, engine[2]).session_allowed(now)
