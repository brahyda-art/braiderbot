"""TradeRecord.from_row() must tolerate legacy/extra columns physically
present in the on-disk `trades` table (CREATE TABLE IF NOT EXISTS never
migrates an existing table, and sqlite3.Row -> dict(row) pulls every
physical column) - a stale column from an older schema version must not
crash trade reconciliation every cycle."""

import sqlite3

import pytest

from app.state_store import TradeRecord


def _row_with_extra_column(extra_col="account_id", extra_val="acct-001"):
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    conn.executescript(f"""
        CREATE TABLE trades (
            id TEXT PRIMARY KEY, {extra_col} TEXT, symbol TEXT, side TEXT,
            lots REAL, status TEXT, setup_id TEXT, ticket TEXT, entry REAL,
            sl REAL, tp REAL, opened_at INTEGER, closed_at INTEGER,
            close_price REAL, profit REAL, r_multiple REAL, exit_reason TEXT,
            mode TEXT, thesis TEXT, management TEXT, comment TEXT
        );
    """)
    conn.execute(
        "INSERT INTO trades VALUES "
        "('t1',?,'EURUSDm','buy',0.1,'open',NULL,NULL,1.1,1.09,1.12,"
        "1000,NULL,NULL,0.0,NULL,NULL,'paper','{}','{}','')",
        (extra_val,),
    )
    return conn.execute("SELECT * FROM trades WHERE id=?", ("t1",)).fetchone()


class TestFromRowToleratesLegacyColumns:
    def test_stale_account_id_column_does_not_crash(self):
        row = _row_with_extra_column("account_id", "acct-001")
        tr = TradeRecord.from_row(row)
        assert tr.id == "t1"
        assert tr.symbol == "EURUSDm"
        assert not hasattr(tr, "account_id")

    def test_any_other_unknown_legacy_column_also_tolerated(self):
        row = _row_with_extra_column("some_future_column", "whatever")
        tr = TradeRecord.from_row(row)
        assert tr.id == "t1"

    def test_known_fields_still_populated_correctly(self):
        row = _row_with_extra_column()
        tr = TradeRecord.from_row(row)
        assert tr.side == "buy"
        assert tr.lots == 0.1
        assert tr.status == "open"
        assert tr.entry == 1.1
        assert tr.thesis == {}
        assert tr.management == {}
