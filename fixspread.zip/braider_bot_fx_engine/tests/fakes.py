"""Reusable fakes: a deterministic broker double + candle builders."""

from __future__ import annotations

import math
import random
from typing import Any, Dict, List, Optional

from app.execution.broker_client import (AccountInfo, BrokerClient, OrderResult,
                                         PendingOrderInfo, Position)


def make_candles(closes: List[float], start_time: int = 1_700_000_000,
                 spread_frac: float = 0.0005,
                 wick_frac: float = 0.001) -> list:
    """Build OHLC candles from a close series."""
    out = []
    prev = closes[0]
    for i, close in enumerate(closes):
        o = prev
        hi = max(o, close) * (1 + wick_frac)
        lo = min(o, close) * (1 - wick_frac)
        out.append(
            __import__("app.market.candles", fromlist=["Candle"]).Candle(
                time=start_time + i * 900, open=o, high=hi, low=lo, close=close))
        prev = close
    return out


def trending(start: float, drift: float, n: int, noise: float = 0.0002,
             seed: int = 7) -> List[float]:
    rnd = random.Random(seed)
    vals = [start]
    for _ in range(n - 1):
        vals.append(vals[-1] * (1 + drift + rnd.uniform(-noise, noise)))
    return vals


class FakeBroker(BrokerClient):
    """In-memory broker double for tests. Records all orders."""

    mode = "fake"

    def __init__(self, balance: float = 10000.0, equity: float = 10000.0):
        self.balance = balance
        self.equity = equity
        self._positions: Dict[str, Position] = {}
        self._orders: Dict[str, PendingOrderInfo] = {}
        self.sent_market: List[Dict] = []
        self.sent_limits: List[Dict] = []
        self.cancelled: List[str] = []
        self.closed: List[Dict] = []
        self.modified: List[Dict] = []
        self._ticket = 1000
        self.spread_points = 10.0
        self.health_info = {"ok": True, "connected": True}

    # data ---------------------------------------------------------------
    def health(self): return self.health_info

    def account(self) -> AccountInfo:
        return AccountInfo(login="12345", server="Demo-Server", broker="TestBroker",
                           currency="USD", balance=self.balance, equity=self.equity,
                           margin=0, free_margin=self.equity, leverage=100,
                           mode="demo")

    def symbol_specs(self, symbol: str) -> Dict[str, Any]:
        specs = {
            "EURUSD": dict(tick_size=0.00001, tick_value=1.0, volume_min=0.01,
                           volume_max=100, volume_step=0.01, contract_size=100000,
                           point=0.00001, stops_level_points=0),
            "XAUUSD": dict(tick_size=0.01, tick_value=1.0, volume_min=0.01,
                           volume_max=50, volume_step=0.01, contract_size=100,
                           point=0.01, stops_level_points=0),
            "BTCUSD": dict(tick_size=0.01, tick_value=0.01, volume_min=0.01,
                           volume_max=5, volume_step=0.01, contract_size=1,
                           point=0.01, stops_level_points=0),
        }
        base = specs.get(symbol.upper(), specs["EURUSD"])
        base = dict(base)
        base["symbol"] = symbol
        return base

    def rates(self, symbol, timeframe, count):
        return []

    def tick(self, symbol):
        return {"time": 0, "bid": 1.0, "ask": 1.0 + self.spread_points * 0.00001,
                "spread_points": self.spread_points}

    # trading --------------------------------------------------------------
    def positions(self):
        return list(self._positions.values())

    def pending_orders(self):
        return list(self._orders.values())

    def market_order(self, symbol, side, lots, sl, tp, comment="", magic=0,
                     deviation_points=10.0):
        if not sl or sl <= 0:
            return OrderResult(ok=False, comment="SL mandatory")
        self._ticket += 1
        t = str(self._ticket)
        self.sent_market.append(dict(symbol=symbol, side=side, lots=lots,
                                     sl=sl, tp=tp, comment=comment, magic=magic))
        price = 1.1000 if side == "buy" else 1.1000
        self._positions[t] = Position(ticket=t, symbol=symbol, side=side, lots=lots,
                                      open_price=price, sl=sl, tp=tp,
                                      comment=comment, magic=magic)
        return OrderResult(ok=True, ticket=t, price=price, retcode=10009)

    def limit_order(self, symbol, side, lots, price, sl, tp, comment="", magic=0,
                    expiration_ms=None):
        if not sl or sl <= 0:
            return OrderResult(ok=False, comment="SL mandatory")
        self._ticket += 1
        t = str(self._ticket)
        self.sent_limits.append(dict(symbol=symbol, side=side, lots=lots, price=price,
                                     sl=sl, tp=tp, comment=comment, magic=magic,
                                     expiration_ms=expiration_ms))
        self._orders[t] = PendingOrderInfo(ticket=t, symbol=symbol,
                                           kind=f"{side}_limit", lots=lots,
                                           price=price, sl=sl, tp=tp,
                                           comment=comment, magic=magic)
        return OrderResult(ok=True, ticket=t, price=price, retcode=10009)

    def modify_position(self, ticket, sl, tp):
        p = self._positions.get(str(ticket))
        if not p:
            return OrderResult(ok=False, comment="not found")
        if sl is not None:
            p.sl = sl
        if tp is not None:
            p.tp = tp
        self.modified.append(dict(ticket=str(ticket), sl=sl, tp=tp))
        return OrderResult(ok=True)

    def close_position(self, ticket, lots=None):
        p = self._positions.get(str(ticket))
        if not p:
            return OrderResult(ok=False, comment="not found")
        self.closed.append(dict(ticket=str(ticket), lots=lots or p.lots))
        if lots and lots < p.lots:
            p.lots -= lots
        else:
            del self._positions[str(ticket)]
        return OrderResult(ok=True, raw={"profit": 0.0, "lots": lots or p.lots})

    def cancel_order(self, ticket):
        if str(ticket) in self._orders:
            del self._orders[str(ticket)]
            self.cancelled.append(str(ticket))
            return OrderResult(ok=True)
        return OrderResult(ok=False, comment="not found")
