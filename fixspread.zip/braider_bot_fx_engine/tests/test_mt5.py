import MetaTrader5 as mt5

print("Starting MT5 connection test...")

initialized = mt5.initialize()
print("Initialize:", initialized)

if not initialized:
    print("Last error:", mt5.last_error())
else:
    print("Terminal version:", mt5.version())
    account = mt5.account_info()
    print("Account:", account)

    if account is None:
        print("Account info error:", mt5.last_error())
    else:
        print("Login:", account.login)
        print("Server:", account.server)
        print("Balance:", account.balance)
        print("Equity:", account.equity)
        print("Currency:", account.currency)

    mt5.shutdown()
    print("MT5 connection closed.")
