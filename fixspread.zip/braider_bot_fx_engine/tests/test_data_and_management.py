"""Data validation / freshness + early-exit management behaviour."""

import math

import pytest

from app.config import Config
from app.constants import Direction, ManagementSignal
from app.market.candles import Candle, atr, validate_candles
from app.market.data_feed import CsvFeed, resample
from app.state_store import StateStore, TradeRecord


def c(t, o, h, l, cl):
    return Candle(time=t, open=o, high=h, low=l, close=cl)


class TestDataValidation:
    def test_nan_and_dupes_dropped(self):
        candles = [
            c(1, 1.0, 1.1, 0.9, 1.05),
            c(1, 1.0, 1.1, 0.9, 1.05),              # duplicate time
            c(2, float("nan"), 1.1, 0.9, 1.05),     # NaN
            c(3, 1.0, 0.8, 1.2, 1.05),              # high < low
            c(4, 1.0, 1.1, 0.9, 1.05),
            c(3.5, 1.0, 1.1, 0.9, 1.05),            # out of order
        ]
        out = validate_candles(candles)
        assert [x.time for x in out] == [1, 4]

    def test_atr_positive(self):
        seq = [100 + i * 0.1 for i in range(50)]
        candles = [c(i, v, v + 0.2, v - 0.2, v + 0.1) for i, v in enumerate(seq, 1)]
        assert atr(candles, 14) > 0


class TestCsvFeed:
    def test_loads_csv(self, tmp_path):
        import csv as _csv
        p = tmp_path / "EURUSD_M15.csv"
        with p.open("w", newline="") as fh:
            w = _csv.writer(fh)
            w.writerow(["time", "open", "high", "low", "close", "volume"])
            for i in range(10):
                w.writerow([1700000000 + i * 900, 1.1, 1.11, 1.09, 1.105, 100])
        feed = CsvFeed(tmp_path)
        got = feed.get_rates("EURUSD", "M15", 100)
        assert len(got) == 10
        assert got[0].open == 1.1

    def test_missing_file_returns_empty(self, tmp_path):
        assert CsvFeed(tmp_path).get_rates("NOPE", "M15", 10) == []

    def test_broker_suffixed_symbol_finds_plain_file(self, tmp_path):
        """Paper mode must work whether the configured symbol has a broker
        suffix (EURUSDm) or not (EURUSD) - the sample data only has to exist
        once, under the plain name."""
        import csv as _csv
        p = tmp_path / "EURUSD_M15.csv"
        with p.open("w", newline="") as fh:
            w = _csv.writer(fh)
            w.writerow(["time", "open", "high", "low", "close", "volume"])
            for i in range(10):
                w.writerow([1700000000 + i * 900, 1.1, 1.11, 1.09, 1.105, 100])
        feed = CsvFeed(tmp_path)
        # broker-mapped name, lowercase "m" suffix - as the live symbol map uses
        got = feed.get_rates("EURUSDm", "M15", 100)
        assert len(got) == 10
        assert got[0].open == 1.1

    def test_plain_symbol_still_works_when_file_has_no_suffix(self, tmp_path):
        import csv as _csv
        p = tmp_path / "GBPUSD_M15.csv"
        with p.open("w", newline="") as fh:
            w = _csv.writer(fh)
            w.writerow(["time", "open", "high", "low", "close", "volume"])
            w.writerow([1700000000, 1.2, 1.21, 1.19, 1.205, 100])
        feed = CsvFeed(tmp_path)
        assert len(feed.get_rates("GBPUSD", "M15", 10)) == 1

    def test_offline_feed_never_fails_freshness(self, tmp_path):
        assert CsvFeed(tmp_path, require_fresh=False).is_fresh(
            "EURUSD", "M15", [], 2)[0] is True


class TestResample:
    def test_m5_to_m15(self):
        candles = [c(i * 300, 1, 1, 1, 1) for i in range(9)]
        out = resample(candles, "M5", "M15")
        assert len(out) == 3


class TestEarlyExit:
    """TradeManager severity ladder (spec section 35)."""

    def _manager(self, tmp_path, **mg_overrides):
        from app.engine import Engine
        from app.journal.journal import Journal
        from app.portfolio.trade_manager import TradeManager
        from tests.fakes import FakeBroker
        cfg = Config()
        for k, v in mg_overrides.items():
            setattr(cfg.management, k, v)
        store = StateStore(tmp_path / "m.db")
        broker = FakeBroker()
        engine = Engine(cfg, broker, None, store, Journal(store))
        return TradeManager(cfg, broker, engine.executor, store, Journal(store)), broker

    def _trade(self):
        return TradeRecord(id="tr-1", symbol="EURUSD", side="buy", lots=0.2,
                           entry=1.1000, sl=1.0950, tp=1.1100, status="open",
                           opened_at=1_700_000_000_000,
                           thesis={"invalidation_level": 1.0948,
                                   "zone": {"lower": 1.0948, "upper": 1.0960}},
                           management={})

    def _candles(self, closes, start=1_700_100_000, tf=900):
        out = []
        prev = closes[0]
        for i, v in enumerate(closes):
            out.append(Candle(time=start + i * tf, open=prev,
                              high=max(prev, v) + 0.001,
                              low=min(prev, v) - 0.001, close=v))
            prev = v
        return out

    def test_normal_noise_does_not_close(self, tmp_path):
        tm, _ = self._manager(tmp_path)
        # mild retracement that stays ABOVE the invalidation level 1.0948
        closes = [1.1000 - i * 0.0004 for i in range(14)]            # to 1.0948+
        closes += [1.0986 - (i % 4) * 0.0002 for i in range(30)]     # chop
        acts = tm.evaluate_position(self._trade(), self._candles(closes), 0)
        assert not any(a.kind == "close" for a in acts)

    def test_wick_through_invalidation_is_warning_only(self, tmp_path):
        tm, _ = self._manager(tmp_path)
        # 25 flat bars + gentle pullback that stays ABOVE invalidation 1.0948
        closes = [1.0995 - (0.0005 * (i - 25) if i > 25 else 0)
                  for i in range(33)]
        candles = self._candles(closes)
        # append a wick below invalidation 1.0948 that closes back above
        last = candles[-1]
        candles.append(Candle(time=last.time + 900, open=last.close,
                              high=last.close + 0.002, low=1.0940,
                              close=1.0955))
        acts = tm.evaluate_position(self._trade(), candles, 0)
        assert not any(a.kind == "close" for a in acts)
        assert any(a.reason == "thesis_warning" for a in acts)

    def test_body_close_through_with_structure_closes(self, tmp_path):
        tm, broker = self._manager(tmp_path)
        # uptrend then hard break below invalidation (strong close-through)
        closes = ([1.1000 + i * 0.001 for i in range(40)] +
                  [1.1010 - i * 0.004 for i in range(1, 15)])
        candles = self._candles(closes)
        trade = self._trade()
        trade.ticket = "1001"
        broker.market_order("EURUSD", "buy", 0.2, 1.0950, 1.1100)
        # replace the fake position entry to match the trade ticket
        broker._positions["1001"] = broker._positions[
            list(broker._positions)[0]]
        acts = tm.evaluate_position(trade, candles, 0)
        assert any(a.kind == "close" for a in acts)
        tm.apply_actions(trade, acts)
        assert trade.status == "closed"
        assert trade.exit_reason == "thesis_invalidated"

    def test_partial_exit_registered_at_1r(self, tmp_path):
        tm, broker = self._manager(tmp_path,
                                   partial_exits=[{"at_r": 1.0, "close_pct": 50}])
        # rally so price is >= 1R above entry (risk = 50 pips)
        closes = [1.1000 + i * 0.002 for i in range(40)]
        candles = self._candles(closes)
        trade = self._trade()
        trade.ticket = "1001"
        acts = tm.evaluate_position(trade, candles, 0)
        partials = [a for a in acts if a.kind == "partial"]
        assert partials, "expected a partial close action at 1R"
        assert partials[0].detail["lots"] == pytest.approx(0.1)

    def test_break_even_moves_sl(self, tmp_path):
        tm, _ = self._manager(tmp_path, break_even_requires_structure=False)
        closes = [1.1000 + i * 0.002 for i in range(40)]
        candles = self._candles(closes)
        trade = self._trade()
        acts = tm.evaluate_position(trade, candles, 0)
        be = [a for a in acts if a.reason == "break_even"]
        assert be and be[0].detail["new_sl"] > trade.entry
