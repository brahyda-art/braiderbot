"""Stop-loss validation tests (SL is mandatory, spec 15)."""

from app.risk.stop_loss import validate_stop_loss


class TestMandatory:
    def test_missing_sl_rejected(self):
        r = validate_stop_loss("buy", 1.1000, 0, [1.0950])
        assert not r.ok and "missing" in r.reason

    def test_none_sl_rejected(self):
        assert not validate_stop_loss("sell", 1.1000, None, [1.1050]).ok


class TestSides:
    def test_buy_sl_above_entry_rejected(self):
        r = validate_stop_loss("buy", 1.1000, 1.1010, [1.0950])
        assert not r.ok

    def test_sell_sl_below_entry_rejected(self):
        r = validate_stop_loss("sell", 1.1000, 1.0990, [1.1050])
        assert not r.ok


class TestDistances:
    def test_min_distance_enforced(self):
        r = validate_stop_loss("buy", 1.1000, 1.0999, [1.0999],
                               min_stop_price=0.0005)
        assert not r.ok and "below minimum" in r.reason

    def test_max_distance_enforced(self):
        r = validate_stop_loss("buy", 1.1000, 1.0800, [1.0800],
                               max_stop_price=0.0050)
        assert not r.ok and "above maximum" in r.reason

    def test_broker_stops_level(self):
        r = validate_stop_loss("buy", 1.1000, 1.09995, [1.0999],
                               broker_min_distance=0.0002)
        assert not r.ok


class TestLogicalAnchor:
    def test_sl_beyond_zone_low_ok(self):
        r = validate_stop_loss("buy", 1.1000, 1.0940, [1.0950])
        assert r.ok

    def test_sl_inside_structure_rejected(self):
        # anchors sit BELOW the proposed SL -> the stop is not beyond structure
        r = validate_stop_loss("buy", 1.1000, 1.0970, [1.0955, 1.0950])
        assert not r.ok and "not beyond" in r.reason

    def test_sell_sl_beyond_zone_high_ok(self):
        r = validate_stop_loss("sell", 1.1000, 1.1060, [1.1050])
        assert r.ok

    def test_fixed_pip_allowed_only_when_enabled(self):
        r = validate_stop_loss("buy", 1.1000, 1.0995, [1.0940])
        assert not r.ok
        r2 = validate_stop_loss("buy", 1.1000, 1.0995, [1.0940],
                                allow_fixed_pip_sl=True)
        assert r2.ok
