"""End-to-end trade rejection tests: the pipeline must refuse bad setups."""

import pytest

from app.config import Config
from app.constants import BotState, Direction, SetupKind
from app.entries.pipeline import TradePipeline
from app.risk.risk_engine import RiskContext, RiskEngine
from app.risk.position_sizing import SymbolSpec
from app.state_store import StateStore
from app.strategy.confluence import Setup


def mk_setup(score=8.0):
    return Setup(
        id="su-test", symbol="EURUSD", direction=Direction.LONG,
        kind=SetupKind.TREND_PULLBACK_ZONE, score=score,
        entry=1.1000, sl=1.0950, tp=1.1100, order_type="market",
        entry_tf="M15",
        reasons=[], gates_failed=[],
        thesis={"zone": {"lower": 1.0948, "upper": 1.0960},
                "invalidation_level": 1.0948},
    )


def mk_ctx(**kw):
    defaults = dict(bot_state=BotState.RUNNING, balance=10000.0, equity=10000.0,
                    day="2026-01-15", open_positions=[], open_pendings=[],
                    spread_points=10.0, consecutive_losses=0,
                    last_loss_ts_ms=None, now_ms=1_768_467_600_000)  # 09:00 UTC
    defaults.update(kw)
    return RiskContext(**defaults)


def spec(**kw):
    base = dict(symbol="EURUSD", tick_size=0.00001, tick_value=1.0,
                volume_min=0.01, volume_max=100, volume_step=0.01,
                contract_size=100000, point=0.00001, stops_level_points=0)
    base.update(kw)
    return SymbolSpec(**base)


@pytest.fixture
def pipeline(tmp_path):
    cfg = Config()
    store = StateStore(tmp_path / "p.db")
    store.init_daily("2026-01-15", 10000, 10000)
    store.kv_set("account_peak_equity", 10000)
    store.kv_set("current_day", "2026-01-15")
    pipe = TradePipeline(cfg, RiskEngine(cfg, store), lambda s: spec())
    return pipe, cfg, store


class TestApprovals:
    def test_good_setup_approved(self, pipeline):
        pipe, cfg, _ = pipeline
        res = pipe.run(mk_setup(), mk_ctx(), spread_points=10, tick_size=0.00001,
                       spec=spec())
        assert res.approved
        assert res.lots == pytest.approx(0.20, abs=0.01)

    def test_partial_risk_correct(self, pipeline):
        pipe, *_ = pipeline
        res = pipe.run(mk_setup(), mk_ctx(), 10, 0.00001, spec())
        assert res.metrics["actual_risk_amount"] == pytest.approx(100.0, abs=2.0)


class TestRejections:
    def test_spread_too_wide_rejected(self, pipeline):
        pipe, cfg, _ = pipeline
        res = pipe.run(mk_setup(), mk_ctx(), spread_points=cfg.risk.max_spread_points + 1,
                       tick_size=0.00001, spec=spec())
        assert not res.approved and res.stage == "spread_check"

    def test_wrong_side_sl_rejected(self, pipeline):
        pipe, *_ = pipeline
        s = mk_setup()
        s.sl = 1.1050    # buy with SL above entry
        res = pipe.run(s, mk_ctx(), 10, 0.00001, spec())
        assert not res.approved and res.stage == "stop_loss_validation"

    def test_sl_not_beyond_anchor_rejected(self, pipeline):
        pipe, *_ = pipeline
        s = mk_setup()
        s.sl = 1.0970    # inside the zone, not beyond the anchor 1.0948
        s.thesis = {"zone": {"lower": 1.0948, "upper": 1.0960},
                    "invalidation_level": 1.0948}
        res = pipe.run(s, mk_ctx(), 10, 0.00001, spec())
        assert not res.approved and res.stage == "stop_loss_validation"

    def test_daily_loss_blocks_trade(self, pipeline):
        pipe, cfg, store = pipeline
        store.update_daily("2026-01-15", realized_pnl=-400.0)
        res = pipe.run(mk_setup(), mk_ctx(equity=9600), 10, 0.00001, spec())
        assert not res.approved and res.stage == "daily_loss_check"

    def test_bot_paused_blocks_trade(self, pipeline):
        pipe, *_ = pipeline
        res = pipe.run(mk_setup(), mk_ctx(bot_state=BotState.PAUSED), 10, 0.00001,
                       spec())
        assert not res.approved and res.stage == "state_check"

    def test_sizing_failure_blocks(self, pipeline):
        pipe, *_ = pipeline
        tiny = spec(volume_min=1.0)   # needs >= 1 lot but we compute ~0.2
        res = pipe.run(mk_setup(), mk_ctx(equity=9800, balance=9800), 10,
                       0.00001, tiny)
        assert not res.approved and res.stage == "position_size"

    def test_rr_gate(self, pipeline):
        pipe, cfg, _ = pipeline
        s = mk_setup()
        s.tp = 1.1060   # 1.2R < min_rr 1.5
        res = pipe.run(s, mk_ctx(), 10, 0.00001, spec())
        # RR is checked by confluence (gate), pipeline only sees SL/sizing/risk;
        # ensure confluence-level gate logic flags it:
        from app.strategy import confluence
        assert confluence._rr(s.entry, s.sl, s.tp, s.direction) < cfg.risk.min_rr
