"""Demo-first safety (spec section 25): live mode must be explicitly enabled."""

import pytest

from app.config import Config, load_config
from app.journal.journal import Journal
from app.state_store import StateStore
from tests.fakes import FakeBroker


class TestDefaults:
    def test_default_mode_is_paper(self, base_cfg):
        assert base_cfg.execution.mode == "paper"

    def test_default_config_file_is_paper(self):
        cfg = load_config()
        assert cfg.execution.mode == "paper"


class TestLiveGate:
    def test_live_refused_without_env(self, monkeypatch, tmp_path):
        from app.main import verify_safety_gates
        monkeypatch.delenv("LIVE_TRADING_ENABLED", raising=False)
        cfg = Config()
        cfg.execution.mode = "live"
        store = StateStore(tmp_path / "s.db")
        with pytest.raises(SystemExit):
            verify_safety_gates(cfg, FakeBroker(), Journal(store))

    def test_live_allowed_with_explicit_env(self, monkeypatch, tmp_path):
        from app.main import verify_safety_gates
        monkeypatch.setenv("LIVE_TRADING_ENABLED", "true")
        cfg = Config()
        cfg.execution.mode = "live"
        store = StateStore(tmp_path / "s.db")
        # must NOT raise
        verify_safety_gates(cfg, FakeBroker(), Journal(store))

    def test_demo_requires_bridge(self, monkeypatch, tmp_path):
        from app.main import verify_safety_gates
        from app.execution.broker_client import BrokerError

        class DeadBroker(FakeBroker):
            def health(self):
                raise BrokerError("bridge unreachable")

        cfg = Config()
        cfg.execution.mode = "demo"
        cfg.execution.bridge_url = "http://127.0.0.1:1"
        with pytest.raises(SystemExit):
            verify_safety_gates(cfg, DeadBroker(), Journal(StateStore(tmp_path / "x.db")))


class TestPaperBrokerHonesty:
    def test_paper_trades_are_labelled(self, tmp_path):
        from app.market.data_feed import CsvFeed
        from app.execution.paper_broker import PaperBroker
        broker = PaperBroker(CsvFeed(tmp_path), {}, start_balance=5000)
        acc = broker.account()
        assert acc.mode == "paper"
        assert "simulated" in acc.broker.lower() or "paper" in acc.broker.lower()

    def test_paper_health_declares_simulation(self, tmp_path):
        from app.market.data_feed import CsvFeed
        from app.execution.paper_broker import PaperBroker
        broker = PaperBroker(CsvFeed(tmp_path), {}, start_balance=5000)
        h = broker.health()
        assert h["mode"] == "paper" and "simulator" in h["detail"]

    def test_executor_refuses_orders_without_sl(self, tmp_path):
        # the ENGINE never sends orders without SL; the executor refuses.
        from app.execution.executor import Executor
        from app.journal.journal import Journal
        from app.state_store import StateStore
        from app.config import Config
        from app.market.data_feed import CsvFeed
        from app.execution.paper_broker import PaperBroker
        from app.constants import Direction
        cfg = Config()
        store = StateStore(tmp_path / "s.db")
        broker = PaperBroker(CsvFeed(tmp_path), {}, 10000)
        ex = Executor(cfg, broker, store, Journal(store))
        res = ex.place_market("su-x", "EURUSD", Direction.LONG, 0.1, 0.0, 1.2)
        assert not res["ok"] and "mandatory" in res["reason"]
