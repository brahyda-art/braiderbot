"""The website -> engine contract. The website sends a config_update command
whose payload is {web:{config,mapping}}; these tests pin down that every
setting the Settings page exposes actually reaches the engine config."""

from app.config import Config, STRATEGY_CONCEPTS, apply_web_config


def web(**config):
    return {"config": config}


class TestConcepts:
    def test_enabled_concepts_applied(self):
        cfg = Config()
        applied = apply_web_config(cfg, web(enabledConcepts=["supply_demand", "fair_value_gap"]))
        assert cfg.strategy.enabled_concepts == ["supply_demand", "fair_value_gap"]
        assert "strategy.enabled_concepts" in applied

    def test_unknown_concepts_dropped_not_fatal(self):
        cfg = Config()
        apply_web_config(cfg, web(enabledConcepts=["supply_demand", "nonsense"]))
        assert cfg.strategy.enabled_concepts == ["supply_demand"]

    def test_all_unknown_leaves_previous_setting(self):
        cfg = Config()
        cfg.strategy.enabled_concepts = ["support_resistance"]
        apply_web_config(cfg, web(enabledConcepts=["bogus"]))
        assert cfg.strategy.enabled_concepts == ["support_resistance"]

    def test_default_is_every_concept(self):
        assert set(Config().strategy.enabled_concepts) == set(STRATEGY_CONCEPTS)


class TestScalping:
    def test_scalping_toggle_on_and_off(self):
        cfg = Config()
        apply_web_config(cfg, web(scalpingEnabled=True))
        assert cfg.scalping.enabled is True
        apply_web_config(cfg, web(scalpingEnabled=False))
        assert cfg.scalping.enabled is False

    def test_scalping_does_not_touch_enabled_concepts(self):
        cfg = Config()
        cfg.strategy.enabled_concepts = ["supply_demand"]
        apply_web_config(cfg, web(scalpingEnabled=True))
        assert cfg.strategy.enabled_concepts == ["supply_demand"]

    def test_scalping_mode_string_accepted(self):
        cfg = Config()
        apply_web_config(cfg, web(mode="scalping"))
        assert cfg.strategy.mode == "scalping"
        assert cfg.effective_strategy().mode == "scalping"


class TestPairsAndLots:
    def test_disabled_pair_removed_from_watched(self):
        cfg = Config()
        apply_web_config(cfg, web(symbols=["EURUSD", "GBPUSD", "USDCAD"]))
        assert "XAUUSD" not in cfg.symbols.watched
        assert "BTCUSD" not in cfg.symbols.watched

    def test_per_symbol_lots(self):
        cfg = Config()
        apply_web_config(cfg, web(risk={"lotSizingMode": "per_symbol",
                                       "fixedLotSize": 0.01,
                                       "fixedLotSizes": {"eurusd": 0.05, "XAUUSD": 0.01}}))
        assert cfg.risk.lot_sizing_mode == "per_symbol"
        assert cfg.risk.fixed_lot_sizes == {"EURUSD": 0.05, "XAUUSD": 0.01}

    def test_fixed_lot(self):
        cfg = Config()
        apply_web_config(cfg, web(risk={"lotSizingMode": "fixed_lot", "fixedLotSize": 0.03}))
        assert cfg.risk.fixed_lot_size == 0.03

    def test_invalid_lot_ignored(self):
        cfg = Config()
        before = cfg.risk.fixed_lot_size
        apply_web_config(cfg, web(risk={"fixedLotSize": -1}))
        assert cfg.risk.fixed_lot_size == before


class TestSessions:
    def test_new_york_actually_applies(self):
        # Website value "ny" used to be silently ignored.
        cfg = Config()
        apply_web_config(cfg, web(risk={"session": "ny"}))
        assert cfg.risk.allowed_sessions == ["newyork"]

    def test_london_plus_ny(self):
        cfg = Config()
        apply_web_config(cfg, web(risk={"session": "londonny"}))
        assert cfg.risk.allowed_sessions == ["london", "newyork"]

    def test_asia(self):
        cfg = Config()
        apply_web_config(cfg, web(risk={"session": "asia"}))
        assert set(cfg.risk.allowed_sessions) == {"tokyo", "sydney"}

    def test_all_sessions(self):
        cfg = Config()
        apply_web_config(cfg, web(risk={"session": "all"}))
        assert set(cfg.risk.allowed_sessions) == {"sydney", "tokyo", "london", "newyork"}

    def test_unknown_session_leaves_setting(self):
        cfg = Config()
        before = list(cfg.risk.allowed_sessions)
        apply_web_config(cfg, web(risk={"session": "moonbase"}))
        assert cfg.risk.allowed_sessions == before


class TestFullWebsitePayload:
    def test_realistic_payload_from_settings_page(self):
        cfg = Config()
        payload = {"web": {"config": {
            "mode": "scalping", "timeframe": "H1",
            "symbols": ["EURUSD", "GBPUSD"],
            "enabledConcepts": ["supply_demand"],
            "scalpingEnabled": True,
            "risk": {"perTrade": 2, "maxDailyLoss": 3, "maxDrawdown": 8, "maxTrades": 6,
                     "maxSimul": 2, "maxSpread": 25, "maxSlippage": 10, "minRR": 1.5,
                     "session": "londonny", "lotSizingMode": "risk_percent",
                     "fixedLotSize": 0.01, "fixedLotSizes": {}}},
            "mapping": {"XAUUSD": "XAUUSDm", "EURUSD": "EURUSDm"}}}
        applied = apply_web_config(cfg, payload["web"])
        assert cfg.scalping.enabled and cfg.strategy.mode == "scalping"
        assert cfg.symbols.watched == ["EURUSD", "GBPUSD"]
        assert cfg.symbols.mapping["XAUUSD"] == "XAUUSDm"
        assert cfg.risk.per_trade_risk_pct == 2
        assert cfg.risk.allowed_sessions == ["london", "newyork"]
        assert "symbols" in applied and "scalping.enabled" in applied
