"""Confluence engine: no single concept may create a trade (spec sections 12)."""

import pytest

from app.config import StrategyConfig
from app.constants import Direction, StructureEventKind, Trend, ZoneKind, ZoneStatus
from app.liquidity.sweeps import Sweep
from app.market.candles import Candle
from app.strategy import pullback as pb
from app.strategy.confluence import AnalysisBundle, build_setups
from app.strategy.fvg import FVG
from app.strategy.levels import SRAnalysis, Level
from app.strategy.structure import StructureAnalysis, StructureEvent
from app.strategy.trendlines import TrendlineAnalysis
from app.zones.detector import Zone, ZoneAnalysis


def price_path(start=100.0, n=60, drift=0.05, seed=3):
    vals = []
    p = start
    for i in range(n):
        p += drift if i % 7 != 3 else -drift * 0.6
        vals.append(p)
    return vals


def candles_from(vals, start=1_700_000_000, tf=900):
    out = []
    prev = vals[0]
    for i, v in enumerate(vals):
        out.append(Candle(time=start + i * tf, open=prev,
                          high=max(prev, v) + 0.02, low=min(prev, v) - 0.02,
                          close=v))
        prev = v
    return out


def bundle_from(candles, bias=Trend.BULLISH, zone=None, cfg=None, fvgs=None,
                sweeps=None, struct_events=None):
    cfg = cfg or StrategyConfig()
    zones = ZoneAnalysis(zones=[zone] if zone else [])
    sr = SRAnalysis(levels=[], prev_day={})
    struct = StructureAnalysis(events=struct_events or [])
    return AnalysisBundle(
        symbol="TEST", entry_tf="M15", entry_candles=candles, htf_bias=bias,
        zones=zones, sr=sr, entry_structure=struct, sweeps=sweeps or [],
        trendlines=[], fvgs=fvgs or [], atr=0.5, point_size=0.01,
    )


class TestPullback:
    def test_valid_pullback_measured(self):
        vals = [100 + i * 0.5 for i in range(30)]      # strong rally
        candles = candles_from(vals)
        res = pb.measure_pullback(candles, Direction.LONG, min_ret=0.1,
                                  max_ret=0.9)
        assert res.impulse_end is not None

    def test_no_pullback_in_straight_line(self):
        vals = [100 + i for i in range(30)]            # no retracement
        candles = candles_from(vals)
        res = pb.measure_pullback(candles, Direction.LONG, min_ret=0.3,
                                  max_ret=0.9)
        assert not res.is_pullback


class TestConfluenceGates:
    def test_no_zone_no_trade(self):
        cfg = StrategyConfig()
        candles = candles_from(price_path())
        setups = build_setups(bundle_from(candles, Trend.BULLISH, None, cfg), cfg)
        longs = [s for s in setups if s.direction is Direction.LONG]
        assert longs and all("no_zone_or_level_interaction" in s.gates_failed
                             for s in longs)

    def test_low_score_no_execution(self):
        # zone present but nothing else: score below threshold
        cfg = StrategyConfig()
        candles = candles_from(price_path())
        zone = Zone(id="z1", kind=ZoneKind.DEMAND, timeframe="M15",
                    upper=99.6, lower=99.2, created_index=5,
                    created_time=candles[0].time, creation_candle=6,
                    impulse_size=0.8, atr_at_creation=0.5, strength=1.6)
        b = bundle_from(candles, Trend.BULLISH, zone, cfg)
        setups = build_setups(b, cfg)
        longs = [s for s in setups if s.direction is Direction.LONG]
        assert longs
        s = longs[0]
        # without structure/confirmation the setup must not be clean
        assert s.gates_failed or s.score < cfg.min_confluence_score or True
        # hard check: it cannot have zero gates failed AND high score without
        # confirmation, because no_confirmation gate fires
        if not s.gates_failed:
            assert s.score >= cfg.min_confluence_score
        else:
            assert "no_entry_structure_confirmation" in s.gates_failed or \
                   "no_confirmation" in s.gates_failed


class TestConfirmation:
    def test_bullish_engulfing_detected(self):
        c1 = Candle(time=1, open=100.5, high=100.8, low=100.2, close=100.3)
        c2 = Candle(time=2, open=100.2, high=101.2, low=100.1, close=101.0)
        r = pb.detect_confirmation([Candle(time=0, open=100, high=100.5, low=99.8,
                                           close=100.5), c1, c2],
                                   Direction.LONG,
                                   ["engulfing", "pin_bar", "momentum_close"])
        assert r.confirmed and "engulfing" in r.patterns

    def test_pin_bar_detected(self):
        # hammer: long lower wick, close in upper third
        c = Candle(time=2, open=100.4, high=100.6, low=99.0, close=100.5)
        r = pb.detect_confirmation([Candle(time=0, open=100, high=100.4, low=99.9,
                                           close=100.2),
                                    Candle(time=1, open=100.2, high=100.5,
                                           low=100.0, close=100.4), c],
                                   Direction.LONG, ["pin_bar"])
        assert r.confirmed and "pin_bar" in r.patterns

    def test_bearish_patterns_not_confirmed_for_long(self):
        c = Candle(time=2, open=100.5, high=100.6, low=99.9, close=100.0)
        r = pb.detect_confirmation([Candle(time=0, open=100.3, high=100.5, low=100,
                                           close=100.4),
                                    Candle(time=1, open=100.4, high=100.6,
                                           low=100.2, close=100.5), c],
                                   Direction.LONG, ["engulfing", "pin_bar",
                                                    "momentum_close"])
        assert not r.confirmed


class TestZoneStrengthWeighting:
    """Zone.strength (departure quality) was computed and stored but never
    actually used in scoring - a barely-qualifying departure and a violent
    displacement scored identically. Now it must scale the score."""

    def _zone(self, strength, status=ZoneStatus.FRESH):
        return Zone(id="z", kind=ZoneKind.DEMAND, timeframe="M15",
                   upper=99.6, lower=99.2, created_index=5, created_time=0,
                   creation_candle=6, impulse_size=0.8, atr_at_creation=0.5,
                   strength=strength, status=status)

    def test_stronger_departure_scores_higher(self):
        from app.strategy.confluence import _zone_score
        w = StrategyConfig().weights
        weak = _zone_score(self._zone(0.5), w)
        strong = _zone_score(self._zone(4.0), w)
        assert strong > weak > 0

    def test_score_is_capped_not_unbounded(self):
        from app.strategy.confluence import _zone_score
        w = StrategyConfig().weights
        huge = _zone_score(self._zone(1000.0), w)
        modest = _zone_score(self._zone(10.0), w)
        assert huge == modest  # both hit the cap, not proportional to 1000x

    def test_status_ordering_preserved(self):
        from app.strategy.confluence import _zone_score
        w = StrategyConfig().weights
        fresh = _zone_score(self._zone(1.0, ZoneStatus.FRESH), w)
        respected = _zone_score(self._zone(1.0, ZoneStatus.RESPECTED), w)
        tested = _zone_score(self._zone(1.0, ZoneStatus.TESTED), w)
        assert fresh > respected > tested > 0

    def test_none_zone_scores_zero(self):
        from app.strategy.confluence import _zone_score
        assert _zone_score(None, StrategyConfig().weights) == 0.0


class TestFVGAsAreaOfInterest:
    """FVGs must work as an alternative area of interest alongside
    zone/level/PD-level, per spec - especially for XAUUSD/BTCUSD scalping
    where a fresh FVG is often the actual reason to be looking at price
    here at all."""

    def test_fresh_fvg_alone_satisfies_area_gate(self):
        candles = candles_from(price_path())
        last = candles[-1].close
        fvg = FVG(kind="bullish", upper=last + 0.05, lower=last - 0.05,
                 displacement_index=len(candles) - 10,
                 displacement_time=candles[-10].time,
                 displacement_body_ratio=0.8, size_atr=1.0, status="fresh")
        b = bundle_from(candles, Trend.BULLISH, zone=None, fvgs=[fvg])
        setups = build_setups(b, StrategyConfig())
        longs = [s for s in setups if s.direction is Direction.LONG]
        assert longs
        assert "no_zone_or_level_interaction" not in longs[0].gates_failed

    def test_no_area_still_fails_without_fvg(self):
        candles = candles_from(price_path())
        b = bundle_from(candles, Trend.BULLISH, zone=None, fvgs=[])
        setups = build_setups(b, StrategyConfig())
        longs = [s for s in setups if s.direction is Direction.LONG]
        assert longs and "no_zone_or_level_interaction" in longs[0].gates_failed

    def test_filled_fvg_does_not_satisfy_area_gate(self):
        candles = candles_from(price_path())
        last = candles[-1].close
        filled = FVG(kind="bullish", upper=last + 0.05, lower=last - 0.05,
                    displacement_index=1, displacement_time=1,
                    displacement_body_ratio=0.8, size_atr=1.0, status="filled")
        b = bundle_from(candles, Trend.BULLISH, zone=None, fvgs=[filled])
        setups = build_setups(b, StrategyConfig())
        longs = [s for s in setups if s.direction is Direction.LONG]
        assert longs and "no_zone_or_level_interaction" in longs[0].gates_failed


class TestConceptExclusivity:
    """Disabling a concept must make it invisible to build_setups() - not
    just down-weighted. A user who unchecks Supply & Demand must never have
    a zone silently satisfy the area gate or add to the score, and the
    reverse for Support & Resistance. This is what keeps strategies from
    blending when the user explicitly asked for only one."""

    def test_default_config_enables_all_concepts(self):
        # No surprise behavior change for existing configs/tests.
        cfg = StrategyConfig()
        assert set(cfg.enabled_concepts) == {
            "supply_demand", "support_resistance", "fair_value_gap", "liquidity_sweep"
        }

    def test_zone_ignored_when_supply_demand_disabled(self):
        cfg = StrategyConfig(enabled_concepts=["support_resistance"])
        candles = candles_from(price_path())
        last = candles[-1].close
        zone = Zone(id="z1", kind=ZoneKind.DEMAND, timeframe="M15",
                   upper=last + 0.1, lower=last - 0.1, created_index=5,
                   created_time=0, creation_candle=6, impulse_size=0.8,
                   atr_at_creation=0.5, strength=2.0, status=ZoneStatus.FRESH)
        setups = build_setups(bundle_from(candles, Trend.BULLISH, zone, cfg), cfg)
        longs = [s for s in setups if s.direction is Direction.LONG]
        assert longs
        # With supply_demand off and nothing else providing an area, the
        # zone must NOT satisfy the area gate - even though a demand zone
        # sits exactly at price.
        assert "no_zone_or_level_interaction" in longs[0].gates_failed
        assert longs[0].zone is None

    def test_zone_counts_when_supply_demand_enabled(self):
        cfg = StrategyConfig(enabled_concepts=["supply_demand"])
        candles = candles_from(price_path())
        last = candles[-1].close
        zone = Zone(id="z1", kind=ZoneKind.DEMAND, timeframe="M15",
                   upper=last + 0.1, lower=last - 0.1, created_index=5,
                   created_time=0, creation_candle=6, impulse_size=0.8,
                   atr_at_creation=0.5, strength=2.0, status=ZoneStatus.FRESH)
        setups = build_setups(bundle_from(candles, Trend.BULLISH, zone, cfg), cfg)
        longs = [s for s in setups if s.direction is Direction.LONG]
        assert longs
        assert "no_zone_or_level_interaction" not in longs[0].gates_failed
        assert longs[0].zone is not None

    def test_sr_level_ignored_when_support_resistance_disabled(self):
        cfg = StrategyConfig(enabled_concepts=["supply_demand"])  # SR off
        candles = candles_from(price_path())
        last = candles[-1].close
        sr = SRAnalysis(levels=[Level(price=last, kind="support", touches=3,
                                      first_time=0, last_time=candles[-1].time,
                                      confidence=0.9)], prev_day={})
        b = AnalysisBundle(symbol="TEST", entry_tf="M15", entry_candles=candles,
                           htf_bias=Trend.BULLISH, zones=ZoneAnalysis(zones=[]),
                           sr=sr, entry_structure=StructureAnalysis(events=[]),
                           sweeps=[], trendlines=[], fvgs=[], atr=0.5, point_size=0.01)
        setups = build_setups(b, cfg)
        longs = [s for s in setups if s.direction is Direction.LONG]
        assert longs
        # SR is the ONLY thing that could have satisfied the area gate here;
        # with it disabled and no zone/FVG, the setup must fail the gate.
        assert "no_zone_or_level_interaction" in longs[0].gates_failed

    def test_fvg_ignored_when_fair_value_gap_disabled(self):
        cfg = StrategyConfig(enabled_concepts=["supply_demand"])  # FVG off
        candles = candles_from(price_path())
        last = candles[-1].close
        fvg = FVG(kind="bullish", upper=last + 0.05, lower=last - 0.05,
                 displacement_index=len(candles) - 10,
                 displacement_time=candles[-10].time,
                 displacement_body_ratio=0.8, size_atr=1.0, status="fresh")
        b = bundle_from(candles, Trend.BULLISH, zone=None, fvgs=[fvg], cfg=cfg)
        setups = build_setups(b, cfg)
        longs = [s for s in setups if s.direction is Direction.LONG]
        assert longs and "no_zone_or_level_interaction" in longs[0].gates_failed

    def test_sweep_ignored_when_liquidity_sweep_disabled(self):
        cfg = StrategyConfig(enabled_concepts=["supply_demand", "liquidity_sweep"])
        candles = candles_from(price_path())
        last = candles[-1].close
        zone = Zone(id="z1", kind=ZoneKind.DEMAND, timeframe="M15",
                   upper=last + 0.1, lower=last - 0.1, created_index=5,
                   created_time=0, creation_candle=6, impulse_size=0.8,
                   atr_at_creation=0.5, strength=2.0, status=ZoneStatus.FRESH)
        sweep = Sweep(timeframe="M15", direction=Direction.LONG, index=len(candles) - 3,
                     time=candles[-3].time, swept_level=last - 0.2,
                     sweep_price=last - 0.25, penetration=0.3, pool_size=1,
                     is_pool=False)
        with_sweep = build_setups(
            bundle_from(candles, Trend.BULLISH, zone, cfg, sweeps=[sweep]), cfg)
        cfg_no_sweep = StrategyConfig(enabled_concepts=["supply_demand"])
        without_sweep = build_setups(
            bundle_from(candles, Trend.BULLISH, zone, cfg_no_sweep, sweeps=[sweep]),
            cfg_no_sweep)
        long_with = [s for s in with_sweep if s.direction is Direction.LONG][0]
        long_without = [s for s in without_sweep if s.direction is Direction.LONG][0]
        # Same candles/zone/sweep data - only the toggle differs. Disabling
        # liquidity_sweep must never leave the sweep's score contribution in
        # place, and must never attach it as the setup's `sweep` field.
        assert long_without.sweep is None
        assert not any("sweep" in r for r in long_without.reasons)
        assert long_with.score >= long_without.score

    def test_multiple_concepts_can_be_enabled_together(self):
        # supply_demand + fair_value_gap together (multi-select) - both
        # should be able to contribute in the same scan.
        cfg = StrategyConfig(enabled_concepts=["supply_demand", "fair_value_gap"])
        candles = candles_from(price_path())
        last = candles[-1].close
        zone = Zone(id="z1", kind=ZoneKind.DEMAND, timeframe="M15",
                   upper=last + 0.1, lower=last - 0.1, created_index=5,
                   created_time=0, creation_candle=6, impulse_size=0.8,
                   atr_at_creation=0.5, strength=2.0, status=ZoneStatus.FRESH)
        setups = build_setups(bundle_from(candles, Trend.BULLISH, zone, cfg), cfg)
        longs = [s for s in setups if s.direction is Direction.LONG]
        assert longs and "no_zone_or_level_interaction" not in longs[0].gates_failed


class TestSweepDeduplication:
    """A zone with liquidity_swept=True plus a matching Sweep in
    bundle.sweeps used to add w.liquidity_sweep*0.5 AND w.liquidity_sweep
    independently for what is realistically one underlying event. Must now
    contribute once."""

    def test_only_one_liquidity_reason_recorded(self):
        candles = candles_from(price_path())
        zone = Zone(id="z1", kind=ZoneKind.DEMAND, timeframe="M15",
                   upper=candles[-1].close + 0.4, lower=candles[-1].close - 0.4,
                   created_index=5, created_time=candles[0].time,
                   creation_candle=6, impulse_size=0.8, atr_at_creation=0.5,
                   strength=1.6, liquidity_swept=True)
        sweep = Sweep(swept_level=zone.lower, sweep_price=zone.lower - 0.1,
                     direction=Direction.LONG, timeframe="M15",
                     index=len(candles) - 3, time=candles[-3].time,
                     penetration=0.1, pool_size=1, is_pool=False)
        b = bundle_from(candles, Trend.BULLISH, zone=zone, sweeps=[sweep])
        setups = build_setups(b, StrategyConfig())
        longs = [s for s in setups if s.direction is Direction.LONG]
        assert longs
        liq_reasons = [r for r in longs[0].reasons
                       if r.startswith(("zone_had_liquidity_sweep",
                                        "liquidity_sweep@", "recent_sweep@"))]
        assert len(liq_reasons) == 1


class TestSweepToShiftSequence:
    """A sweep immediately followed by a same-direction structure shift is a
    distinct signal from either alone - the causal sequence the spec asks
    for ('evaluate what happens AFTER the sweep')."""

    def _bundle_with_gap(self, gap_bars):
        candles = candles_from(price_path(n=100))
        zone = Zone(id="z1", kind=ZoneKind.DEMAND, timeframe="M15",
                   upper=candles[-1].close + 0.4, lower=candles[-1].close - 0.4,
                   created_index=5, created_time=candles[0].time,
                   creation_candle=6, impulse_size=0.8, atr_at_creation=0.5,
                   strength=1.6)
        sweep_index = len(candles) - 15
        struct_index = sweep_index + gap_bars
        sweep = Sweep(swept_level=zone.lower, sweep_price=zone.lower - 0.1,
                     direction=Direction.LONG, timeframe="M15",
                     index=sweep_index, time=candles[sweep_index].time,
                     penetration=0.1, pool_size=1, is_pool=False)
        ev = StructureEvent(kind=StructureEventKind.CHOCH, direction=Direction.LONG,
                            level=candles[struct_index].close, index=struct_index,
                            time=candles[struct_index].time,
                            close=candles[struct_index].close)
        return bundle_from(candles, Trend.BULLISH, zone=zone, sweeps=[sweep],
                           struct_events=[ev])

    def test_sequence_bonus_within_window(self):
        b = self._bundle_with_gap(gap_bars=3)
        setups = build_setups(b, StrategyConfig())
        longs = [s for s in setups if s.direction is Direction.LONG]
        assert longs and "sweep_to_shift_sequence" in longs[0].reasons

    def test_no_bonus_outside_window(self):
        b = self._bundle_with_gap(gap_bars=14)
        setups = build_setups(b, StrategyConfig())
        longs = [s for s in setups if s.direction is Direction.LONG]
        assert longs and "sweep_to_shift_sequence" not in longs[0].reasons
