"""Fair Value Gap detection - this module did not exist before this task."""

from app.market.candles import Candle
from app.strategy.fvg import FVGAnalysis, detect_fvgs


def c(t, o, h, l, cl):
    return Candle(time=t, open=o, high=h, low=l, close=cl)


class TestDetectFVGs:
    def test_bullish_displacement_creates_gap(self):
        candles = [
            c(0, 100.0, 100.1, 99.9, 100.0),
            c(1, 100.0, 100.05, 99.95, 100.0),   # prev: high=100.05
            c(2, 100.1, 101.5, 100.05, 101.4),   # displacement, strong body
            c(3, 101.4, 101.6, 101.2, 101.5),    # next: low=101.2 > prev.high
        ] + [c(4 + i, 101.5, 101.6, 101.4, 101.5) for i in range(10)]
        gaps = detect_fvgs(candles, atr_value=0.2, min_gap_atr_mult=0.1,
                           min_displacement_body_ratio=0.3)
        bullish = [g for g in gaps if g.kind == "bullish"]
        assert bullish
        g = bullish[0]
        assert g.lower == 100.05
        assert g.upper == 101.2

    def test_bearish_displacement_creates_gap(self):
        candles = [
            c(0, 100.0, 100.1, 99.9, 100.0),
            c(1, 100.0, 100.05, 99.95, 100.0),   # prev: low=99.95
            c(2, 99.9, 99.95, 98.5, 98.6),        # displacement down
            c(3, 98.6, 98.8, 98.4, 98.5),          # next: high=98.8 < prev.low
        ] + [c(4 + i, 98.5, 98.6, 98.4, 98.5) for i in range(10)]
        gaps = detect_fvgs(candles, atr_value=0.2, min_gap_atr_mult=0.1,
                           min_displacement_body_ratio=0.3)
        bearish = [g for g in gaps if g.kind == "bearish"]
        assert bearish

    def test_no_gap_when_candles_overlap(self):
        candles = [c(i, 100 + i * 0.01, 100.05 + i * 0.01, 99.95 + i * 0.01,
                     100 + i * 0.01) for i in range(10)]
        gaps = detect_fvgs(candles, atr_value=0.2)
        assert gaps == []

    def test_small_gap_filtered_by_min_gap_atr_mult(self):
        # a real but tiny gap - must be rejected when below the ATR threshold
        candles = [
            c(0, 100.0, 100.1, 99.9, 100.0),
            c(1, 100.0, 100.05, 99.95, 100.0),
            c(2, 100.0, 100.5, 100.0, 100.45),
            c(3, 100.46, 100.55, 100.06, 100.5),  # gap only 0.01 wide
        ] + [c(4 + i, 100.5, 100.6, 100.4, 100.5) for i in range(10)]
        gaps = detect_fvgs(candles, atr_value=1.0, min_gap_atr_mult=0.15)
        assert gaps == []

    def test_weak_displacement_body_filtered(self):
        candles = [
            c(0, 100.0, 100.1, 99.9, 100.0),
            c(1, 100.0, 100.05, 99.95, 100.0),
            c(2, 100.5, 101.5, 100.0, 100.55),    # huge range, tiny body = doji-like
            c(3, 101.4, 101.6, 101.2, 101.5),
        ] + [c(4 + i, 101.5, 101.6, 101.4, 101.5) for i in range(10)]
        gaps = detect_fvgs(candles, atr_value=0.2, min_gap_atr_mult=0.1,
                           min_displacement_body_ratio=0.8)
        assert gaps == []

    def test_fresh_status_when_never_revisited(self):
        candles = [
            c(0, 100.0, 100.1, 99.9, 100.0),
            c(1, 100.0, 100.05, 99.95, 100.0),
            c(2, 100.1, 101.5, 100.05, 101.4),
            c(3, 101.4, 101.6, 101.2, 101.5),
        ] + [c(4 + i, 101.5 + i * 0.1, 101.6 + i * 0.1, 101.4 + i * 0.1,
               101.5 + i * 0.1) for i in range(10)]  # trends away, never returns
        gaps = detect_fvgs(candles, atr_value=0.2, min_gap_atr_mult=0.1,
                           min_displacement_body_ratio=0.3)
        assert gaps and gaps[0].status == "fresh"

    def test_filled_status_when_price_closes_through(self):
        candles = [
            c(0, 100.0, 100.1, 99.9, 100.0),
            c(1, 100.0, 100.05, 99.95, 100.0),
            c(2, 100.1, 101.5, 100.05, 101.4),
            c(3, 101.4, 101.6, 101.2, 101.5),
            c(4, 101.4, 101.5, 99.5, 99.6),        # closes back below gap.lower
        ] + [c(5 + i, 99.6, 99.7, 99.5, 99.6) for i in range(10)]
        gaps = detect_fvgs(candles, atr_value=0.2, min_gap_atr_mult=0.1,
                           min_displacement_body_ratio=0.3)
        assert gaps and gaps[0].status == "filled"
        assert gaps[0].fill_index is not None


class TestFVGAnalysis:
    def test_nearest_active_excludes_filled(self):
        from app.strategy.fvg import FVG
        fresh = FVG(kind="bullish", upper=101.2, lower=100.05,
                    displacement_index=2, displacement_time=2,
                    displacement_body_ratio=0.8, size_atr=1.0, status="fresh")
        filled = FVG(kind="bullish", upper=99.2, lower=99.05,
                     displacement_index=1, displacement_time=1,
                     displacement_body_ratio=0.8, size_atr=1.0, status="filled")
        analysis = FVGAnalysis(gaps=[fresh, filled])
        result = analysis.nearest_active(100.5, "bullish", max_distance=5.0)
        assert result is fresh

    def test_nearest_active_returns_none_when_none_match_kind(self):
        from app.strategy.fvg import FVG
        bearish = FVG(kind="bearish", upper=101.2, lower=100.05,
                      displacement_index=2, displacement_time=2,
                      displacement_body_ratio=0.8, size_atr=1.0, status="fresh")
        analysis = FVGAnalysis(gaps=[bearish])
        assert analysis.nearest_active(100.5, "bullish", max_distance=5.0) is None
