"""Supply/demand zone detection + lifecycle tests (spec section 7)."""

import pytest

from app.config import StrategyConfig
from app.constants import ZoneKind, ZoneStatus
from app.market.candles import Candle
from app.zones.detector import analyze_zones, detect_zones


def make_candles(rows, tf_minutes=60, start=1_700_000_000):
    out, t = [], start
    for o, h, l, c in rows:
        out.append(Candle(time=t, open=o, high=h, low=l, close=c))
        t += tf_minutes * 60
    return out


def drop_base_rally(after_rows=None):
    """Classic demand pattern: drift down -> drop -> base -> strong rally."""
    rows = [
        # pre-context drift (keeps ATR realistic)
        (100.0, 100.4, 99.7, 100.2),
        (100.2, 100.6, 100.0, 100.4),
        (100.4, 100.8, 100.2, 100.6),
        # drop
        (100.6, 100.8, 99.4, 99.6),
        (99.6, 99.8, 98.6, 98.8),
        # base (consolidation at the low)
        (98.8, 99.0, 98.4, 98.6),
        (98.6, 98.9, 98.4, 98.8),
        # rally (impulse)
        (98.8, 99.9, 98.7, 99.8),
        (99.8, 100.9, 99.7, 100.8),
        (100.8, 101.9, 100.7, 101.8),
    ]
    if after_rows:
        rows = rows + after_rows
    return make_candles(rows)


class TestDetection:
    def test_demand_zone_created(self):
        zones = detect_zones(drop_base_rally(), "H1", impulse_atr_mult=0.8)
        assert any(z.kind is ZoneKind.DEMAND for z in zones)
        demand = [z for z in zones if z.kind is ZoneKind.DEMAND][0]
        assert demand.lower <= 98.9
        assert demand.upper >= 98.4
        assert demand.strength > 0
        assert demand.timeframe == "H1"

    def test_metadata_complete(self):
        zones = detect_zones(drop_base_rally(), "H1", impulse_atr_mult=0.8)
        assert zones, "expected at least one zone"
        z = zones[0]
        assert z.created_time > 0
        assert z.impulse_size > 0
        assert z.atr_at_creation > 0


class TestLifecycle:
    def test_fresh_before_touch(self):
        candles = drop_base_rally([
            (101.8, 102.4, 101.7, 102.2),
            (102.2, 102.6, 102.0, 102.4),
        ])
        zones = detect_zones(candles, "H1", impulse_atr_mult=0.8)
        demand = [z for z in zones if z.kind is ZoneKind.DEMAND][0]
        assert demand.status is ZoneStatus.FRESH
        assert demand.touches == 0

    def test_tested_then_respected(self):
        candles = drop_base_rally([
            # price returns into the demand area and rallies away strongly
            (101.8, 101.9, 99.0, 99.4),
            (99.4, 100.9, 99.3, 100.8),
            (100.8, 102.0, 100.7, 101.9),
        ])
        zones = detect_zones(candles, "H1", impulse_atr_mult=0.8)
        demand = [z for z in zones if z.kind is ZoneKind.DEMAND][0]
        assert demand.touches >= 1
        assert demand.status is not ZoneStatus.FRESH
        assert demand.status in (ZoneStatus.TESTED, ZoneStatus.RESPECTED)

    def test_body_close_through_invalidates(self):
        candles = drop_base_rally([
            # crash: body closes below the zone low
            (101.8, 101.9, 98.5, 98.7),
            (98.7, 98.9, 96.8, 97.0),
            (97.0, 97.2, 95.9, 96.1),
        ])
        zones = detect_zones(candles, "H1", impulse_atr_mult=0.8)
        demand = [z for z in zones if z.kind is ZoneKind.DEMAND]
        assert demand
        assert all(z.status is ZoneStatus.INVALIDATED for z in demand)

    def test_wick_through_does_NOT_invalidate(self):
        candles = drop_base_rally([
            # wick below the zone low but close back inside/above
            (101.8, 101.9, 98.0, 99.6),
            (99.6, 100.8, 99.4, 100.7),
            (100.7, 101.6, 100.5, 101.5),
        ])
        zones = detect_zones(candles, "H1", impulse_atr_mult=0.8)
        demand = [z for z in zones if z.kind is ZoneKind.DEMAND][0]
        assert demand.status is not ZoneStatus.INVALIDATED


class TestSupply:
    def test_supply_zone_created(self):
        # mirror: rally -> base at the high -> drop
        rows = [
            (98.0, 98.4, 97.7, 98.2),
            (98.2, 98.6, 98.0, 98.4),
            (98.4, 98.8, 98.2, 98.6),
            # rally
            (98.6, 99.6, 98.5, 99.5),
            (99.5, 100.5, 99.4, 100.4),
            # base at the top
            (100.4, 100.9, 100.2, 100.5),
            (100.5, 100.8, 100.1, 100.3),
            # drop (impulse)
            (100.3, 100.4, 99.2, 99.4),
            (99.4, 99.5, 98.3, 98.5),
            (98.5, 98.6, 97.4, 97.6),
        ]
        zones = detect_zones(make_candles(rows), "H1", impulse_atr_mult=0.8)
        assert any(z.kind is ZoneKind.SUPPLY for z in zones)


class TestAnalysis:
    def test_active_zones_exclude_invalidated(self):
        candles = drop_base_rally([
            (101.8, 101.9, 98.5, 98.7),
            (98.7, 98.9, 96.8, 97.0),
            (97.0, 97.2, 95.9, 96.1),
        ])
        za = analyze_zones(candles, "H1", StrategyConfig())
        assert za.active_zones(ZoneKind.DEMAND) == []
