"""Emergency stop behaviour (spec section 21)."""

import pytest

from app.config import Config
from app.constants import BotState
from app.engine import Engine
from app.journal.journal import Journal
from app.state_store import StateStore, TradeRecord, utc_now_ms
from tests.fakes import FakeBroker


@pytest.fixture
def engine(tmp_path):
    cfg = Config()
    cfg.management.emergency_cancel_pending = True
    cfg.management.emergency_close_positions = True
    store = StateStore(tmp_path / "t.db")
    broker = FakeBroker()
    eng = Engine(cfg, broker, None, store, Journal(store))
    return eng, cfg, broker, store


class TestEmergencyStop:
    def test_state_transitions(self, engine):
        eng, *_ = engine
        assert eng.bot_state is BotState.STOPPED
        eng.handle_command("start", {})
        assert eng.bot_state is BotState.RUNNING
        eng.handle_command("pause", {})
        assert eng.bot_state is BotState.PAUSED
        eng.handle_command("emergency", {})
        assert eng.bot_state is BotState.EMERGENCY_STOP

    def test_emergency_cancels_pendings_and_closes_positions(self, engine):
        eng, cfg, broker, store = engine
        broker.limit_order("EURUSD", "buy", 0.1, 1.09, 1.08, 1.11,
                           comment="BBFX:test", magic=cfg.execution.magic)
        broker.market_order("EURUSD", "buy", 0.1, 1.08, 1.11,
                            comment="BBFX:test", magic=cfg.execution.magic)
        assert broker.pending_orders() and broker.positions()
        eng.handle_command("emergency", {})
        assert not broker.pending_orders()
        assert not broker.positions()

    def test_start_refused_while_emergency(self, engine):
        eng, *_ = engine
        eng.handle_command("emergency", {})
        res = eng.handle_command("start", {})
        assert not res["ok"]
        assert eng.bot_state is BotState.EMERGENCY_STOP

    def test_resume_clears_emergency(self, engine):
        eng, *_ = engine
        eng.handle_command("emergency", {})
        res = eng.handle_command("resume", {})
        assert res["ok"]
        assert eng.bot_state is BotState.RUNNING

    def test_unknown_command_refused(self, engine):
        eng, *_ = engine
        res = eng.handle_command("buy_eurusd_now", {})
        assert not res["ok"]

    def test_emergency_event_recorded(self, engine):
        eng, _, _, store = engine
        eng.handle_command("emergency", {})
        rows = store.query("SELECT * FROM events WHERE message LIKE '%EMERGENCY%'")
        assert rows
