"""Pending-order validation, duplicates and cancellation (spec section 14)."""

import pytest

from app.config import Config
from app.constants import Direction
from app.execution.executor import Executor
from app.journal.journal import Journal
from app.state_store import StateStore
from tests.fakes import FakeBroker


@pytest.fixture
def setup(tmp_path):
    cfg = Config()
    cfg.execution.duplicate_window_seconds = 60
    store = StateStore(tmp_path / "t.db")
    broker = FakeBroker()
    journal = Journal(store)
    ex = Executor(cfg, broker, store, journal)
    return cfg, broker, store, journal, ex


class TestPendingBasics:
    def test_limit_order_requires_sl(self, setup):
        _, broker, _, _, ex = setup
        res = ex.place_limit("su-1", "EURUSD", Direction.LONG, 0.1, 1.0950,
                             sl=0, tp=1.1050, expiry_ms=None)
        assert not res["ok"]
        assert not broker.sent_limits

    def test_limit_order_placed_with_expiry(self, setup):
        _, broker, _, _, ex = setup
        res = ex.place_limit("su-2", "EURUSD", Direction.LONG, 0.1, 1.0950,
                             sl=1.0930, tp=1.1050, expiry_ms=99_999_999_999_999)
        assert res["ok"]
        assert broker.sent_limits[0]["expiration_ms"] == 99_999_999_999_999

    def test_duplicate_pending_suppressed(self, setup):
        _, broker, store, _, ex = setup
        r1 = ex.place_limit("su-3", "EURUSD", Direction.LONG, 0.1, 1.0950,
                            sl=1.0930, tp=1.1050, expiry_ms=None)
        assert r1["ok"]
        r2 = ex.place_limit("su-3", "EURUSD", Direction.LONG, 0.1, 1.0950,
                            sl=1.0930, tp=1.1050, expiry_ms=None)
        assert not r2["ok"] and r2.get("duplicate")
        assert len(broker.sent_limits) == 1

    def test_second_pending_same_symbol_refused(self, setup):
        cfg, broker, store, _, ex = setup
        r1 = ex.place_limit("su-4", "EURUSD", Direction.LONG, 0.1, 1.0950,
                            sl=1.0930, tp=1.1050, expiry_ms=None)
        assert r1["ok"]
        # different setup id -> not an idempotency hit, but similar-pending guard
        r2 = ex.place_limit("su-5", "EURUSD", Direction.LONG, 0.2, 1.0940,
                            sl=1.0920, tp=1.1050, expiry_ms=None)
        assert not r2["ok"] and "pending" in r2["reason"]

    def test_cancel_pending(self, setup):
        _, broker, _, _, ex = setup
        res = ex.place_limit("su-6", "EURUSD", Direction.LONG, 0.1, 1.0950,
                             sl=1.0930, tp=1.1050, expiry_ms=None)
        ticket = res["ticket"]
        assert ex.cancel_pending(ticket, reason="expired")
        assert broker.cancelled == [ticket]


class TestMarketOrderGuards:
    def test_market_duplicate_suppressed(self, setup):
        _, broker, _, _, ex = setup
        r1 = ex.place_market("su-7", "EURUSD", Direction.LONG, 0.1, 1.0950, 1.1100)
        r2 = ex.place_market("su-7", "EURUSD", Direction.LONG, 0.1, 1.0950, 1.1100)
        assert r1["ok"] and not r2["ok"] and r2.get("duplicate")
        assert len(broker.sent_market) == 1
