# BRAIDER BOT FX — Full VPS Installation Guide
**Scenario: ONE Windows VPS with MT5 + Python already installed (everything runs on this single machine).**
This is the simplest and safest setup: the strategy engine and the MT5 bridge talk to each other over `127.0.0.1` only — **no firewall ports need to be opened at all.**

> Using a separate Linux VPS for the engine instead? Do steps 1–6 the same
> (skip `MetaTrader5` in step 3), then see **Appendix B** at the bottom.

Follow the phases in order. Do not skip the PAPER-mode phase — it proves the
installation is healthy before any broker connection.

---

## Phase 0 — Pre-flight checks (2 minutes)

Open **PowerShell** on the VPS (Start → type "PowerShell") and run:

```powershell
python --version
```
✔ You want **3.10, 3.11 or 3.12**. If `python` opens the Microsoft Store instead, see Troubleshooting T1.

Check Python is **64-bit** (the MetaTrader5 package needs 64-bit Python to match the 64-bit MT5 terminal):

```powershell
python -c "import struct; print(struct.calcsize('P')*8, 'bit')"
```
✔ Must print `64 bit`. If it prints `32 bit`, reinstall Python 64-bit (T2).

Check MT5 is installed and you can log in:

1. Open **MetaTrader 5**.
2. File → *Login to Trade Account* → enter login / password / server of your **DEMO account**.
3. Bottom-right of the terminal shows connection quality (bars) and your login number.
4. **Important:** click the **Algo Trading** button on the top toolbar so it turns **green/play**. Orders are refused without it.

Keep MT5 **open and logged in** from now on.

---

## Phase 1 — Put the project on the VPS (5 minutes)

1. Download `BRAIDER-BOT-FX-ENGINE.zip` (from this chat) on your own PC.
2. Copy it to the VPS (RDP: just copy the file on your PC, then right-click → paste on the VPS desktop), or upload via any file manager your VPS provider gives you.
3. Extract it to `C:\` so you get the folder **`C:\braider_bot_fx_engine`**:

```powershell
Expand-Archive -Path "$HOME\Downloads\BRAIDER-BOT-FX-ENGINE.zip" -DestinationPath "C:\" -Force
cd C:\braider_bot_fx_engine
dir
```
✔ You should see: `app`, `mt5_bridge`, `backtest`, `tests`, `scripts`, `config`, `deploy`, `requirements.txt`, `.env.example`, `README.md`.

---

## Phase 2 — Install the Python dependencies (5 minutes)

```powershell
cd C:\braider_bot_fx_engine

# create an isolated environment for the bot
python -m venv .venv

# activate it (PowerShell)
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force
.\.venv\Scripts\Activate.ps1
```
✔ Your prompt now starts with `(.venv)`.

```powershell
python -m pip install --upgrade pip
pip install -r requirements.txt

# the MT5 connector (Windows only - this is what talks to your terminal)
pip install MetaTrader5
```
✔ No red errors. Warnings in yellow are fine.

> If you prefer CMD instead of PowerShell, activate with `.venv\Scripts\activate.bat`.

---

## Phase 3 — Verify the installation (3 minutes)

Run the automated test suite — 124 checks of the risk/sizing/safety logic:

```powershell
python -m pytest tests/ -q
```
✔ Must end with **`124 passed`**. If any fail, STOP and see Troubleshooting T5.

---

## Phase 4 — PAPER mode first run (no broker, totally safe) (10 minutes)

This proves the whole engine works using a built-in simulator.

```powershell
# 1. create .env from the template
Copy-Item .env.example .env
notepad .env
```
For paper mode you only need one line changed (the defaults are already safe):
```
BBFX_EXECUTION_MODE=paper
```
Save and close Notepad, then:

```powershell
# 2. generate demo price data so the simulator has candles to read
python scripts/generate_demo_data.py --symbol EURUSD
python scripts/generate_demo_data.py --symbol XAUUSD

# 3. start the engine (keep this window open)
python -m app.main
```
✔ You should see:
```
API listening on 0.0.0.0:8000
BRAIDER BOT FX engine ready | mode=paper symbols=[...]
engine loop starting mode=paper
```

Leave it running ~10 minutes. Every scan decision is being recorded —
including every reason it did NOT trade. Check the journal from a **second**
PowerShell window:

```powershell
curl http://127.0.0.1:8000/status
curl "http://127.0.0.1:8000/setups?limit=10"
type logs\engine.log
```
✔ `/status` shows `"mode":"paper"` and `"connected":true`.

Stop the engine with `CTRL+C`. Paper mode is complete — your installation
works. Now we connect the real MT5 terminal.

---

## Phase 5 — Create your secret tokens (2 minutes)

Generate two long random tokens (one for the bridge, one for the engine API):

```powershell
$chars = 48..57 + 65..90 + 97..122
$bridgeToken = -join (1..48 | ForEach-Object { [char](Get-Random -InputObject $chars) })
$apiToken    = -join (1..48 | ForEach-Object { [char](Get-Random -InputObject $chars) })
Write-Host "BRIDGE_TOKEN = $bridgeToken"
Write-Host "API_TOKEN    = $apiToken"
```
**Copy both values into Notepad now** — you'll paste them in the next step.

---

## Phase 6 — Configure `.env` for DEMO mode (5 minutes)

Open the config again:

```powershell
notepad .env
```
Edit it to look like this (paste your own tokens):

```ini
# ---- execution mode ----
BBFX_EXECUTION_MODE=demo
LIVE_TRADING_ENABLED=false

# ---- MT5 bridge (same machine = localhost) ----
BBFX_BRIDGE_URL=http://127.0.0.1:8001
BRIDGE_TOKEN=paste-the-bridge-token-here

# MT5 auto-login (OPTIONAL - easiest is to stay logged in via the terminal
# window itself; if you fill these in, the bridge can re-login after a restart)
MT5_LOGIN=12345678
MT5_PASSWORD=your-mt5-password
MT5_SERVER=YourBroker-Demo
MT5_TERMINAL_PATH=

# ---- engine API ----
API_TOKEN=paste-the-api-token-here

# ---- Firebase (OPTIONAL - only for your website dashboard, see Phase 9) ----
FIREBASE_CREDENTIALS_PATH=
FIREBASE_PROJECT_ID=braider-bot
FIREBASE_USER_UID=
```

Next, check the **symbol mapping** matches your broker's symbol names:

```powershell
notepad config\config.yaml
```
In the `symbols:` section, set the right-hand side to the names your broker
shows in MT5 **Market Watch** (right-click a symbol in Market Watch → the
exact name is shown). Examples:

```yaml
  mapping:
    EURUSD: EURUSD
    GBPUSD: GBPUSD
    USDCAD: USDCAD
    XAUUSD: XAUUSDm      # Exness uses XAUUSDm
    BTCUSD: BTCUSD.a     # example of a broker suffix
```
Also reduce `watched:` to 1–2 symbols for your first days. Save.

---

## Phase 7 — Start the MT5 bridge and connect (5 minutes)

**Window A — the bridge** (keep open):

```powershell
cd C:\braider_bot_fx_engine
.\.venv\Scripts\Activate.ps1
python mt5_bridge\bridge.py
```
✔ You should see:
```
INFO:     Uvicorn running on http://127.0.0.1:8001
```
If it prints `REFUSING to start: set BRIDGE_TOKEN...` → the `.env` isn't saved correctly (check Phase 6).

**Window B — verify the connection to MT5**:

```powershell
cd C:\braider_bot_fx_engine
.\.venv\Scripts\Activate.ps1
python scripts\check_bridge.py
```
✔ Every line should show `[OK]` — health, account (your broker name + balance), each symbol, and rates. The final line must say **`bridge is READY`**.

Common failures:

| Message | Fix |
|---|---|
| `MetaTrader5 package missing` | `pip install MetaTrader5` inside the venv |
| `terminal not attached` / `initialize failed` | MT5 terminal not open, or logged out. Open it, log in, keep it running |
| `unknown symbol: XAUUSD` | Your broker calls it something else → fix `config.yaml` mapping |
| `AutoTrading disabled` | Click the **Algo Trading** button in MT5 so it's green |

---

## Phase 8 — Run the engine in DEMO mode (the real test)

**Window B — the engine**:

```powershell
cd C:\braider_bot_fx_engine
.\.venv\Scripts\Activate.ps1
python -m app.main
```
✔ Log shows `mode=demo`, then scan activity. The engine now:

- reads **real** prices from your broker through the bridge,
- runs the full confluence analysis (HTF bias → zones → structure → liquidity → confirmation),
- journals every decision *with the reason*,
- and only trades when ALL gates + the risk engine approve.

Watch it work:

```powershell
curl http://127.0.0.1:8000/status
curl "http://127.0.0.1:8000/trades?limit=20"
curl "http://127.0.0.1:8000/setups?limit=20"     # every decision + rejection reason
type logs\trades.log
type logs\risk.log
```

**Leave it running for days/weeks in demo.** That is the point of demo mode.
Check the logs once or twice a day. You should see rejections — the bot
refusing ambiguous setups is exactly the discipline you asked for.

Manual controls (from any PowerShell window):

```powershell
# EMERGENCY STOP - cancels pending orders + closes positions, needs manual resume
curl -X POST http://127.0.0.1:8000/command -H "X-API-Token: YOUR_API_TOKEN" -H "Content-Type: application/json" -d "{\"action\":\"emergency\"}"

# pause / stop / start / resume
curl -X POST http://127.0.0.1:8000/command -H "X-API-Token: YOUR_API_TOKEN" -H "Content-Type: application/json" -d "{\"action\":\"pause\"}"
```

---

## Phase 9 — Auto-start on boot (so it survives VPS restarts) (10 minutes)

Two pieces must auto-start: the **bridge** and the **engine** (MT5 itself:
Tools → Options → check *auto login*; Windows usually reopens it).

**Option A — NSSM (recommended, real services with auto-restart):**

Download NSSM (nssm.cc), copy `nssm.exe` to `C:\braider_bot_fx_engine\`, then in an **Administrator** PowerShell:

```powershell
cd C:\braider_bot_fx_engine

.\nssm.exe install BBFX-Bridge "C:\braider_bot_fx_engine\.venv\Scripts\python.exe" "mt5_bridge\bridge.py"
.\nssm.exe set BBFX-Bridge AppDirectory C:\braider_bot_fx_engine
.\nssm.exe set BBFX-Bridge AppStdout C:\braider_bot_fx_engine\logs\bridge-service.log
.\nssm.exe set BBFX-Bridge AppStderr C:\braider_bot_fx_engine\logs\bridge-service.log
.\nssm.exe start BBFX-Bridge

.\nssm.exe install BBFX-Engine "C:\braider_bot_fx_engine\.venv\Scripts\python.exe" "-m" "app.main"
.\nssm.exe set BBFX-Engine AppDirectory C:\braider_bot_fx_engine
.\nssm.exe set BBFX-Engine AppStdout C:\braider_bot_fx_engine\logs\engine-service.log
.\nssm.exe set BBFX-Engine AppStderr C:\braider_bot_fx_engine\logs\engine-service.log
.\nssm.exe start BBFX-Engine
```

Manage them like any Windows service:
```powershell
Get-Service BBFX-*                     # status
Restart-Service BBFX-Engine            # after config changes
Stop-Service BBFX-Bridge               # stop trading
```

**Option B — Task Scheduler (no downloads):** Task Scheduler → *Create Basic
Task* twice (bridge, then engine), trigger "When the computer starts",
action "Start a program":
- Program: `C:\braider_bot_fx_engine\.venv\Scripts\python.exe`
- Arguments: `mt5_bridge\bridge.py`  (or `-m app.main` for the engine)
- Start in: `C:\braider_bot_fx_engine`

---

## Phase 10 — Optional: connect your website (Firebase dashboard)

Your website's buttons write commands to Firestore; the engine watches them.

1. Firebase console (console.firebase.google.com → project **braider-bot**) → ⚙️ Project settings → **Service accounts** → *Generate new private key* → download the JSON.
2. Upload it to the VPS as `C:\braider_bot_fx_engine\firebase-service-account.json`.
3. Copy your website account's UID: Firebase console → Authentication → Users → copy the **User UID**.
4. Edit `.env`:
   ```ini
   FIREBASE_CREDENTIALS_PATH=C:\braider_bot_fx_engine\firebase-service-account.json
   FIREBASE_PROJECT_ID=braider-bot
   FIREBASE_USER_UID=paste-your-uid-here
   ```
5. Restart the engine (`Restart-Service BBFX-Engine` or CTRL+C + rerun).

✔ Log shows `Firebase connected: project=braider-bot uid=xxxxxx***`.
Now: your website's **Start / Pause / Stop / Emergency** buttons control this
engine, and trades/logs/account status appear on the dashboard automatically.
(Keep the service-account JSON private — never in the website code.)

---

## Phase 11 — Backtest with REAL history (before trusting demo trades)

1. In MT5: View → Symbols → select your symbol → **Bars** tab shows history; export it with any MT5-to-CSV exporter (or a small script) into:
   `C:\braider_bot_fx_engine\data\EURUSD_M15.csv`
   Format: `time,open,high,low,close,volume` (time = Unix seconds).
2. Run:
   ```powershell
   python scripts\run_backtest.py --symbol EURUSD
   ```
3. Read **TRAIN vs VALIDATION** separately. If validation is much worse than
   train, the settings are curve-fitted — raise `min_confluence_score`, don't
   lower it. Profit means nothing without drawdown + losing-streak context;
   the report prints those warnings for you.

---

## Phase 12 — Daily operation cheat sheet

| Action | Command |
|---|---|
| Status | `curl http://127.0.0.1:8000/status` |
| Open positions | `curl http://127.0.0.1:8000/positions` |
| Why did/didn't it trade? | `curl "http://127.0.0.1:8000/setups?limit=30"` |
| Trade log | `type logs\trades.log` |
| Risk events | `type logs\risk.log` |
| EMERGENCY stop | `curl -X POST http://127.0.0.1:8000/command -H "X-API-Token: ..." -H "Content-Type: application/json" -d "{\"action\":\"emergency\"}"` |
| Resume after emergency | same but `{"action":"resume"}` |
| Change strategy settings | edit `config\config.yaml` → `Restart-Service BBFX-Engine` |
| Full stop trading | `Stop-Service BBFX-Engine; Stop-Service BBFX-Bridge` (broker-side SL/TP stay active in MT5) |

**Updating the bot:** stop services → copy the new files over (keep `.env`,
`data\`, `logs\`, `firebase-service-account.json`) → `pip install -r
requirements.txt` → `python -m pytest tests/ -q` → start services again.

---

## Phase 13 — Multi-account + website settings (optional)

The engine supports several MT5 accounts through one dashboard and ONE
settings object on the website.

**A. One bridge slot per account** (on the Windows machine):
1. One MT5 terminal per account, each logged into that account.
2. One copy of `mt5_bridge/bridge.py` per terminal, each on its own port
   (8001, 8002, 8003 …) with its own `BRIDGE_TOKEN_<port>` in its `.env`
   (or the same `BRIDGE_TOKEN` for all slots).
3. On the engine VPS `.env`, list the slots:

   ```
   BRIDGE_SLOTS=http://127.0.0.1:8001,http://127.0.0.1:8002,http://127.0.0.1:8003
   ```

**B. Connect accounts from the website**: MT5 Accounts → Connect, enter
broker/server/login/password and Demo or Real. The engine logs that account
into its bridge slot. The password is used once for the login and is never
stored or logged — only a masked number (e.g. `1234****9012`) is kept.

**C. One settings object**: the website Settings page writes
`users/{uid}.botSettings` in Firestore (or `POST /settings`). It contains
everything: trading mode (conservative/balanced/aggressive/scalping), lot
size, risk %, daily-loss/drawdown caps, watched symbols, scalping options
(limit/stop orders, buffers), trade management (partials, break-even,
trailing, scale-in) and the auto-trade switch. The engine applies it live
and mirrors it back; settings survive restarts.

**D. Auto-trade switch**: the bot trades only when RUNNING **and** auto-trade
is ON. Turning it off stops NEW trades instantly (open positions are still
managed). Everything is also gated by the same strategy/risk pipeline —
activation never bypasses safety.

**E. Per-account stats**: wins, losses, win-rate, profit factor, expectancy
and drawdown per account (and totals) are pushed to `users/{uid}.stats` and
available at `GET /stats`.

## Troubleshooting

| # | Problem | Fix |
|---|---|---|
| T1 | `python` opens Microsoft Store | Settings → Apps → *App execution aliases* → turn OFF both `python.exe` aliases, then reopen PowerShell |
| T2 | Python is 32-bit | Uninstall, install the **64-bit** Python 3.11/3.12 from python.org ("Windows installer 64-bit") |
| T3 | `'pip' is not recognized` | Use `python -m pip install ...` instead |
| T4 | `cannot be loaded because running scripts is disabled` | Run `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` first (or use CMD's `activate.bat`) |
| T5 | Tests fail | You're probably outside the venv or install is broken: `pip install -r requirements.txt` again inside `.venv` |
| T6 | Bridge: `MT5 initialize failed` | MT5 not running/logged in; or multiple MT5 installs → set `MT5_TERMINAL_PATH` in `.env` to that terminal's `terminal64.exe` |
| T7 | Orders rejected, retcode **10027** | Enable the **Algo Trading** button in MT5 |
| T8 | Retcode **10018** | Market closed (weekend) — normal, wait |
| T9 | Engine: `bridge unreachable` | Bridge window not running, or `BRIDGE_TOKEN` differs between the two processes |
| T10 | Engine API returns 401 | You forgot the header: `-H "X-API-Token: ..."` |
| T11 | `daily loss limit hit` in logs | Working as designed — protection. Resets next trading day |
| T12 | `stale data` rejections | Market closed, or symbol mapping wrong (check Market Watch names) |
| T13 | Firebase `connect failed` | Wrong path/UID, or the service-account key was deleted/rotated |
| T14 | After VPS reboot nothing runs | Did Phase 9? Check `Get-Service BBFX-*` and that MT5 starts logged-in |

---

## Appendix A — Going LIVE (read twice)

Live = real money. The engine refuses it by default *twice*: it needs
`BBFX_EXECUTION_MODE=live` **and** `LIVE_TRADING_ENABLED=true` in `.env`,
otherwise it exits on startup. Before you even consider it:

1. ✅ At least 2–4 weeks of stable demo (no crashes, sane behaviour)
2. ✅ Backtest on real history with acceptable drawdown, TRAIN≈VALIDATION
3. ✅ Start `per_trade_risk_pct` at **0.25–0.5%**, `max_daily_loss_pct` at 1–2%
4. ✅ Tokens rotated, `.env` private
5. ✅ You can afford to lose the whole account

Then and only then: edit `.env`, restart the engine, and watch the first day
continuously. The bot provides **discipline**, not a profit promise.

## Appendix B — Split setup (Linux VPS engine + Windows VPS bridge)

If your engine runs on a Linux box instead: install per README (`pip install
-r requirements.txt`, systemd unit in `deploy/`), and in its `.env` set
`BBFX_BRIDGE_URL=http://<windows-vps-ip>:8001`. On the Windows box, allow
inbound TCP 8001 **only from the Linux VPS IP**:
```powershell
netsh advfirewall firewall add rule name="bbfx-bridge" dir=in action=allow protocol=TCP localport=8001 remoteip=<LINUX_VPS_IP>
```
Then verify with `python scripts/check_bridge.py --url http://<win-ip>:8001`.
