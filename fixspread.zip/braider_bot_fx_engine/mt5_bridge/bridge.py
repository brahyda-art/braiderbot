"""BRAIDER BOT FX - MT5 Bridge (Windows).

WHY THIS EXISTS
---------------
The MetaTrader5 Python package ONLY works on Windows, attached to a running,
logged-in MT5 terminal.  It cannot run inside a Linux VPS container.  The
correct architecture is therefore:

    [Linux VPS]  Strategy/Risk engine  --HTTPS+token-->  [Windows VPS] MT5 terminal
                                                          + this bridge

This FastAPI service wraps the MetaTrader5 package behind an authenticated,
localhost-bound REST API:

    GET  /health                  connection + terminal status
    GET  /account                 account info
    GET  /symbol?symbol=XAUUSD    trading specifications (tick size/value...)
    GET  /rates?symbol=&tf=&count=  OHLC bars
    GET  /tick?symbol=            last tick (bid/ask/spread)
    GET  /positions               open positions
    GET  /orders                  pending orders
    POST /order/market           market order (SL mandatory)
    POST /order/limit            buy_limit / sell_limit
    POST /position/modify        change SL/TP
    POST /position/close         close (partial supported)
    POST /order/cancel           cancel pending
    GET  /deals?position=<ticket>  realized result of a closed position

SAFETY
------
* Bearer-token auth (BRIDGE_TOKEN env). Requests without it are refused.
* Binds to 127.0.0.1 by default; only expose on the LAN/Tailscale if the
  engine runs on a separate machine.
* Orders WITHOUT a stop loss are rejected at this layer too (defence in
  depth).
* Idempotency: a repeated request with the same idempotency key returns the
  cached result instead of sending a duplicate order.

RUN (on the Windows machine with MT5 installed and logged in):
    pip install -r mt5_bridge/requirements.txt
    set BRIDGE_TOKEN=<long-random-string>
    python mt5_bridge/bridge.py
"""

from __future__ import annotations

import hmac
import os
import time
import threading
from typing import Any, Dict, Optional

from dotenv import load_dotenv

load_dotenv()

from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel

try:
    import MetaTrader5 as mt5
except ImportError:  # pragma: no cover - Linux dev boxes
    mt5 = None

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from app.market.symbol_resolution import resolve_symbol_name  # noqa: E402

# Common install locations tried ONLY if MT5_TERMINAL_PATH is not set and the
# default (last-used terminal) initialize() fails. Never guessed silently -
# every attempt is against a path that actually exists on disk.
COMMON_MT5_PATHS = (
    r"C:\Program Files\MetaTrader 5\terminal64.exe",
    r"C:\Program Files\Exness MetaTrader 5\terminal64.exe",
    r"C:\Program Files (x86)\MetaTrader 5\terminal64.exe",
)

app = FastAPI(title="BRAIDER MT5 Bridge", version="1.0.0",
              docs_url=None, redoc_url=None, openapi_url=None)

BRIDGE_TOKEN = os.environ.get("BRIDGE_TOKEN", "").strip()
MT5_PATH = os.environ.get("MT5_TERMINAL_PATH", "").strip() or None
MT5_LOGIN = os.environ.get("MT5_LOGIN")
MT5_PASSWORD = os.environ.get("MT5_PASSWORD")
MT5_SERVER = os.environ.get("MT5_SERVER")

TIMEFRAME_MAP = {
    "M1": mt5.TIMEFRAME_M1 if mt5 else 1,
    "M5": mt5.TIMEFRAME_M5 if mt5 else 5,
    "M15": mt5.TIMEFRAME_M15 if mt5 else 15,
    "M30": mt5.TIMEFRAME_M30 if mt5 else 30,
    "H1": mt5.TIMEFRAME_H1 if mt5 else 16385,
    "H4": mt5.TIMEFRAME_H4 if mt5 else 16388,
    "D1": mt5.TIMEFRAME_D1 if mt5 else 16408,
    "W1": mt5.TIMEFRAME_W1 if mt5 else 32769,
}

_idem_lock = threading.Lock()
_idempotency: Dict[str, Dict[str, Any]] = {}
_IDEM_TTL = 120.0


def _auth(authorization: str = Header(default="")) -> None:
    if not BRIDGE_TOKEN:
        raise HTTPException(503, "BRIDGE_TOKEN not configured on the bridge")
    expected = f"Bearer {BRIDGE_TOKEN}"
    if not authorization or not hmac.compare_digest(authorization, expected):
        raise HTTPException(401, "unauthorized")


def _idempotent(key: str, body: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    if not key:
        return None
    now = time.time()
    with _idem_lock:
        for k in [k for k, v in _idempotency.items() if now - v["t"] > _IDEM_TTL]:
            del _idempotency[k]
        hit = _idempotency.get(key)
        if hit:
            return hit["result"]
    return None


def _idempotent_store(key: str, result: Dict[str, Any]) -> None:
    if key:
        with _idem_lock:
            _idempotency[key] = {"t": time.time(), "result": result}


def _require_mt5():
    if mt5 is None:
        raise HTTPException(500,
                            "MetaTrader5 package not available. Run the bridge on "
                            "Windows with the MT5 terminal installed "
                            "(pip install MetaTrader5).")
    if not mt5.terminal_info():
        raise HTTPException(503, "MT5 terminal is not running/attached")


def _ensure_initialized() -> None:
    if mt5 is None:
        _require_mt5()
    if mt5.terminal_info() is not None:
        return
    login_kwargs: Dict[str, Any] = {}
    if MT5_LOGIN and MT5_PASSWORD and MT5_SERVER:
        login_kwargs.update(login=int(MT5_LOGIN), password=MT5_PASSWORD, server=MT5_SERVER)

    # 1) explicit MT5_TERMINAL_PATH env var (highest priority)
    if MT5_PATH:
        if mt5.initialize(path=MT5_PATH, **login_kwargs):
            return
        raise HTTPException(
            503,
            f"MT5 initialize failed using MT5_TERMINAL_PATH={MT5_PATH}: {mt5.last_error()}",
        )

    # 2) default: let MT5 attach to whatever terminal it last used
    if mt5.initialize(**login_kwargs):
        return
    default_error = mt5.last_error()

    # 3) fall back to common install locations that actually exist on disk
    for candidate in COMMON_MT5_PATHS:
        if Path(candidate).exists() and mt5.initialize(path=candidate, **login_kwargs):
            return

    raise HTTPException(
        503,
        "MT5 initialize failed: no running terminal and no MT5_TERMINAL_PATH configured "
        f"(default attempt error: {default_error}). Set MT5_TERMINAL_PATH in .env to the "
        "exact terminal64.exe path.",
    )


def _resolve_symbol(symbol: str) -> str:
    _ensure_initialized()
    info = mt5.symbol_info(symbol)
    if info is not None:
        if not info.visible:
            mt5.symbol_select(symbol, True)
        return symbol
    all_symbols = mt5.symbols_get() or []
    resolved = resolve_symbol_name(symbol, (s.name for s in all_symbols))
    if resolved is None:
        raise HTTPException(400, f"unknown symbol: {symbol}")
    mt5.symbol_select(resolved, True)
    return resolved


# ---------------------------------------------------------------------------
@app.get("/health")
def health(authorization: str = Header(default="")) -> Dict[str, Any]:
    _auth(authorization)
    if mt5 is None:
        return {"ok": False, "detail": "MetaTrader5 package missing (install on Windows)"}
    try:
        _ensure_initialized()
    except HTTPException as exc:
        return {"ok": False, "detail": str(exc.detail)}
    term = mt5.terminal_info()
    if term is None:
        return {"ok": False, "detail": "terminal not attached"}
    return {
        "ok": True,
        "terminal": term.name,
        "connected": bool(term.trade_allowed),
        "ping_last": getattr(mt5, "last_error", lambda: None)(),
        "detail": "connected to MT5 terminal" if term.trade_allowed else
                  "terminal attached but AutoTrading disabled - enable Algo Trading",
    }


@app.post("/account/connect")
def account_connect(body: AccountConnectBody,
                    authorization: str = Header(default="")) -> Dict[str, Any]:
    _auth(authorization)
    _ensure_initialized()
    # Safety: do not switch accounts while this terminal has open positions or
    # pending orders. This first version intentionally supports one active
    # trading context at a time.
    if mt5.positions_total() or mt5.orders_total():
        raise HTTPException(409, "cannot switch MT5 account while positions or pending orders exist")
    ok = mt5.login(int(body.login), password=body.password, server=body.server)
    if not ok:
        raise HTTPException(401, f"MT5 login failed: {mt5.last_error()}")
    acc = mt5.account_info()
    if acc is None:
        raise HTTPException(503, "account connected but account_info failed")
    return {"ok": True, "login": acc.login, "server": acc.server,
            "company": acc.company, "currency": acc.currency,
            "balance": acc.balance, "equity": acc.equity,
            "leverage": acc.leverage, "trade_mode": _trade_mode(acc.trade_mode)}


@app.post("/account/disconnect")
def account_disconnect(authorization: str = Header(default="")) -> Dict[str, Any]:
    _auth(authorization)
    _ensure_initialized()
    if mt5.positions_total() or mt5.orders_total():
        raise HTTPException(409, "cannot disconnect while positions or pending orders exist")
    # MT5 has no explicit logout; initialize() will reconnect as needed.
    return {"ok": True, "detail": "account session left idle; no credentials persisted by bridge"}


@app.get("/account")
def account(authorization: str = Header(default="")) -> Dict[str, Any]:
    _auth(authorization)
    _ensure_initialized()
    acc = mt5.account_info()
    if acc is None:
        raise HTTPException(503, "account_info failed (not logged in?)")
    return {
        "login": acc.login, "server": acc.server, "company": acc.company,
        "currency": acc.currency, "balance": acc.balance, "equity": acc.equity,
        "margin": acc.margin, "margin_free": acc.margin_free,
        "leverage": acc.leverage, "trade_mode": _trade_mode(acc.trade_mode),
    }


def _trade_mode(code: int) -> str:
    if mt5 is None:
        return "unknown"
    return {0: "demo", 1: "contest", 2: "real"}.get(code, "unknown")


@app.get("/symbol")
def symbol(symbol: str, authorization: str = Header(default="")) -> Dict[str, Any]:
    _auth(authorization)
    name = _resolve_symbol(symbol)
    info = mt5.symbol_info(name)
    tick = mt5.symbol_info_tick(name)
    if info is None:
        raise HTTPException(400, f"symbol_info failed for {name}")
    return {
        "symbol": name,
        "tick_size": info.trade_tick_size or info.point,
        "tick_value": info.trade_tick_value,
        "volume_min": info.volume_min,
        "volume_max": info.volume_max,
        "volume_step": info.volume_step,
        "contract_size": info.trade_contract_size,
        "point": info.point,
        "digits": info.digits,
        "stops_level_points": info.trade_stops_level,
        "spread_points": (tick.ask - tick.bid) / info.point if tick and info.point else 0,
        "visible": info.visible,
    }


@app.get("/rates")
def rates(symbol: str, timeframe: str = "M15", count: int = 300,
          authorization: str = Header(default="")) -> Dict[str, Any]:
    _auth(authorization)
    name = _resolve_symbol(symbol)
    tf = TIMEFRAME_MAP.get(timeframe.upper())
    if tf is None:
        raise HTTPException(400, f"unknown timeframe {timeframe}")
    got = mt5.copy_rates_from_pos(name, tf, 0, max(10, min(count, 5000)))
    if got is None:
        raise HTTPException(503, f"copy_rates failed: {mt5.last_error()}")
    out = [{"time": int(r["time"]), "open": float(r["open"]), "high": float(r["high"]),
            "low": float(r["low"]), "close": float(r["close"]),
            "volume": float(r["tick_volume"])} for r in got]
    return {"symbol": name, "timeframe": timeframe.upper(), "rates": out}


@app.get("/tick")
def tick(symbol: str, authorization: str = Header(default="")) -> Dict[str, Any]:
    _auth(authorization)
    name = _resolve_symbol(symbol)
    t = mt5.symbol_info_tick(name)
    info = mt5.symbol_info(name)
    if t is None or info is None:
        raise HTTPException(503, "no tick available (market closed or symbol error)")
    return {
        "time": int(t.time), "bid": t.bid, "ask": t.ask,
        "spread_points": (t.ask - t.bid) / info.point if info.point else 0,
    }


@app.get("/positions")
def positions(authorization: str = Header(default="")) -> Dict[str, Any]:
    _auth(authorization)
    _ensure_initialized()
    pos = mt5.positions_get()
    return {"positions": [{
        "ticket": p.ticket, "symbol": p.symbol, "type": "buy" if p.type == 0 else "sell",
        "lots": p.volume, "open_price": p.price_open, "sl": p.sl, "tp": p.tp,
        "profit": p.profit, "swap": p.swap, "comment": p.comment, "magic": p.magic,
        "time": int(p.time),
    } for p in (pos or [])]}


@app.get("/orders")
def orders(authorization: str = Header(default="")) -> Dict[str, Any]:
    _auth(authorization)
    _ensure_initialized()
    ords = mt5.orders_get()
    kind_map = {0: "buy_limit", 1: "sell_limit", 2: "buy_stop", 3: "sell_stop",
                4: "buy_stoplimit", 5: "sell_stoplimit"}
    return {"orders": [{
        "ticket": o.ticket, "symbol": o.symbol, "type": kind_map.get(o.type, str(o.type)),
        "lots": o.volume_current, "price_open": o.price_open, "sl": o.sl, "tp": o.tp,
        "comment": o.comment, "magic": o.magic, "time_setup": int(o.time_setup),
    } for o in (ords or [])]}


# ---------------------------------------------------------------------------
class AccountConnectBody(BaseModel):
    login: int
    password: str
    server: str


class MarketOrderBody(BaseModel):
    symbol: str
    side: str                      # buy | sell
    lots: float
    sl: float
    tp: float
    comment: str = ""
    magic: int = 0
    deviation_points: float = 10.0
    idempotency_key: str = ""


class LimitOrderBody(BaseModel):
    symbol: str
    side: str                      # buy | sell  -> buy_limit / sell_limit
    lots: float
    price: float
    sl: float
    tp: float
    comment: str = ""
    magic: int = 0
    expiration_ms: Optional[int] = None
    idempotency_key: str = ""


class ModifyBody(BaseModel):
    ticket: int
    sl: Optional[float] = None
    tp: Optional[float] = None


class CloseBody(BaseModel):
    ticket: int
    lots: Optional[float] = None


class CancelBody(BaseModel):
    ticket: int


def _sending_request(symbol: str, **overrides: Any) -> Dict[str, Any]:
    name = _resolve_symbol(symbol)
    info = mt5.symbol_info(name)
    tickv = mt5.symbol_info_tick(name)
    if info is None or tickv is None:
        raise HTTPException(503, "symbol info/tick unavailable")
    req = {
        "action": mt5.TRADE_ACTION_DEAL,
        "symbol": name,
        "volume": float(overrides["volume"]),
        "type": mt5.ORDER_TYPE_BUY if overrides["type"] == "buy" else mt5.ORDER_TYPE_SELL,
        "price": tickv.ask if overrides["type"] == "buy" else tickv.bid,
        "sl": float(overrides["sl"]),
        "tp": float(overrides["tp"]),
        "deviation": int(overrides.get("deviation", 10)),
        "magic": int(overrides.get("magic", 0)),
        "comment": str(overrides.get("comment", ""))[:31],
        "type_time": mt5.ORDER_TIME_GTC,
        "type_filling": _filling_mode(info),
    }
    return req


def _filling_mode(info) -> int:
    """Pick a filling mode the symbol supports (broker-dependent)."""
    fmodes = info.filling_mode
    for flag, mode in ((1, mt5.ORDER_FILLING_FOK), (2, mt5.ORDER_FILLING_IOC)):
        if fmodes & flag:
            return mode
    return mt5.ORDER_FILLING_RETURN


def _send(req: Dict[str, Any]) -> Dict[str, Any]:
    result = mt5.order_send(req)
    if result is None:
        raise HTTPException(503, f"order_send returned None: {mt5.last_error()}")
    ok = result.retcode == mt5.TRADE_RETCODE_DONE
    return {
        "ok": ok,
        "retcode": result.retcode,
        "ticket": getattr(result, "order", None) or getattr(result, "deal", None),
        "price": getattr(result, "price", None),
        "comment": result.comment or _retcode_meaning(result.retcode),
        "request_id": getattr(result, "request_id", None),
    }


def _retcode_meaning(code: int) -> str:
    meanings = {
        10009: "done", 10004: "requote", 10006: "rejected", 10013: "invalid request",
        10014: "invalid volume", 10015: "invalid price", 10016: "invalid stops",
        10018: "market closed", 10019: "not enough money", 10027:
        "autotrading disabled in terminal (enable Algo Trading!)",
        10031: "no connection to trade server", 10044: "only position closing allowed",
    }
    return meanings.get(code, f"retcode {code}")


@app.post("/order/market")
def order_market(body: MarketOrderBody,
                 authorization: str = Header(default="")) -> Dict[str, Any]:
    _auth(authorization)
    cached = _idempotent(body.idempotency_key, body.model_dump())
    if cached:
        return {**cached, "duplicate": True}
    if body.side not in ("buy", "sell"):
        raise HTTPException(400, "side must be buy|sell")
    if not body.sl or body.sl <= 0:
        # Defence in depth: the engine already enforces SL, so does the bridge.
        raise HTTPException(400, "stop loss is mandatory")
    _ensure_initialized()
    req = _sending_request(body.symbol, type=body.side, volume=body.lots,
                           sl=body.sl, tp=body.tp, magic=body.magic,
                           comment=body.comment, deviation=body.deviation_points)
    res = _send(req)
    _idempotent_store(body.idempotency_key, res)
    return res


@app.post("/order/limit")
def order_limit(body: LimitOrderBody,
                authorization: str = Header(default="")) -> Dict[str, Any]:
    _auth(authorization)
    cached = _idempotent(body.idempotency_key, body.model_dump())
    if cached:
        return {**cached, "duplicate": True}
    if body.side not in ("buy", "sell"):
        raise HTTPException(400, "side must be buy|sell")
    if not body.sl or body.sl <= 0:
        raise HTTPException(400, "stop loss is mandatory")
    _ensure_initialized()
    name = _resolve_symbol(body.symbol)
    info = mt5.symbol_info(name)
    req = {
        "action": mt5.TRADE_ACTION_PENDING,
        "symbol": name,
        "volume": body.lots,
        "type": mt5.ORDER_TYPE_BUY_LIMIT if body.side == "buy" else mt5.ORDER_TYPE_SELL_LIMIT,
        "price": body.price,
        "sl": body.sl,
        "tp": body.tp,
        "magic": body.magic,
        "comment": body.comment[:31],
        "type_time": mt5.ORDER_TIME_SPECIFIED if body.expiration_ms else mt5.ORDER_TIME_GTC,
        "expiration": int(body.expiration_ms) if body.expiration_ms else 0,
        "type_filling": _filling_mode(info),
    }
    if req["type_time"] == mt5.ORDER_TIME_SPECIFIED:
        # MT5 wants expiration as datetime in terminal tz; use seconds-accurate.
        from datetime import datetime, timezone
        req["expiration"] = datetime.fromtimestamp(body.expiration_ms / 1000,
                                                   tz=timezone.utc)
    res = _send(req)
    _idempotent_store(body.idempotency_key, res)
    return res


@app.post("/position/modify")
def position_modify(body: ModifyBody,
                    authorization: str = Header(default="")) -> Dict[str, Any]:
    _auth(authorization)
    _ensure_initialized()
    req = {
        "action": mt5.TRADE_ACTION_SLTP,
        "position": body.ticket,
        "symbol": None,
    }
    pos = mt5.positions_get(ticket=body.ticket)
    if not pos:
        raise HTTPException(404, "position not found")
    req["symbol"] = pos[0].symbol
    req["sl"] = float(body.sl) if body.sl is not None else pos[0].sl
    req["tp"] = float(body.tp) if body.tp is not None else pos[0].tp
    return _send(req)


@app.post("/position/close")
def position_close(body: CloseBody,
                   authorization: str = Header(default="")) -> Dict[str, Any]:
    _auth(authorization)
    _ensure_initialized()
    pos = mt5.positions_get(ticket=body.ticket)
    if not pos:
        raise HTTPException(404, "position not found")
    p = pos[0]
    lots = body.lots if (body.lots and body.lots < p.volume) else p.volume
    tickv = mt5.symbol_info_tick(p.symbol)
    req = {
        "action": mt5.TRADE_ACTION_DEAL,
        "symbol": p.symbol,
        "volume": lots,
        "type": mt5.ORDER_TYPE_SELL if p.type == 0 else mt5.ORDER_TYPE_BUY,
        "position": p.ticket,
        "price": tickv.bid if p.type == 0 else tickv.ask,
        "deviation": 20,
        "magic": p.magic,
        "comment": "bbfx-close",
        "type_filling": _filling_mode(mt5.symbol_info(p.symbol)),
    }
    res = _send(req)
    if res["ok"]:
        profit = p.profit * (lots / p.volume)
        res["profit"] = round(profit, 2)
        res["lots"] = lots
    return res


def _deal_reason(code: int) -> str:
    names = {getattr(mt5, "DEAL_REASON_SL", -1): "stop_loss",
             getattr(mt5, "DEAL_REASON_TP", -2): "take_profit",
             getattr(mt5, "DEAL_REASON_SO", -3): "stop_out",
             getattr(mt5, "DEAL_REASON_CLIENT", -4): "manual",
             getattr(mt5, "DEAL_REASON_MOBILE", -5): "manual",
             getattr(mt5, "DEAL_REASON_WEB", -6): "manual",
             getattr(mt5, "DEAL_REASON_EXPERT", -7): "expert"}
    return names.get(code, "closed")


def summarize_deals(deals: Any) -> Dict[str, Any]:
    """Collapse the MT5 deals of ONE position into its realized result.
    profit = sum(profit + swap + commission + fee) over all deals of the position."""
    deals = list(deals or [])
    if not deals:
        return {"found": False}
    out_entry = {getattr(mt5, "DEAL_ENTRY_OUT", 1), getattr(mt5, "DEAL_ENTRY_OUT_BY", 3),
                 getattr(mt5, "DEAL_ENTRY_INOUT", 2)}
    total = sum(float(d.profit) + float(d.swap) + float(d.commission) + float(getattr(d, "fee", 0.0))
                for d in deals)
    outs = [d for d in deals if d.entry in out_entry]
    if not outs:
        return {"found": False, "open_only": True}
    last = max(outs, key=lambda d: d.time)
    return {"found": True, "profit": round(total, 2), "close_price": float(last.price),
            "closed_at": int(last.time) * 1000, "reason": _deal_reason(last.reason),
            "deals": len(deals)}


@app.get("/deals")
def deals(position: int, authorization: str = Header(default="")) -> Dict[str, Any]:
    _auth(authorization)
    _ensure_initialized()
    res = mt5.history_deals_get(position=position)
    return summarize_deals(res)


@app.post("/order/cancel")
def order_cancel(body: CancelBody,
                 authorization: str = Header(default="")) -> Dict[str, Any]:
    _auth(authorization)
    _ensure_initialized()
    req = {"action": mt5.TRADE_ACTION_REMOVE, "order": body.ticket}
    return _send(req)


if __name__ == "__main__":
    import uvicorn
    host = os.environ.get("BRIDGE_HOST", "127.0.0.1")
    port = int(os.environ.get("BRIDGE_PORT", "8001"))
    if not BRIDGE_TOKEN:
        print("REFUSING to start: set BRIDGE_TOKEN to a long random string first.")
        raise SystemExit(1)
    uvicorn.run(app, host=host, port=port, log_level="info")
