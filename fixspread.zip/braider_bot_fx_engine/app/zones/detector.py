"""Supply / Demand zone detection with full lifecycle metadata (spec section 7).

Detection rule (objective): a zone forms when an *impulse* leaves a *base*.

* Impulse: the net price displacement of 1-3 consecutive candles exceeds
  ``impulse_atr_mult`` x ATR in one direction.
* Base: the candle (or small consolidation) immediately before the impulse.
* Demand zone  = base of a bullish impulse;  zone body spans the base's low
  to max(open, close) of the base candle.
* Supply zone  = base of a bearish impulse;  body spans min(open, close) of
  the base to the base's high.

Lifecycle (all thresholds configurable in config.yaml):

* FRESH      - price has never returned into the zone since creation.
* TESTED     - price returned into the zone 1..N times without a body close
               through the far edge.
* RESPECTED  - a touch produced a reaction of at least
               ``reaction_atr_mult`` x ATR away from the zone.
* INVALIDATED- a candle BODY closed through the far edge plus
               ``invalidate_buffer_atr`` x ATR (wick-only breaches don't count).
* CONSUMED   - price traded beyond the zone by ``consumed_atr_mult`` x ATR.

Fresh zones are preferred by the confluence engine; a zone stops being
"fresh" after any meaningful interaction.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence

from ..constants import ZoneKind, ZoneStatus
from ..market.candles import Candle, atr


@dataclass
class Zone:
    id: str
    kind: ZoneKind
    timeframe: str
    upper: float
    lower: float
    created_index: int
    created_time: int
    creation_candle: int            # index of the impulse candle that created it
    impulse_size: float             # in price units
    atr_at_creation: float
    strength: float                 # impulse_size / atr_at_creation
    touches: int = 0
    status: ZoneStatus = ZoneStatus.FRESH
    last_touch_time: Optional[int] = None
    last_reaction_size: float = 0.0
    liquidity_swept: bool = False   # a sweep happened at/around the zone
    mitigated_index: Optional[int] = None

    @property
    def height(self) -> float:
        return self.upper - self.lower

    def contains(self, price: float, buffer: float = 0.0) -> bool:
        return (self.lower - buffer) <= price <= (self.upper + buffer)

    def to_dict(self) -> Dict:
        return {
            "id": self.id, "kind": self.kind.value, "timeframe": self.timeframe,
            "upper": self.upper, "lower": self.lower,
            "created_time": self.created_time, "strength": round(self.strength, 3),
            "touches": self.touches, "status": self.status.value,
            "liquidity_swept": self.liquidity_swept,
        }


@dataclass
class ZoneAnalysis:
    zones: List[Zone] = field(default_factory=list)

    def active_zones(self, kind: Optional[ZoneKind] = None) -> List[Zone]:
        return [z for z in self.zones
                if z.status in (ZoneStatus.FRESH, ZoneStatus.TESTED, ZoneStatus.RESPECTED)
                and (kind is None or z.kind is kind)]

    def nearest_active(self, price: float, kind: ZoneKind,
                       max_distance: float | None = None) -> Optional[Zone]:
        best = None
        best_d = float("inf")
        for z in self.active_zones(kind):
            if z.contains(price):
                return z
            d = 0.0 if z.contains(price) else min(abs(price - z.lower), abs(price - z.upper))
            if d < best_d and (max_distance is None or d <= max_distance):
                best, best_d = z, d
        return best


def _find_impulses(candles: Sequence[Candle], atr_value: float,
                   impulse_atr_mult: float) -> List[tuple]:
    """Return (start_idx, end_idx, direction) for qualifying impulses."""
    impulses = []
    n = len(candles)
    if atr_value <= 0 or n < 4:
        return impulses
    i = 0
    while i < n - 1:
        window = 1
        found = None
        for window in (1, 2, 3):
            if i + window >= n:
                break
            seg = candles[i + 1:i + 1 + window]
            net = seg[-1].close - candles[i].close
            if abs(net) >= impulse_atr_mult * atr_value:
                direction = 1 if net > 0 else -1
                found = (i, i + window, direction)
                break
        if found:
            impulses.append(found)
            i = found[1]
        else:
            i += 1
    return impulses


def detect_zones(candles: Sequence[Candle], timeframe: str,
                 impulse_atr_mult: float = 1.2,
                 invalidate_buffer_atr: float = 0.15,
                 consumed_atr_mult: float = 2.0,
                 reaction_atr_mult: float = 0.8,
                 max_age_bars: int = 300,
                 atr_period: int = 14,
                 prefix: str = "z") -> List[Zone]:
    if len(candles) < 10:
        return []
    atr_value = atr(candles, atr_period)
    if atr_value <= 0:
        return []
    zones: List[Zone] = []
    counter = 0

    for base_idx, impulse_end, direction in _find_impulses(candles, atr_value, impulse_atr_mult):
        base = candles[base_idx]
        counter += 1
        zid = f"{prefix}{timeframe}-{base.time}-{counter}"
        if direction > 0:
            upper = max(base.open, base.close)
            lower = base.low
            kind = ZoneKind.DEMAND
        else:
            upper = base.high
            lower = min(base.open, base.close)
            kind = ZoneKind.SUPPLY
        if upper - lower <= 1e-12:
            upper = base.high
            lower = base.low
        zone = Zone(
            id=zid, kind=kind, timeframe=timeframe,
            upper=round(upper, 6), lower=round(lower, 6),
            created_index=base_idx, created_time=base.time,
            creation_candle=impulse_end,
            impulse_size=abs(candles[impulse_end].close - base.close),
            atr_at_creation=atr_value,
            strength=abs(candles[impulse_end].close - base.close) / atr_value,
        )

        # Walk forward through candles after the impulse to build lifecycle.
        buffer = invalidate_buffer_atr * atr_value
        for j in range(impulse_end + 1, len(candles)):
            c = candles[j]
            in_zone = c.low <= zone.upper and c.high >= zone.lower
            if in_zone:
                zone.touches += 1
                zone.mitigated_index = j
                if zone.status is ZoneStatus.FRESH:
                    zone.status = ZoneStatus.TESTED
                zone.last_touch_time = c.time
                # Reaction: how far price moved away after touching.
                if zone.kind is ZoneKind.DEMAND:
                    reaction = c.high - zone.upper
                else:
                    reaction = zone.lower - c.low
                zone.last_reaction_size = max(zone.last_reaction_size, reaction)
                if reaction >= reaction_atr_mult * atr_value:
                    zone.status = ZoneStatus.RESPECTED
            # Invalidation: BODY close through far edge (+buffer).
            if zone.kind is ZoneKind.DEMAND:
                body_through = c.close < zone.lower - buffer
            else:
                body_through = c.close > zone.upper + buffer
            if body_through:
                zone.status = ZoneStatus.INVALIDATED
                break
            # Consumed: traded far beyond the zone without respecting it.
            if zone.kind is ZoneKind.DEMAND and c.low <= zone.lower - consumed_atr_mult * atr_value:
                zone.status = ZoneStatus.CONSUMED
                break
            if zone.kind is ZoneKind.SUPPLY and c.high >= zone.upper + consumed_atr_mult * atr_value:
                zone.status = ZoneStatus.CONSUMED
                break

        # Age filter: drop very old zones (bar count since creation).
        if len(candles) - 1 - zone.created_index > max_age_bars:
            continue
        zones.append(zone)

    return zones


def analyze_zones(candles: Sequence[Candle], timeframe: str,
                  cfg) -> ZoneAnalysis:
    """cfg: app.config.StrategyConfig"""
    zones = detect_zones(
        candles, timeframe,
        impulse_atr_mult=cfg.zone_impulse_atr_mult,
        invalidate_buffer_atr=cfg.zone_invalidate_buffer_atr,
        consumed_atr_mult=cfg.zone_consumed_atr_mult,
        reaction_atr_mult=cfg.zone_reaction_atr_mult,
        max_age_bars=cfg.zone_max_age_bars,
        atr_period=cfg.atr_period,
        prefix="z",
    )
    return ZoneAnalysis(zones=zones)
