"""Active trade management and early exit (spec section 35).

For every open position the engine keeps its ORIGINAL THESIS (stored at open
in SQLite).  On every confirmed (closed) bar of the entry timeframe the
manager re-asks: "is the original reason for this trade still valid?"

Severity ladder (a single wick can NEVER close a position):

    NONE          - thesis intact
    WARNING       - minor structure weakness (monitored, not acted on)
    DETERIORATED  - repeated warnings / opposing momentum without confirmed
                    break (acts only if configured to)
    INVALIDATED   - candle BODY closed through the invalidation level AND
                    (optionally) an opposing confirmed structure event
                    (CHoCH/MSS) exists -> close per exit policy

Exit priority (evaluated in this order):
    1 emergency/risk shutdown   2 hard SL/TP (broker-side)
    3 confirmed strategy invalidation
    4 structural early exit     5 partial profit-taking
    6 break-even                7 structure trailing   8 final TP
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from ..config import Config
from ..constants import (Direction, ManagementSignal, StructureEventKind, Trend)
from ..execution.broker_client import BrokerClient
from ..execution.executor import Executor
from ..journal.journal import Journal
from ..market.candles import Candle, atr
from ..state_store import StateStore, TradeRecord, utc_now_ms
from ..strategy.structure import analyze_structure


@dataclass
class ManagementAction:
    kind: str                     # close | partial | modify_sl | none | warning
    ticket: str
    reason: str
    detail: Dict = field(default_factory=dict)


class TradeManager:
    def __init__(self, cfg: Config, broker: BrokerClient, executor: Executor,
                 store: StateStore, journal: Journal):
        self.cfg = cfg
        self.broker = broker
        self.executor = executor
        self.store = store
        self.journal = journal

    # ------------------------------------------------------------------
    def evaluate_position(self, trade: TradeRecord, candles: List[Candle],
                          now_ms: int) -> List[ManagementAction]:
        """Evaluate one open position against its stored thesis."""
        if not candles or len(candles) < 30:
            return []
        direction = Direction(trade.side)
        entry = float(trade.entry or 0)
        sl = float(trade.sl or 0)
        atr_value = atr(candles, self.cfg.strategy.atr_period)
        actions: List[ManagementAction] = []

        # Current profit distance in R
        risk_dist = abs(entry - sl) if entry and sl else 0.0
        last = candles[-1]
        if risk_dist > 0:
            move = (last.close - entry) if direction is Direction.LONG else (entry - last.close)
            r_multiple = move / risk_dist
        else:
            r_multiple = 0.0

        # ---- 3. confirmed strategy invalidation --------------------------------
        severity, detail = self._assess_thesis(trade, candles, direction, atr_value)
        if severity is ManagementSignal.INVALIDATED:
            actions.append(ManagementAction(
                "close", trade.ticket, "thesis_invalidated",
                {"detail": detail, "r_multiple": round(r_multiple, 2)}))
            return actions
        if severity is ManagementSignal.DETERIORATED:
            actions.append(ManagementAction(
                "warning", trade.ticket, "thesis_deteriorated",
                {"detail": detail, "r_multiple": round(r_multiple, 2)}))
        elif severity is ManagementSignal.WARNING:
            actions.append(ManagementAction(
                "warning", trade.ticket, "thesis_warning", {"detail": detail}))

        # ---- 5. partial profit taking ---------------------------------------------
        for partial in self.cfg.management.partial_exits or []:
            at_r = float(partial.get("at_r", 0))
            pct = float(partial.get("close_pct", 0))
            key = f"partial_{at_r}R_done"
            done = (trade.management or {}).get(key)
            if pct <= 0 or pct >= 100 or done:
                continue
            if r_multiple >= at_r:
                if self._structure_still_valid(candles, direction):
                    lots_close = round(trade.lots * pct / 100.0, 2)
                    if lots_close > 0 and lots_close < trade.lots:
                        actions.append(ManagementAction(
                            "partial", trade.ticket, "partial_take_profit",
                            {"lots": lots_close, "at_r": at_r,
                             "r_multiple": round(r_multiple, 2)}))
                break

        # ---- 6. break-even ----------------------------------------------------------
        be_at = self.cfg.management.break_even_at_r
        be_key = "break_even_done"
        if be_at > 0 and r_multiple >= be_at and not (trade.management or {}).get(be_key):
            structure_ok = (not self.cfg.management.break_even_requires_structure) or \
                self._structure_still_valid(candles, direction)
            if structure_ok:
                buffer = self.cfg.management.break_even_buffer_points * self._point_size(trade.symbol)
                new_sl = entry + buffer if direction is Direction.LONG else entry - buffer
                improves = (new_sl > sl) if direction is Direction.LONG else (new_sl < sl or sl == 0)
                if improves:
                    actions.append(ManagementAction(
                        "modify_sl", trade.ticket, "break_even",
                        {"new_sl": round(new_sl, 8), "r_multiple": round(r_multiple, 2)}))

        # ---- 7. structure trailing ---------------------------------------------------
        if self.cfg.management.structure_trailing_enabled:
            new_sl = self._trail_level(candles, direction, entry, sl, atr_value)
            if new_sl is not None:
                improves = (new_sl > sl) if direction is Direction.LONG else (new_sl < sl)
                # Never trail past break-even backwards (only tighten).
                if improves and ((direction is Direction.LONG and new_sl > last.low - 4 * atr_value)
                                 or (direction is Direction.SHORT and new_sl < last.high + 4 * atr_value)):
                    actions.append(ManagementAction(
                        "modify_sl", trade.ticket, "structure_trail",
                        {"new_sl": round(new_sl, 8)}))

        return actions

    # ------------------------------------------------------------------
    def _assess_thesis(self, trade: TradeRecord, candles: List[Candle],
                       direction: Direction, atr_value: float) -> Tuple[ManagementSignal, Dict]:
        """The core early-exit evaluation.  Uses candle BODY closes only."""
        mg = self.cfg.management
        thesis = trade.thesis or {}
        invalidation = thesis.get("invalidation_level")
        detail: Dict = {}
        if not invalidation or atr_value <= 0:
            return ManagementSignal.NONE, detail

        opposing_events = []
        if len(candles) >= 30:
            analysis = analyze_structure(candles, strength=self.cfg.strategy.swing_strength,
                                         atr_period=self.cfg.strategy.atr_period)
            opposing_dir = Direction.SHORT if direction is Direction.LONG else Direction.LONG
            for ev in analysis.events[-6:]:
                if ev.direction is opposing_dir and \
                        ev.kind in (StructureEventKind.CHOCH, StructureEventKind.MSS):
                    opposing_events.append(ev.kind.value)

        recent = candles[-3:]
        if direction is Direction.LONG:
            body_through = any(c.close < invalidation for c in recent)
            wick_through = any(c.low < invalidation for c in recent)
            penetration = max((invalidation - c.close for c in recent), default=0.0)
        else:
            body_through = any(c.close > invalidation for c in recent)
            wick_through = any(c.high > invalidation for c in recent)
            penetration = max((c.close - invalidation for c in recent), default=0.0)
        strong_break = atr_value > 0 and penetration >= \
            self.cfg.management.early_exit_close_margin_atr * atr_value

        if body_through:
            # Spec 35: "Strong break and close through the structural
            # invalidation level" is itself a confirmed invalidation. A
            # marginal close-through additionally wants opposing structure.
            if opposing_events or strong_break or \
                    not self.cfg.management.early_exit_require_opposing_structure:
                detail.update({"invalidation_level": invalidation,
                               "penetration": round(penetration, 8),
                               "strong_break": strong_break,
                               "opposing_structure": opposing_events,
                               "mode": "body_close_through"})
                return ManagementSignal.INVALIDATED, detail
            detail.update({"mode": "body_close_marginal",
                           "opposing_structure": opposing_events})
            return ManagementSignal.DETERIORATED, detail

        if wick_through:
            # A wick through the invalidation is a WARNING, never an exit.
            detail["mode"] = "wick_through_invalidation"
            return ManagementSignal.WARNING, detail

        # Track deterioration count for repeated warnings.
        warn_count = int((trade.management or {}).get("warning_count", 0))
        if opposing_events and warn_count >= mg.warning_deterioration_count:
            detail["opposing_structure"] = opposing_events
            return ManagementSignal.DETERIORATED, detail
        if opposing_events:
            detail["opposing_structure"] = opposing_events
            return ManagementSignal.WARNING, detail
        return ManagementSignal.NONE, detail

    # ------------------------------------------------------------------
    def _structure_still_valid(self, candles: List[Candle], direction: Direction) -> bool:
        """For BE/partials: require that no confirmed opposing MSS/CHoCH exists
        in the recent window (structure remains valid)."""
        if len(candles) < 30:
            return True
        analysis = analyze_structure(candles, strength=self.cfg.strategy.swing_strength,
                                     atr_period=self.cfg.strategy.atr_period)
        opposing_dir = Direction.SHORT if direction is Direction.LONG else Direction.LONG
        for ev in analysis.events[-4:]:
            if ev.direction is opposing_dir and \
                    ev.kind in (StructureEventKind.MSS, StructureEventKind.CHOCH):
                return False
        return True

    def _trail_level(self, candles: List[Candle], direction: Direction,
                     entry: float, current_sl: float, atr_value: float) -> Optional[float]:
        """Structure-based trailing: after a CONFIRMED protected swing forms,
        trail SL beyond it (not a pip-chaser)."""
        if atr_value <= 0 or len(candles) < 40:
            return None
        analysis = analyze_structure(candles, strength=self.cfg.strategy.swing_strength,
                                     atr_period=self.cfg.strategy.atr_period)
        buffer = 0.25 * atr_value
        if direction is Direction.LONG:
            # Trail to below the most recent confirmed higher low, only if the
            # swing formed AFTER entry and is above the current SL zone.
            if analysis.protected_low and analysis.trend is Trend.BULLISH:
                candidate = analysis.protected_low - buffer
                if candidate > current_sl and candidate < candles[-1].close:
                    return candidate
        else:
            if analysis.protected_high and analysis.trend is Trend.BEARISH:
                candidate = analysis.protected_high + buffer
                if (candidate < current_sl or current_sl == 0) and candidate > candles[-1].close:
                    return candidate
        return None

    def _point_size(self, symbol: str) -> float:
        try:
            specs = self.broker.symbol_specs(symbol)
            return float(specs.get("point", 0.00001))
        except Exception:
            return 0.00001

    # ------------------------------------------------------------------
    def apply_actions(self, trade: TradeRecord,
                      actions: List[ManagementAction]) -> None:
        """Execute approved management actions and persist management state."""
        mg_state = dict(trade.management or {})
        for act in actions:
            if act.kind == "close":
                res = self.executor.close_position(trade.ticket, None,
                                                   reason=act.reason)
                if res.get("ok"):
                    profit = float(res.get("profit") or 0.0)
                    self._mark_closed(trade, act.reason, profit)
                    return
            elif act.kind == "partial":
                lots = act.detail.get("lots")
                res = self.executor.close_position(trade.ticket, lots,
                                                   reason="partial_take_profit")
                if res.get("ok"):
                    key = f"partial_{act.detail.get('at_r')}R_done"
                    mg_state[key] = True
                    self.journal.log_trade_event("INFO", "partial profit taken", {
                        "ticket": trade.ticket, "lots": lots,
                        "at_r": act.detail.get("at_r"),
                    })
            elif act.kind == "modify_sl":
                new_sl = act.detail.get("new_sl")
                if new_sl and self.executor.modify_sl_tp(trade.ticket, new_sl, None):
                    if act.reason == "break_even":
                        mg_state["break_even_done"] = True
                    mg_state["last_trail_sl"] = new_sl
                    self.journal.log_trade_event("INFO", f"SL moved ({act.reason})", {
                        "ticket": trade.ticket, "new_sl": new_sl,
                    })
            elif act.kind == "warning":
                if act.reason == "thesis_warning":
                    mg_state["warning_count"] = int(mg_state.get("warning_count", 0)) + 1
        if mg_state != (trade.management or {}):
            trade.management = mg_state
            self.store.upsert_trade(trade)

    # ------------------------------------------------------------------
    def _mark_closed(self, trade: TradeRecord, reason: str, profit: float) -> None:
        risk_dist = abs((trade.entry or 0) - (trade.sl or 0))
        r_mult = None
        if risk_dist > 0:
            r_mult = round(profit / (risk_dist * self._profit_per_lot(trade) or 1.0), 3) \
                if self._profit_per_lot(trade) else None
        trade.status = "closed"
        trade.closed_at = utc_now_ms()
        trade.exit_reason = reason
        trade.profit = profit
        trade.r_multiple = r_mult
        self.store.upsert_trade(trade)
        self.journal.log_trade_event("INFO", f"trade closed: {reason}", {
            "ticket": trade.ticket, "profit": round(profit, 2),
            "exit_reason": reason, "r_multiple": r_mult,
        })
        if self.journal.firebase is not None:
            try:
                self.journal.firebase.push_trade(trade.to_web())
            except Exception:
                pass

    def _profit_per_lot(self, trade: TradeRecord) -> Optional[float]:
        try:
            specs = self.broker.symbol_specs(trade.symbol)
            ts, tv = float(specs.get("tick_size", 0)), float(specs.get("tick_value", 0))
            if ts <= 0 or tv <= 0:
                return None
            return tv / ts
        except Exception:
            return None
