"""Configuration loading for BRAIDER BOT FX.

Configuration is layered, in increasing precedence:

1. ``config/config.yaml``  - the checked-in strategy/risk configuration.
2. Environment variables   - secrets and machine-specific settings only.

Ordinary strategy settings never require source-code changes: edit the YAML.
Secrets (MT5 credentials, Firebase service account, API tokens) live ONLY in
the environment / ``.env`` file which is never committed.

The engine also accepts live configuration pushes from the existing website
(the ``config`` block inside ``users/{uid}`` in Firestore).  The web values are
merged over the YAML values for the safe subset (risk %, limits, symbols,
mapping, session) - see ``apply_web_config``.
"""

from __future__ import annotations

import copy
import math
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml

from .constants import DEFAULT_SESSIONS

PROJECT_ROOT = Path(__file__).resolve().parent.parent


# ---------------------------------------------------------------------------
# Dataclass tree
# ---------------------------------------------------------------------------
@dataclass
class RiskConfig:
    per_trade_risk_pct: float = 1.0
    lot_sizing_mode: str = "risk_percent"  # risk_percent | fixed_lot | per_symbol
    fixed_lot_size: float = 0.01
    fixed_lot_sizes: Dict[str, float] = field(default_factory=dict)
    max_daily_loss_pct: float = 3.0
    max_daily_drawdown_pct: float = 4.0      # intraday equity peak-to-trough
    max_weekly_drawdown_pct: float = 10.0    # peak-to-trough within the trading week
    max_account_drawdown_pct: float = 10.0
    max_trades_per_day: int = 6
    max_simultaneous_positions: int = 2
    max_positions_per_symbol: int = 1
    max_exposure_lots: float = 2.0
    max_consecutive_losses: int = 3
    cooldown_minutes_after_losses: int = 60
    max_spread_points: float = 25.0
    max_slippage_points: float = 10.0
    min_rr: float = 1.5
    sl_required: bool = True
    allowed_sessions: List[str] = field(default_factory=lambda: ["london", "newyork"])
    # Hard floor/ceiling for computed stop distance (in points, 0 = disabled)
    min_stop_points: float = 0.0
    max_stop_points: float = 0.0


@dataclass
class StrategyWeights:
    fresh_zone: float = 2.0
    respected_zone: float = 1.5
    tested_zone: float = 0.5
    liquidity_sweep: float = 3.0
    structure_confirmation: float = 3.0   # CHoCH / MSS on entry timeframe
    structure_bos: float = 2.0
    pullback_valid: float = 1.0
    confirmation_candle: float = 2.0
    sr_confluence: float = 1.0
    trendline_confluence: float = 1.0
    pd_level_confluence: float = 1.0
    fvg_confluence: float = 1.5
    sweep_to_shift_sequence: float = 1.5  # sweep immediately followed by a
                                           # same-direction structure shift -
                                           # the causal sequence, not just
                                           # "a sweep happened somewhere"


#: Website session choice -> engine session names.
WEB_SESSION_MAP = {
    "all": ["sydney", "tokyo", "london", "newyork"],
    "london": ["london"],
    "ny": ["newyork"],
    "newyork": ["newyork"],
    "asia": ["tokyo", "sydney"],
    "londonny": ["london", "newyork"],
}


#: Valid values for StrategyConfig.enabled_concepts. Each name maps to one
#: independent area-of-interest / scoring concept inside build_setups(). A
#: concept NOT in this list contributes ZERO score and cannot satisfy the
#: "interest area" gate (G2) on its own - this is what keeps strategies from
#: silently blending (e.g. running pure Support & Resistance without Supply &
#: Demand zones ever counting toward a setup).
STRATEGY_CONCEPTS = (
    "supply_demand",     # order-block / demand-supply zones (ZoneAnalysis)
    "support_resistance",  # horizontal S/R levels + previous-day levels
    "fair_value_gap",    # FVG imbalance areas
    "liquidity_sweep",   # sweep-of-liquidity scoring/sequence bonus
)


@dataclass
class StrategyConfig:
    mode: str = "balanced"                # conservative | balanced | aggressive | scalping
    # Which swing-trading concepts are allowed to contribute to a setup.
    # Multiple may be enabled together (e.g. supply_demand + fair_value_gap).
    # This has NO effect on Scalping mode, which uses its own dedicated
    # SMC-pullback method (app/strategy/scalp_smc.py) and never touches this
    # list - scalping is always fully separate, never blended with these.
    enabled_concepts: List[str] = field(
        default_factory=lambda: list(STRATEGY_CONCEPTS)
    )
    entry_timeframe: str = "M15"
    confirmation_timeframe: str = "M5"
    htf_bias_timeframes: List[str] = field(default_factory=lambda: ["H4", "H1"])
    zone_timeframes: List[str] = field(default_factory=lambda: ["H4", "H1", "M30"])
    bars: Dict[str, int] = field(default_factory=lambda: {
        "M1": 400, "M5": 400, "M15": 400, "M30": 400, "H1": 500, "H4": 400, "D1": 120,
    })
    min_confluence_score: float = 6.0
    max_confluence_score: float = 10.0
    weights: StrategyWeights = field(default_factory=StrategyWeights)
    swing_strength: int = 2               # fractal bars left/right for swings
    atr_period: int = 14
    # Zones
    zone_impulse_atr_mult: float = 1.2
    zone_max_age_bars: int = 300
    zone_invalidate_buffer_atr: float = 0.15
    zone_consumed_atr_mult: float = 2.0
    zone_reaction_atr_mult: float = 0.8
    zone_entry_buffer_atr: float = 0.10
    # Fair value gaps
    fvg_min_gap_atr_mult: float = 0.15
    fvg_min_displacement_body_ratio: float = 0.5
    fvg_max_age_bars: int = 150
    # Sweep -> structure-shift sequence window: how many bars after a sweep
    # a same-direction structure event still counts as "caused by" it.
    sweep_to_shift_max_bars: int = 6
    # Liquidity sweeps
    sweep_min_penetration_atr: float = 0.10
    sweep_lookback_swings: int = 10
    # Pullback / confirmation
    pullback_min_retracement: float = 0.236
    pullback_max_retracement: float = 0.85
    confirmation_patterns: List[str] = field(
        default_factory=lambda: ["engulfing", "pin_bar", "momentum_close", "mss"]
    )
    # Stop loss / targets
    sl_buffer_atr: float = 0.35
    tp_rr: float = 2.0
    use_opposing_zone_target: bool = True
    # Limit-order pullback entries
    prefer_limit_entries: bool = True
    limit_expiry_bars: int = 12
    limit_buffer_atr: float = 0.05
    max_pending_per_symbol: int = 1
    # Per-symbol timeframe (and other simple field) overrides, keyed by
    # canonical symbol (EURUSD, not EURUSDm). Falls back to the fields above
    # when a symbol isn't listed. See Config.effective_strategy(canonical).
    symbol_overrides: Dict[str, Dict[str, Any]] = field(default_factory=dict)


@dataclass
class ScalpingConfig:
    enabled: bool = False
    entry_timeframe: str = "M5"
    confirmation_timeframe: str = "M5"
    min_confluence_score: float = 5.0
    max_spread_points: float = 20.0
    min_stop_points: float = 30.0
    max_stop_points: float = 600.0
    max_trades_per_day: int = 8
    max_simultaneous_positions: int = 1
    cooldown_minutes: int = 20
    allowed_sessions: List[str] = field(default_factory=lambda: ["london", "newyork"])
    prefer_limit_entries: bool = True
    limit_expiry_bars: int = 8
    tp_rr: float = 1.5


@dataclass
class ManagementConfig:
    """Active trade management (spec section 35)."""
    # Partial take profit: list of {at_r, close_pct}
    partial_exits: List[Dict[str, float]] = field(
        default_factory=lambda: [
            {"at_r": 1.0, "close_pct": 50.0},
        ]
    )
    break_even_at_r: float = 1.0
    break_even_buffer_points: float = 2.0
    break_even_requires_structure: bool = True
    structure_trailing_enabled: bool = True
    # Early exit confirmation requirements
    early_exit_requires_close: bool = True          # never exit on a single wick
    early_exit_require_opposing_structure: bool = False
    early_exit_close_margin_atr: float = 0.15       # "strong" close-through margin
    warning_deterioration_count: int = 2            # warnings before deterioration
    # Emergency behaviour
    emergency_cancel_pending: bool = True
    emergency_close_positions: bool = True
    # Pending order maintenance
    cancel_pending_on_thesis_invalidation: bool = True


@dataclass
class SymbolsConfig:
    watched: List[str] = field(
        default_factory=lambda: ["EURUSD", "GBPUSD", "USDCAD", "XAUUSD", "BTCUSD"]
    )
    # Canonical -> broker symbol. Overridable from web app `mapping`.
    mapping: Dict[str, str] = field(default_factory=lambda: {
        "EURUSD": "EURUSD",
        "GBPUSD": "GBPUSD",
        "USDCAD": "USDCAD",
        "XAUUSD": "XAUUSD",
        "BTCUSD": "BTCUSD",
    })


@dataclass
class ExecutionConfig:
    mode: str = "paper"                    # paper | demo | live  (LIVE blocked unless env flag)
    paper_balance: float = 10000.0
    paper_spread_points: Dict[str, float] = field(default_factory=lambda: {
        "EURUSD": 10, "GBPUSD": 15, "USDCAD": 15, "XAUUSD": 25, "BTCUSD": 60,
    })
    magic: int = 777001
    order_comment_prefix: str = "BBFX"
    order_retry_attempts: int = 2
    order_retry_delay_seconds: float = 1.5
    execution_slippage_points: float = 10.0
    bridge_url: str = "http://127.0.0.1:8001"
    bridge_timeout_seconds: float = 10.0
    duplicate_window_seconds: int = 30     # idempotency window for identical orders
    cycle_seconds: float = 10.0            # engine loop cadence
    data_max_age_bars: int = 2             # reject feed if last bar older than N * tf


@dataclass
class ApiConfig:
    enabled: bool = True
    host: str = "0.0.0.0"
    port: int = 8000
    rate_limit_per_minute: int = 120


@dataclass
class LoggingConfig:
    level: str = "INFO"
    dir: str = "logs"
    max_file_mb: int = 20
    backup_count: int = 10


@dataclass
class Config:
    symbols: SymbolsConfig = field(default_factory=SymbolsConfig)
    risk: RiskConfig = field(default_factory=RiskConfig)
    strategy: StrategyConfig = field(default_factory=StrategyConfig)
    scalping: ScalpingConfig = field(default_factory=ScalpingConfig)
    management: ManagementConfig = field(default_factory=ManagementConfig)
    execution: ExecutionConfig = field(default_factory=ExecutionConfig)
    api: ApiConfig = field(default_factory=ApiConfig)
    logging: LoggingConfig = field(default_factory=LoggingConfig)
    sessions: Dict[str, Dict[str, int]] = field(default_factory=lambda: copy.deepcopy(DEFAULT_SESSIONS))
    timezone: str = "UTC"                  # trading-day boundary timezone
    source_path: Optional[Path] = None
    # Version stamp of the website config last applied (echoed back to the
    # website so it can show "engine confirmed"). 0 = nothing applied yet.
    web_config_version: int = 0

    # ------------------------------------------------------------------
    @property
    def is_live_requested(self) -> bool:
        return self.execution.mode == "live"

    def effective_strategy(self, canonical: Optional[str] = None) -> StrategyConfig:
        """Strategy settings adjusted when scalping mode is active, then
        adjusted again for ``canonical``'s per-symbol override, if any
        (strategy.symbol_overrides - e.g. a faster entry_timeframe). Symbol
        overrides are applied last so they always win. Passing no symbol
        keeps the old global behaviour (used by callers with no specific
        symbol in hand)."""
        if self.strategy.mode == "scalping" or self.scalping.enabled:
            s = copy.deepcopy(self.strategy)
            sc = self.scalping
            s.mode = "scalping"
            s.entry_timeframe = sc.entry_timeframe
            s.confirmation_timeframe = sc.confirmation_timeframe
            s.min_confluence_score = sc.min_confluence_score
            s.prefer_limit_entries = sc.prefer_limit_entries
            s.limit_expiry_bars = sc.limit_expiry_bars
            s.tp_rr = sc.tp_rr
        else:
            s = copy.deepcopy(self.strategy)

        if canonical:
            override = self.strategy.symbol_overrides.get(canonical.upper())
            if override:
                for key, value in override.items():
                    if hasattr(s, key):
                        setattr(s, key, value)
        return s

    def effective_risk(self) -> RiskConfig:
        if self.strategy.mode == "scalping" or self.scalping.enabled:
            r = copy.deepcopy(self.risk)
            r.max_spread_points = min(r.max_spread_points, self.scalping.max_spread_points)
            r.max_trades_per_day = min(r.max_trades_per_day, self.scalping.max_trades_per_day)
            r.max_simultaneous_positions = min(
                r.max_simultaneous_positions, self.scalping.max_simultaneous_positions
            )
            if self.scalping.min_stop_points > r.min_stop_points:
                r.min_stop_points = self.scalping.min_stop_points
            if self.scalping.max_stop_points and (
                not r.max_stop_points or self.scalping.max_stop_points < r.max_stop_points
            ):
                r.max_stop_points = self.scalping.max_stop_points
            return r
        return self.risk

    def effective_sessions(self) -> List[str]:
        if self.strategy.mode == "scalping" or self.scalping.enabled:
            return self.scalping.allowed_sessions
        return self.risk.allowed_sessions


# ---------------------------------------------------------------------------
# Loading
# ---------------------------------------------------------------------------
def _apply(obj: Any, data: Dict[str, Any]) -> None:
    """Set dataclass fields from a dict, ignoring unknown keys."""
    for key, value in (data or {}).items():
        if hasattr(obj, key):
            current = getattr(obj, key)
            if hasattr(current, "__dataclass_fields__") and isinstance(value, dict):
                _apply(current, value)
            else:
                setattr(obj, key, value)


def load_config(path: Optional[str] = None) -> Config:
    cfg = Config()
    cfg_path = Path(path) if path else PROJECT_ROOT / "config" / "config.yaml"
    if cfg_path.exists():
        raw = yaml.safe_load(cfg_path.read_text(encoding="utf-8")) or {}
        _apply(cfg, raw)
        cfg.source_path = cfg_path
    # Environment overrides for machine-specific values.
    env = os.environ
    if env.get("BBFX_EXECUTION_MODE"):
        cfg.execution.mode = env["BBFX_EXECUTION_MODE"].strip().lower()
    if env.get("BBFX_BRIDGE_URL"):
        cfg.execution.bridge_url = env["BBFX_BRIDGE_URL"]
    if env.get("BBFX_MAGIC"):
        cfg.execution.magic = int(env["BBFX_MAGIC"])
    if env.get("BBFX_TIMEZONE"):
        cfg.timezone = env["BBFX_TIMEZONE"]
    if env.get("BBFX_PAPER_BALANCE"):
        cfg.execution.paper_balance = float(env["BBFX_PAPER_BALANCE"])
    return cfg


SAFE_WEB_KEYS = {
    # web config key -> config path (applied to local Config instance)
    "mode": ("strategy", "mode"),
    "timeframe": ("strategy", "entry_timeframe"),
}


#: Smallest lot the engine accepts from the website (mirrors
#: risk.position_sizing.ABSOLUTE_MIN_LOT; kept here to avoid an import cycle).
MIN_LOT = 0.01


def _clean_lot(value: Any) -> Optional[float]:
    """Validate a user-entered lot size: finite, floored at MIN_LOT, 0.01 step."""
    try:
        lot = float(value)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(lot) or lot <= 0 or lot > 1000:
        return None
    lot = max(MIN_LOT, lot)
    return round(round(lot / MIN_LOT) * MIN_LOT, 2)


def apply_web_config(cfg: Config, web: Dict[str, Any]) -> List[str]:
    """Merge the safe subset of the website's ``users/{uid}.config`` payload.

    The website stores ``config.risk`` with keys like ``perTrade`` /
    ``maxDailyLoss`` (camelCase).  Unknown or unsafe values are ignored.
    Returns the list of applied keys (for the audit log).
    """
    applied: List[str] = []
    if not isinstance(web, dict):
        return applied

    web_cfg = web.get("config") or {}
    risk_web = web_cfg.get("risk") or {}
    if not isinstance(web_cfg, dict):
        return applied
    if not isinstance(risk_web, dict):
        risk_web = {}

    # Lot sizing controls.  Risk-percent remains the default.  Every lot
    # value is floored at MIN_LOT (0.01) and rounded to the 0.01 step: the
    # engine never accepts, stores or sends anything smaller.
    sizing_mode = risk_web.get("lotSizingMode")
    if sizing_mode in ("risk_percent", "fixed_lot", "per_symbol"):
        cfg.risk.lot_sizing_mode = sizing_mode
        applied.append("risk.lot_sizing_mode")
    if "fixedLotSize" in risk_web:
        lot = _clean_lot(risk_web["fixedLotSize"])
        if lot is not None:
            cfg.risk.fixed_lot_size = lot
            applied.append("risk.fixed_lot_size")
    if isinstance(risk_web.get("fixedLotSizes"), dict):
        clean_lots = {}
        for symbol, value in risk_web["fixedLotSizes"].items():
            lot = _clean_lot(value)
            if isinstance(symbol, str) and lot is not None:
                clean_lots[symbol.upper()] = lot
        cfg.risk.fixed_lot_sizes = clean_lots
        applied.append("risk.fixed_lot_sizes")

    # (website key, RiskConfig attribute, cast, lowest allowed, highest allowed)
    # Out-of-range / non-numeric values are ignored rather than applied, so a
    # typo (0, -5, 500%, NaN) can never weaken or break the risk limits.
    mapping = [
        ("perTrade", "per_trade_risk_pct", float, 0.01, 100.0),
        ("maxDailyLoss", "max_daily_loss_pct", float, 0.1, 100.0),
        ("maxDailyDrawdown", "max_daily_drawdown_pct", float, 0.1, 100.0),
        ("maxWeeklyDrawdown", "max_weekly_drawdown_pct", float, 0.0, 100.0),   # 0 = off
        ("maxDrawdown", "max_account_drawdown_pct", float, 0.1, 100.0),
        ("maxTrades", "max_trades_per_day", int, 1, 1000),
        ("maxSimul", "max_simultaneous_positions", int, 1, 100),
        ("maxSpread", "max_spread_points", float, 0.1, 100000.0),
        ("maxSlippage", "max_slippage_points", float, 0.1, 100000.0),
        ("minRR", "min_rr", float, 0.1, 50.0),
    ]
    for src, dst, cast, lo, hi in mapping:
        if src in risk_web:
            try:
                value = cast(risk_web[src])
            except (TypeError, ValueError):
                continue
            if isinstance(value, float) and not math.isfinite(value):
                continue
            if value < lo or value > hi:
                continue
            setattr(cfg.risk, dst, value)
            applied.append(f"risk.{dst}")
            # Scalping mode would otherwise silently clamp these to its own
            # built-in defaults (8 trades/day, 1 position), overriding what the
            # user configured. The website value is the user's decision.
            if dst == "max_trades_per_day":
                cfg.scalping.max_trades_per_day = value
            elif dst == "max_simultaneous_positions":
                cfg.scalping.max_simultaneous_positions = value

    # Website version stamp: echoed back so the UI can confirm the engine
    # has applied exactly this save.
    try:
        version = int(web_cfg.get("version"))
        if version > 0:
            cfg.web_config_version = version
            applied.append("version")
    except (TypeError, ValueError):
        pass

    mode = web_cfg.get("mode")
    if isinstance(mode, str) and mode in ("conservative", "balanced", "aggressive", "scalping"):
        cfg.strategy.mode = mode
        applied.append("strategy.mode")

    # Which swing concepts may contribute to a setup (multi-select). Unknown
    # values are dropped rather than rejecting the whole list, so one typo
    # doesn't silently fall back to "all enabled".
    concepts = web_cfg.get("enabledConcepts")
    if isinstance(concepts, list):
        clean = [c for c in concepts if isinstance(c, str) and c in STRATEGY_CONCEPTS]
        if clean:
            cfg.strategy.enabled_concepts = clean
            applied.append("strategy.enabled_concepts")

    # Scalping is a fully separate mode, never blended with the concepts
    # above - enabling it does not change enabled_concepts at all.
    if "scalpingEnabled" in web_cfg:
        cfg.scalping.enabled = bool(web_cfg["scalpingEnabled"])
        applied.append("scalping.enabled")

    web_symbols = web_cfg.get("symbols")
    if isinstance(web_symbols, list) and web_symbols:
        clean = [str(s).upper() for s in web_symbols if isinstance(s, str)]
        if clean:
            cfg.symbols.watched = clean
            applied.append("symbols")

    web_mapping = web.get("mapping")
    if isinstance(web_mapping, dict) and web_mapping:
        merged = dict(cfg.symbols.mapping)
        for k, v in web_mapping.items():
            if isinstance(k, str) and isinstance(v, str) and k and v:
                merged[k.upper()] = v
        cfg.symbols.mapping = merged
        applied.append("symbols.mapping")

    # The website offers london / ny / asia / londonny / all; the engine's
    # session table is sydney / tokyo / london / newyork. Translate so a
    # choice like "New York" is not silently ignored (which would leave the
    # bot trading whatever session it was already on).
    session = risk_web.get("session")
    if isinstance(session, str):
        resolved = WEB_SESSION_MAP.get(session.lower(), None)
        if resolved is None and session in cfg.sessions:
            resolved = [session]
        if resolved:
            resolved = [x for x in resolved if x in cfg.sessions]
        if resolved:
            cfg.risk.allowed_sessions = resolved
            cfg.scalping.allowed_sessions = list(resolved)
            applied.append("risk.allowed_sessions")

    return applied
