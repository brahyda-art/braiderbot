"""Broker abstraction.

``BrokerClient`` is the single interface between the strategy engine and any
execution backend:

* ``BridgeBroker``  - the real MT5 bridge (see ``mt5_bridge/bridge.py``).
  Talks HTTP+token to the Windows machine running the MT5 terminal.
* ``PaperBroker``   - explicit, clearly-labelled simulator for PAPER mode.

Nothing in this module fakes results: BridgeBroker raises on any transport
error so callers fail safe, and PaperBroker marks every account/trade with
``mode='paper'``.
"""

from __future__ import annotations

import abc
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

import requests


@dataclass
class AccountInfo:
    login: str = ""
    server: str = ""
    broker: str = ""
    currency: str = "USD"
    balance: float = 0.0
    equity: float = 0.0
    margin: float = 0.0
    free_margin: float = 0.0
    leverage: int = 0
    mode: str = "unknown"          # demo | contest | real | paper

    def masked(self) -> Dict[str, Any]:
        login = str(self.login)
        return {
            "login": (login[:2] + "***" + login[-2:]) if len(login) > 4 else "***",
            "server": self.server, "broker": self.broker, "currency": self.currency,
            "balance": round(self.balance, 2), "equity": round(self.equity, 2),
            "margin": round(self.margin, 2), "freeMargin": round(self.free_margin, 2),
            "leverage": self.leverage, "type": self.mode,
        }


@dataclass
class Position:
    ticket: str
    symbol: str
    side: str                  # buy | sell
    lots: float
    open_price: float
    sl: float = 0.0
    tp: float = 0.0
    profit: float = 0.0
    swap: float = 0.0
    comment: str = ""
    magic: int = 0
    opened_at: int = 0


@dataclass
class PendingOrderInfo:
    ticket: str
    symbol: str
    kind: str                  # buy_limit | sell_limit
    lots: float
    price: float
    sl: float = 0.0
    tp: float = 0.0
    comment: str = ""
    magic: int = 0
    created_at: int = 0


@dataclass
class OrderResult:
    ok: bool
    ticket: Optional[str] = None
    price: Optional[float] = None
    retcode: Optional[int] = None
    comment: str = ""
    raw: Dict[str, Any] = field(default_factory=dict)


class BrokerError(RuntimeError):
    """Raised for any broker/bridge failure. Callers must fail safe."""


class BrokerClient(abc.ABC):
    mode: str = "abstract"

    # -- account / data -----------------------------------------------------
    @abc.abstractmethod
    def health(self) -> Dict[str, Any]: ...
    @abc.abstractmethod
    def account(self) -> AccountInfo: ...
    @abc.abstractmethod
    def symbol_specs(self, symbol: str) -> Dict[str, Any]: ...
    @abc.abstractmethod
    def rates(self, symbol: str, timeframe: str, count: int) -> List[Dict[str, Any]]: ...
    @abc.abstractmethod
    def tick(self, symbol: str) -> Dict[str, Any]: ...

    # -- positions / orders ---------------------------------------------------
    @abc.abstractmethod
    def positions(self) -> List[Position]: ...
    @abc.abstractmethod
    def pending_orders(self) -> List[PendingOrderInfo]: ...
    @abc.abstractmethod
    def market_order(self, symbol: str, side: str, lots: float, sl: float, tp: float,
                     comment: str = "", magic: int = 0,
                     deviation_points: float = 10.0) -> OrderResult: ...
    @abc.abstractmethod
    def limit_order(self, symbol: str, side: str, lots: float, price: float,
                    sl: float, tp: float, comment: str = "", magic: int = 0,
                    expiration_ms: Optional[int] = None) -> OrderResult: ...
    @abc.abstractmethod
    def modify_position(self, ticket: str, sl: Optional[float],
                        tp: Optional[float]) -> OrderResult: ...
    @abc.abstractmethod
    def close_position(self, ticket: str, lots: Optional[float] = None) -> OrderResult: ...
    @abc.abstractmethod
    def cancel_order(self, ticket: str) -> OrderResult: ...


class BridgeBroker(BrokerClient):
    """HTTP client for the MT5 bridge service (mt5_bridge/bridge.py)."""

    mode = "bridge"

    def __init__(self, base_url: str, token: str, timeout: float = 10.0):
        self.base_url = base_url.rstrip("/")
        self.token = token
        self.timeout = timeout
        self._session = requests.Session()
        self._session.headers.update({"Authorization": f"Bearer {token}"})

    def _request(self, method: str, path: str, json_body: Optional[Dict] = None,
                 params: Optional[Dict] = None) -> Dict[str, Any]:
        try:
            resp = self._session.request(
                method, f"{self.base_url}{path}", json=json_body, params=params,
                timeout=self.timeout,
            )
        except requests.RequestException as exc:
            raise BrokerError(f"bridge unreachable: {exc}") from exc
        if resp.status_code == 401:
            raise BrokerError("bridge authentication rejected (check BRIDGE_TOKEN)")
        if resp.status_code >= 400:
            try:
                detail = resp.json().get("detail", resp.text[:200])
            except Exception:
                detail = resp.text[:200]
            raise BrokerError(f"bridge error {resp.status_code}: {detail}")
        return resp.json()

    # -- account / data -------------------------------------------------------
    def health(self) -> Dict[str, Any]:
        return self._request("GET", "/health")

    def connect_account(self, login: str, password: str, server: str) -> Dict[str, Any]:
        return self._request("POST", "/account/connect", {"login": int(login), "password": password, "server": server})

    def disconnect_account(self) -> Dict[str, Any]:
        return self._request("POST", "/account/disconnect", {})

    def account(self) -> AccountInfo:
        d = self._request("GET", "/account")
        return AccountInfo(
            login=str(d.get("login", "")), server=d.get("server", ""),
            broker=d.get("company", ""), currency=d.get("currency", "USD"),
            balance=float(d.get("balance", 0)), equity=float(d.get("equity", 0)),
            margin=float(d.get("margin", 0)), free_margin=float(d.get("margin_free", 0)),
            leverage=int(d.get("leverage", 0)), mode=str(d.get("trade_mode", "unknown")),
        )

    def symbol_specs(self, symbol: str) -> Dict[str, Any]:
        return self._request("GET", "/symbol", params={"symbol": symbol})

    def rates(self, symbol: str, timeframe: str, count: int) -> List[Dict[str, Any]]:
        d = self._request("GET", "/rates",
                          params={"symbol": symbol, "timeframe": timeframe, "count": count})
        return d.get("rates", [])

    def tick(self, symbol: str) -> Dict[str, Any]:
        return self._request("GET", "/tick", params={"symbol": symbol})

    # -- positions / orders ------------------------------------------------------
    def positions(self) -> List[Position]:
        d = self._request("GET", "/positions")
        return [Position(
            ticket=str(p["ticket"]), symbol=p["symbol"], side=p["type"],
            lots=float(p["lots"]), open_price=float(p["open_price"]),
            sl=float(p.get("sl", 0)), tp=float(p.get("tp", 0)),
            profit=float(p.get("profit", 0)), swap=float(p.get("swap", 0)),
            comment=p.get("comment", ""), magic=int(p.get("magic", 0)),
            opened_at=int(p.get("time", 0)),
        ) for p in d.get("positions", [])]

    def pending_orders(self) -> List[PendingOrderInfo]:
        d = self._request("GET", "/orders")
        return [PendingOrderInfo(
            ticket=str(o["ticket"]), symbol=o["symbol"], kind=o["type"],
            lots=float(o["lots"]), price=float(o["price_open"]),
            sl=float(o.get("sl", 0)), tp=float(o.get("tp", 0)),
            comment=o.get("comment", ""), magic=int(o.get("magic", 0)),
            created_at=int(o.get("time_setup", 0)),
        ) for o in d.get("orders", [])]

    def market_order(self, symbol: str, side: str, lots: float, sl: float, tp: float,
                     comment: str = "", magic: int = 0,
                     deviation_points: float = 10.0) -> OrderResult:
        d = self._request("POST", "/order/market", {
            "symbol": symbol, "side": side, "lots": lots, "sl": sl, "tp": tp,
            "comment": comment, "magic": magic, "deviation_points": deviation_points,
        })
        return OrderResult(ok=bool(d.get("ok")), ticket=str(d.get("ticket")) if d.get("ticket") else None,
                           price=d.get("price"), retcode=d.get("retcode"),
                           comment=d.get("comment", ""), raw=d)

    def limit_order(self, symbol: str, side: str, lots: float, price: float,
                    sl: float, tp: float, comment: str = "", magic: int = 0,
                    expiration_ms: Optional[int] = None) -> OrderResult:
        d = self._request("POST", "/order/limit", {
            "symbol": symbol, "side": side, "lots": lots, "price": price,
            "sl": sl, "tp": tp, "comment": comment, "magic": magic,
            "expiration_ms": expiration_ms,
        })
        return OrderResult(ok=bool(d.get("ok")), ticket=str(d.get("ticket")) if d.get("ticket") else None,
                           price=d.get("price"), retcode=d.get("retcode"),
                           comment=d.get("comment", ""), raw=d)

    def modify_position(self, ticket: str, sl: Optional[float],
                        tp: Optional[float]) -> OrderResult:
        d = self._request("POST", "/position/modify",
                          {"ticket": ticket, "sl": sl, "tp": tp})
        return OrderResult(ok=bool(d.get("ok")), comment=d.get("comment", ""), raw=d)

    def close_position(self, ticket: str, lots: Optional[float] = None) -> OrderResult:
        body: Dict[str, Any] = {"ticket": ticket}
        if lots is not None:
            body["lots"] = lots
        d = self._request("POST", "/position/close", body)
        return OrderResult(ok=bool(d.get("ok")), comment=d.get("comment", ""), raw=d)

    def position_result(self, ticket: str) -> Dict[str, Any]:
        """Realized result (profit incl. swap/commission, close price, reason) of a
        position that is no longer open. {'found': False} if MT5 has no history for it."""
        return self._request("GET", "/deals", params={"position": int(ticket)})

    def cancel_order(self, ticket: str) -> OrderResult:
        d = self._request("POST", "/order/cancel", {"ticket": ticket})
        return OrderResult(ok=bool(d.get("ok")), comment=d.get("comment", ""), raw=d)
