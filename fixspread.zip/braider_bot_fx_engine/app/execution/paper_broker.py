"""PAPER broker - a clearly-labelled simulator (spec section 25).

This is NOT a fake "success" wrapper: it is an honest simulation engine used
only when ``execution.mode = paper``.  Every account/trade object it returns
is tagged ``mode='paper'``.  It simulates fills against the configured data
feed prices with a configurable spread and slippage, maintains pending
limit orders with expiration, broker-style stops_level and volume
normalization constraints.

Paper state is in-memory only; the journal (SQLite) is the durable record.
"""

from __future__ import annotations

import threading
import time
import uuid
from typing import Any, Dict, List, Optional

from ..market.candles import Candle
from ..risk.position_sizing import SymbolSpec
from .broker_client import (AccountInfo, BrokerClient, BrokerError,
                            OrderResult, PendingOrderInfo, Position)

# Approximate specs used ONLY for paper simulation of instruments when the
# bridge is not connected.  Real DEMO/LIVE trading always uses live broker
# specs from the bridge.
PAPER_DEFAULT_SPECS: Dict[str, Dict[str, float]] = {
    "EURUSD": {"tick_size": 0.00001, "tick_value": 1.0, "contract_size": 100000,
               "point": 0.00001, "volume_min": 0.01, "volume_step": 0.01},
    "GBPUSD": {"tick_size": 0.00001, "tick_value": 1.0, "contract_size": 100000,
               "point": 0.00001, "volume_min": 0.01, "volume_step": 0.01},
    "USDCAD": {"tick_size": 0.00001, "tick_value": 0.8, "contract_size": 100000,
               "point": 0.00001, "volume_min": 0.01, "volume_step": 0.01},
    "XAUUSD": {"tick_size": 0.01, "tick_value": 1.0, "contract_size": 100,
               "point": 0.01, "volume_min": 0.01, "volume_step": 0.01},
    "BTCUSD": {"tick_size": 0.01, "tick_value": 0.01, "contract_size": 1,
               "point": 0.01, "volume_min": 0.01, "volume_step": 0.01},
}


class PaperBroker(BrokerClient):
    """Simulated broker fed by a DataFeed. Trades marked mode='paper'."""

    mode = "paper"

    def __init__(self, feed, spread_points: Dict[str, float],
                 start_balance: float = 10000.0, currency: str = "USD",
                 spec_overrides: Optional[Dict[str, Dict[str, float]]] = None):
        self.feed = feed
        self.spread_points = dict(spread_points)
        self.start_balance = float(start_balance)
        self.currency = currency
        self.spec_overrides = spec_overrides or {}
        self._lock = threading.RLock()
        self._positions: Dict[str, Dict[str, Any]] = {}
        self._orders: Dict[str, Dict[str, Any]] = {}
        self._balance: float = self.start_balance
        self._specs_cache: Dict[str, SymbolSpec] = {}

    # ------------------------------------------------------------------
    def symbol_specs(self, symbol: str) -> Dict[str, Any]:
        base = dict(PAPER_DEFAULT_SPECS.get(symbol.upper(), {
            "tick_size": 0.00001, "tick_value": 1.0, "contract_size": 100000,
            "point": 0.00001, "volume_min": 0.01, "volume_step": 0.01,
        }))
        base.update(self.spec_overrides.get(symbol.upper(), {}))
        base["symbol"] = symbol
        base["stops_level_points"] = 0
        return base

    def spread_for(self, symbol: str) -> float:
        return float(self.spread_points.get(symbol.upper(), 15))

    def _spread_price(self, symbol: str) -> float:
        specs = self.symbol_specs(symbol)
        return self.spread_for(symbol) * float(specs.get("point", 0.00001))

    def last_price(self, symbol: str) -> Optional[Candle]:
        candles = self.feed.get_rates(symbol, "M5", 2)
        return candles[-1] if candles else None

    # ------------------------------------------------------------------
    def health(self) -> Dict[str, Any]:
        return {"ok": True, "mode": "paper", "detail": "local simulator (no live orders)"}

    def account(self) -> AccountInfo:
        with self._lock:
            floating = self._floating_pnl()
            eq = self._balance + floating
            return AccountInfo(
                login="PAPER", server="paper-sim", broker="BRAIDERTECH (simulated)",
                currency=self.currency, balance=round(self._balance, 2),
                equity=round(eq, 2), leverage=100, mode="paper",
            )

    def _floating_pnl(self) -> float:
        total = 0.0
        for p in self._positions.values():
            candle = self.last_price(p["symbol"])
            if not candle:
                continue
            specs = self.symbol_specs(p["symbol"])
            vpu = specs["tick_value"] / specs["tick_size"]
            mid = candle.close
            if p["side"] == "buy":
                total += (mid - p["open_price"]) * vpu * p["lots"]
            else:
                total += (p["open_price"] - mid) * vpu * p["lots"]
        return total

    def rates(self, symbol: str, timeframe: str, count: int) -> List[Dict[str, Any]]:
        candles = self.feed.get_rates(symbol, timeframe, count)
        return [{"time": c.time, "open": c.open, "high": c.high,
                 "low": c.low, "close": c.close, "volume": c.volume} for c in candles]

    def tick(self, symbol: str) -> Dict[str, Any]:
        candle = self.last_price(symbol)
        if not candle:
            raise BrokerError(f"paper feed has no data for {symbol}")
        spread = self._spread_price(symbol)
        bid = candle.close
        return {"time": int(time.time()), "bid": bid, "ask": bid + spread,
                "spread_points": self.spread_for(symbol)}

    # ------------------------------------------------------------------
    def positions(self) -> List[Position]:
        with self._lock:
            out = []
            for p in self._positions.values():
                candle = self.last_price(p["symbol"])
                specs = self.symbol_specs(p["symbol"])
                vpu = specs["tick_value"] / specs["tick_size"]
                profit = 0.0
                if candle:
                    mid = candle.close
                    profit = ((mid - p["open_price"]) if p["side"] == "buy"
                              else (p["open_price"] - mid)) * vpu * p["lots"]
                out.append(Position(
                    ticket=p["ticket"], symbol=p["symbol"], side=p["side"],
                    lots=p["lots"], open_price=p["open_price"], sl=p["sl"],
                    tp=p["tp"], profit=profit, comment=p["comment"],
                    magic=p["magic"], opened_at=p["opened_at"],
                ))
            return out

    def pending_orders(self) -> List[PendingOrderInfo]:
        with self._lock:
            return [PendingOrderInfo(
                ticket=o["ticket"], symbol=o["symbol"], kind=o["kind"],
                lots=o["lots"], price=o["price"], sl=o["sl"], tp=o["tp"],
                comment=o["comment"], magic=o["magic"], created_at=o["created_at"],
            ) for o in self._orders.values()]

    # ------------------------------------------------------------------
    def market_order(self, symbol: str, side: str, lots: float, sl: float, tp: float,
                     comment: str = "", magic: int = 0,
                     deviation_points: float = 10.0) -> OrderResult:
        candle = self.last_price(symbol)
        if not candle:
            return OrderResult(ok=False, comment="no paper data for symbol")
        spread = self._spread_price(symbol)
        slippage = deviation_points * float(self.symbol_specs(symbol).get("point", 0.00001))
        if side == "buy":
            fill = candle.close + spread + slippage
        else:
            fill = candle.close - slippage
        ticket = uuid.uuid4().hex[:10]
        with self._lock:
            self._positions[ticket] = {
                "ticket": ticket, "symbol": symbol, "side": side, "lots": lots,
                "open_price": fill, "sl": sl, "tp": tp, "comment": comment,
                "magic": magic, "opened_at": int(time.time() * 1000),
            }
        return OrderResult(ok=True, ticket=ticket, price=fill, retcode=10009,
                           comment="paper fill", raw={"mode": "paper"})

    def limit_order(self, symbol: str, side: str, lots: float, price: float,
                    sl: float, tp: float, comment: str = "", magic: int = 0,
                    expiration_ms: Optional[int] = None) -> OrderResult:
        ticket = uuid.uuid4().hex[:10]
        with self._lock:
            self._orders[ticket] = {
                "ticket": ticket, "symbol": symbol,
                "kind": f"{side}_limit", "lots": lots, "price": price,
                "sl": sl, "tp": tp, "comment": comment, "magic": magic,
                "created_at": int(time.time() * 1000),
                "expires_at": expiration_ms,
            }
        return OrderResult(ok=True, ticket=ticket, price=price, retcode=10009,
                           comment="paper pending placed", raw={"mode": "paper"})

    def modify_position(self, ticket: str, sl: Optional[float],
                        tp: Optional[float]) -> OrderResult:
        with self._lock:
            p = self._positions.get(ticket)
            if not p:
                return OrderResult(ok=False, comment="position not found")
            if sl is not None:
                p["sl"] = sl
            if tp is not None:
                p["tp"] = tp
            return OrderResult(ok=True, comment="paper modified")

    def close_position(self, ticket: str, lots: Optional[float] = None) -> OrderResult:
        with self._lock:
            p = self._positions.get(ticket)
            if not p:
                return OrderResult(ok=False, comment="position not found")
            candle = self.last_price(p["symbol"])
            specs = self.symbol_specs(p["symbol"])
            vpu = specs["tick_value"] / specs["tick_size"]
            close_vol = lots if (lots and lots <= p["lots"]) else p["lots"]
            profit = 0.0
            if candle:
                mid = candle.close
                profit = ((mid - p["open_price"]) if p["side"] == "buy"
                          else (p["open_price"] - mid)) * vpu * close_vol
            self._balance += profit
            if close_vol >= p["lots"]:
                del self._positions[ticket]
            else:
                p["lots"] = round(p["lots"] - close_vol, 8)
            return OrderResult(ok=True, price=candle.close if candle else None,
                               comment=f"paper close p/l={profit:.2f}",
                               raw={"profit": profit, "lots": close_vol, "mode": "paper"})

    def cancel_order(self, ticket: str) -> OrderResult:
        with self._lock:
            if ticket in self._orders:
                del self._orders[ticket]
                return OrderResult(ok=True, comment="paper pending cancelled")
            return OrderResult(ok=False, comment="order not found")

    # ------------------------------------------------------------------
    def on_candle_close(self, symbol: str, candle: Candle) -> List[Dict[str, Any]]:
        """Advance the simulation when a candle closes: fill limit orders,
        trigger SL/TP.  Returns list of events for the journal/manager."""
        events: List[Dict[str, Any]] = []
        spread = self._spread_price(symbol)
        now_ms = int(time.time() * 1000)

        with self._lock:
            # 1. Pending limit fills (touch of price with spread-adjusted quote)
            for ticket in list(self._orders.keys()):
                o = self._orders[ticket]
                if o["symbol"] != symbol:
                    continue
                if o.get("expires_at") and now_ms > o["expires_at"]:
                    del self._orders[ticket]
                    events.append({"type": "pending_expired", "ticket": ticket})
                    continue
                hit = (o["kind"] == "buy_limit" and candle.low <= o["price"]) or \
                      (o["kind"] == "sell_limit" and candle.high >= o["price"])
                if hit:
                    del self._orders[ticket]
                    fill = o["price"] + (spread if o["kind"] == "buy_limit" else -spread)
                    pticket = uuid.uuid4().hex[:10]
                    self._positions[pticket] = {
                        "ticket": pticket, "symbol": symbol,
                        "side": "buy" if o["kind"] == "buy_limit" else "sell",
                        "lots": o["lots"], "open_price": fill,
                        "sl": o["sl"], "tp": o["tp"], "comment": o["comment"],
                        "magic": o["magic"], "opened_at": now_ms,
                    }
                    events.append({"type": "pending_filled", "ticket": ticket,
                                   "position_ticket": pticket, "price": fill})

            # 2. SL/TP on open positions of this symbol
            for ticket in list(self._positions.keys()):
                p = self._positions[ticket]
                if p["symbol"] != symbol:
                    continue
                closed = None
                if p["side"] == "buy":
                    if p["sl"] and candle.low <= p["sl"]:
                        closed = ("sl", p["sl"])
                    elif p["tp"] and candle.high >= p["tp"]:
                        closed = ("tp", p["tp"])
                else:
                    if p["sl"] and candle.high >= p["sl"]:
                        closed = ("sl", p["sl"])
                    elif p["tp"] and candle.low <= p["tp"]:
                        closed = ("tp", p["tp"])
                if closed:
                    specs = self.symbol_specs(symbol)
                    vpu = specs["tick_value"] / specs["tick_size"]
                    price = closed[1]
                    profit = ((price - p["open_price"]) if p["side"] == "buy"
                              else (p["open_price"] - price)) * vpu * p["lots"]
                    self._balance += profit
                    del self._positions[ticket]
                    events.append({"type": "position_closed", "ticket": ticket,
                                   "reason": closed[0], "price": price,
                                   "profit": profit, "lots": p["lots"]})
        return events

    def reset(self, balance: Optional[float] = None) -> None:
        with self._lock:
            self._positions.clear()
            self._orders.clear()
            self._balance = float(balance if balance is not None else self.start_balance)
