"""Trade journal + structured event logging (spec sections 19, 20).

Every detected setup is journaled - including rejected ones - so the answer
to "WHY did the bot trade / refuse to trade" is always available.  Events go
to SQLite (durable) and to the category loggers (files).  The optional
Firebase sink mirrors them to the website collections.
"""

from __future__ import annotations

import uuid
from typing import Any, Dict, Optional

from ..logging_config import get as cat_logger
from ..state_store import SetupRecord, StateStore, utc_now_ms


class Journal:
    def __init__(self, store: StateStore, firebase_sink=None):
        self.store = store
        self.firebase = firebase_sink      # optional: services.firebase_sync sink

    # ------------------------------------------------------------------
    def log_event(self, category: str, level: str, message: str,
                  data: Optional[Dict[str, Any]] = None) -> None:
        self.store.add_event(category, level, message, data)
        lg = cat_logger(category if category in ("trade", "risk", "security") else "engine")
        getattr(lg, level.lower(), lg.info)(f"{message} | {data or ''}")
        if self.firebase is not None:
            try:
                self.firebase.push_log(level, message, {**(data or {}), "_cat": category})
            except Exception:
                pass

    def log_trade_event(self, level: str, message: str, data: Optional[Dict] = None) -> None:
        self.log_event("trade", level, message, data)

    def log_risk(self, level: str, message: str, data: Optional[Dict] = None) -> None:
        self.log_event("risk", level, message, data)

    def log_security(self, level: str, message: str, data: Optional[Dict] = None) -> None:
        self.log_event("security", level, message, data)

    # ------------------------------------------------------------------
    def record_setup(self, setup_dict: Dict[str, Any]) -> str:
        setup_id = setup_dict.get("id") or f"su-{uuid.uuid4().hex[:12]}"
        rec = SetupRecord(
            id=setup_id,
            ts=int(setup_dict.get("ts") or utc_now_ms()),
            symbol=setup_dict["symbol"],
            direction=setup_dict["direction"],
            kind=setup_dict["kind"],
            score=setup_dict.get("score"),
            decision=setup_dict.get("decision", "rejected"),
            reject_stage=setup_dict.get("reject_stage"),
            reject_reason=setup_dict.get("reject_reason"),
            entry=setup_dict.get("entry"), sl=setup_dict.get("sl"),
            tp=setup_dict.get("tp"), lots=setup_dict.get("lots"),
            details=setup_dict.get("details", {}),
        )
        self.store.add_setup(rec)
        if self.firebase is not None:
            try:
                self.firebase.push_setup(rec)
            except Exception:
                pass
        return setup_id
