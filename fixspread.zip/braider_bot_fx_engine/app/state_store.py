"""SQLite persistence layer (spec sections 19, 21, 31).

Stores: engine state machine, daily risk stats, the trade journal (including
rejected setups), open-trade theses for restart recovery, and an order
idempotency cache.  The schema is deliberately simple and JSON-based so a
Firebase/Firestore adapter can mirror the same documents without reshaping
(see services/firebase_sync.py).
"""

from __future__ import annotations

import json
import sqlite3
import threading
import time
from dataclasses import dataclass, field, fields
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

SCHEMA = """
CREATE TABLE IF NOT EXISTS kv_state (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS setups (
    id TEXT PRIMARY KEY,
    ts INTEGER NOT NULL,
    symbol TEXT NOT NULL,
    direction TEXT NOT NULL,
    kind TEXT NOT NULL,
    score REAL,
    decision TEXT NOT NULL,
    reject_stage TEXT,
    reject_reason TEXT,
    entry REAL, sl REAL, tp REAL, lots REAL,
    details TEXT
);
CREATE INDEX IF NOT EXISTS idx_setups_ts ON setups(ts);
CREATE TABLE IF NOT EXISTS trades (
    id TEXT PRIMARY KEY,
    setup_id TEXT,
    ticket TEXT,
    symbol TEXT NOT NULL,
    side TEXT NOT NULL,
    lots REAL NOT NULL,
    entry REAL,
    sl REAL, tp REAL,
    status TEXT NOT NULL,
    opened_at INTEGER,
    closed_at INTEGER,
    close_price REAL,
    profit REAL DEFAULT 0,
    r_multiple REAL,
    exit_reason TEXT,
    mode TEXT NOT NULL,
    thesis TEXT,
    management TEXT,
    comment TEXT
);
CREATE INDEX IF NOT EXISTS idx_trades_status ON trades(status);
CREATE TABLE IF NOT EXISTS orders (
    id TEXT PRIMARY KEY,
    setup_id TEXT,
    broker_ticket TEXT,
    kind TEXT NOT NULL,
    symbol TEXT NOT NULL,
    side TEXT NOT NULL,
    price REAL,
    sl REAL, tp REAL,
    lots REAL,
    status TEXT NOT NULL,
    placed_at INTEGER,
    expires_at INTEGER,
    cancel_reason TEXT
);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE TABLE IF NOT EXISTS daily_stats (
    day TEXT PRIMARY KEY,
    start_balance REAL,
    start_equity REAL,
    peak_equity REAL,
    trades INTEGER DEFAULT 0,
    wins INTEGER DEFAULT 0,
    losses INTEGER DEFAULT 0,
    realized_pnl REAL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS idempotency (
    key TEXT PRIMARY KEY,
    created_at INTEGER NOT NULL,
    result TEXT
);
CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts INTEGER NOT NULL,
    category TEXT NOT NULL,
    level TEXT NOT NULL,
    message TEXT NOT NULL,
    data TEXT
);
"""


def utc_now_ms() -> int:
    return int(time.time() * 1000)


def day_key(ts_ms: Optional[int] = None) -> str:
    dt = datetime.fromtimestamp((ts_ms or time.time()), tz=timezone.utc)
    return dt.strftime("%Y-%m-%d")


@dataclass
class TradeRecord:
    id: str
    symbol: str
    side: str
    lots: float
    status: str = "open"           # open | pending | closed | cancelled
    setup_id: Optional[str] = None
    ticket: Optional[str] = None
    entry: Optional[float] = None
    sl: Optional[float] = None
    tp: Optional[float] = None
    opened_at: Optional[int] = None
    closed_at: Optional[int] = None
    close_price: Optional[float] = None
    profit: float = 0.0
    r_multiple: Optional[float] = None
    exit_reason: Optional[str] = None
    mode: str = "paper"
    thesis: Dict[str, Any] = field(default_factory=dict)
    management: Dict[str, Any] = field(default_factory=dict)
    comment: str = ""

    def to_row(self) -> Dict[str, Any]:
        d = self.__dict__.copy()
        d["thesis"] = json.dumps(self.thesis or {})
        d["management"] = json.dumps(self.management or {})
        return d

    @staticmethod
    def from_row(row: sqlite3.Row) -> "TradeRecord":
        d = dict(row)
        d["thesis"] = json.loads(d.get("thesis") or "{}")
        d["management"] = json.loads(d.get("management") or "{}")
        # Defensive: the on-disk table may carry extra legacy columns from an
        # earlier schema version (CREATE TABLE IF NOT EXISTS never migrates
        # an existing table), and sqlite3.Row -> dict(row) pulls every
        # physical column. Drop anything the current dataclass doesn't
        # declare rather than letting a stale column crash construction.
        known = {f.name for f in fields(TradeRecord)}
        d = {k: v for k, v in d.items() if k in known}
        return TradeRecord(**d)

    # Shape consumed by the existing website (`users/{uid}/trades` documents).
    def to_web(self) -> Dict[str, Any]:
        return {
            "side": self.side,
            "symbol": self.symbol,
            "lots": float(self.lots),
            "entry": self.entry,
            "sl": self.sl,
            "tp": self.tp,
            "setup": (self.thesis or {}).get("kind", "bot"),
            "status": self.status,
            "openedAt": self.opened_at,
            "closedAt": self.closed_at,
            "closePrice": self.close_price,
            "profit": round(self.profit, 2),
            # open trades: `profit` holds the live floating P/L; the website reads it as `pl`
            "pl": round(self.profit, 2),
            "rMultiple": self.r_multiple,
            "exitReason": self.exit_reason,
            "mode": self.mode,
            "ticket": self.ticket,
        }


@dataclass
class SetupRecord:
    id: str
    ts: int
    symbol: str
    direction: str
    kind: str
    score: Optional[float] = None
    decision: str = "rejected"
    reject_stage: Optional[str] = None
    reject_reason: Optional[str] = None
    entry: Optional[float] = None
    sl: Optional[float] = None
    tp: Optional[float] = None
    lots: Optional[float] = None
    details: Dict[str, Any] = field(default_factory=dict)


class StateStore:
    """Thread-safe SQLite wrapper.  One connection guarded by a lock keeps
    things simple and avoids multi-connection locking surprises."""

    def __init__(self, db_path: str | Path):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        with self._lock, self._conn:
            self._conn.executescript(SCHEMA)

    def close(self) -> None:
        with self._lock:
            self._conn.close()

    # -- generic ----------------------------------------------------------
    def execute(self, sql: str, params: tuple = ()) -> None:
        with self._lock, self._conn:
            self._conn.execute(sql, params)

    def query(self, sql: str, params: tuple = ()) -> List[sqlite3.Row]:
        with self._lock:
            cur = self._conn.execute(sql, params)
            return cur.fetchall()

    # -- kv state ---------------------------------------------------------
    def kv_set(self, key: str, value: Any) -> None:
        self.execute(
            "INSERT INTO kv_state(key, value) VALUES(?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, json.dumps(value)),
        )

    def kv_get(self, key: str, default: Any = None) -> Any:
        rows = self.query("SELECT value FROM kv_state WHERE key=?", (key,))
        if not rows:
            return default
        return json.loads(rows[0]["value"])

    # -- trades -----------------------------------------------------------
    def upsert_trade(self, trade: TradeRecord) -> None:
        cols = list(trade.to_row().keys())
        placeholders = ",".join("?" for _ in cols)
        updates = ",".join(f"{c}=excluded.{c}" for c in cols if c != "id")
        vals = [trade.to_row()[c] for c in cols]
        self.execute(
            f"INSERT INTO trades({','.join(cols)}) VALUES({placeholders}) "
            f"ON CONFLICT(id) DO UPDATE SET {updates}",
            tuple(vals),
        )

    def get_trade(self, trade_id: str) -> Optional[TradeRecord]:
        rows = self.query("SELECT * FROM trades WHERE id=?", (trade_id,))
        return TradeRecord.from_row(rows[0]) if rows else None

    def get_trade_by_ticket(self, ticket: str) -> Optional[TradeRecord]:
        rows = self.query("SELECT * FROM trades WHERE ticket=? ORDER BY opened_at DESC LIMIT 1", (str(ticket),))
        return TradeRecord.from_row(rows[0]) if rows else None

    def open_trades(self) -> List[TradeRecord]:
        return [TradeRecord.from_row(r) for r in
                self.query("SELECT * FROM trades WHERE status IN ('open','pending')")]

    def recent_trades(self, limit: int = 100) -> List[TradeRecord]:
        return [TradeRecord.from_row(r) for r in
                self.query("SELECT * FROM trades ORDER BY opened_at DESC LIMIT ?", (limit,))]

    def closed_trades_for_day(self, day: str) -> List[TradeRecord]:
        start = int(datetime.strptime(day, "%Y-%m-%d")
                    .replace(tzinfo=timezone.utc).timestamp() * 1000)
        end = start + 86_400_000
        return [TradeRecord.from_row(r) for r in self.query(
            "SELECT * FROM trades WHERE status='closed' AND closed_at BETWEEN ? AND ?",
            (start, end))]

    # -- setups journal ----------------------------------------------------
    def add_setup(self, rec: SetupRecord) -> None:
        self.execute(
            "INSERT OR REPLACE INTO setups(id, ts, symbol, direction, kind, score, decision,"
            " reject_stage, reject_reason, entry, sl, tp, lots, details)"
            " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (rec.id, rec.ts, rec.symbol, rec.direction, rec.kind, rec.score, rec.decision,
             rec.reject_stage, rec.reject_reason, rec.entry, rec.sl, rec.tp, rec.lots,
             json.dumps(rec.details or {})),
        )

    # -- orders -------------------------------------------------------------
    def upsert_order(self, order: Dict[str, Any]) -> None:
        keys = ("id", "setup_id", "broker_ticket", "kind", "symbol", "side", "price",
                "sl", "tp", "lots", "status", "placed_at", "expires_at", "cancel_reason")
        row = {k: order.get(k) for k in keys}
        self.execute(
            f"INSERT OR REPLACE INTO orders({','.join(keys)}) "
            f"VALUES({','.join('?' for _ in keys)})",
            tuple(row[k] for k in keys),
        )

    def pending_orders(self) -> List[Dict[str, Any]]:
        return [dict(r) for r in self.query("SELECT * FROM orders WHERE status='pending'")]

    # -- daily stats ---------------------------------------------------------
    def init_daily(self, day: str, balance: float, equity: float) -> None:
        self.execute(
            "INSERT OR IGNORE INTO daily_stats(day, start_balance, start_equity, peak_equity)"
            " VALUES(?,?,?,?)",
            (day, balance, equity, equity),
        )

    def update_daily(self, day: str, **fields: Any) -> None:
        if not fields:
            return
        assigns = ",".join(f"{k}=?" for k in fields)
        self.execute(
            f"UPDATE daily_stats SET {assigns} WHERE day=?",
            tuple(fields.values()) + (day,),
        )

    def bump_daily_peak(self, day: str, equity: float) -> None:
        self.execute(
            "UPDATE daily_stats SET peak_equity=MAX(peak_equity, ?) WHERE day=?",
            (equity, day),
        )

    def get_daily(self, day: str) -> Dict[str, Any]:
        rows = self.query("SELECT * FROM daily_stats WHERE day=?", (day,))
        return dict(rows[0]) if rows else {}

    def recent_daily(self, limit: int = 30) -> List[Dict[str, Any]]:
        """Most recent daily_stats rows, newest first (spec: trades/wins/losses per day)."""
        rows = self.query(
            "SELECT * FROM daily_stats ORDER BY day DESC LIMIT ?",
            (min(max(limit, 1), 365),),
        )
        return [dict(r) for r in rows]

    def overall_stats(self) -> Dict[str, Any]:
        """All-time trades/wins/losses/realized_pnl across every closed trade -
        the source of truth for win rate is the trades table itself (not a sum
        of daily_stats rows), so it can never drift from what actually closed."""
        rows = self.query(
            "SELECT COUNT(*) AS trades,"
            " SUM(CASE WHEN COALESCE(profit,0) > 0 THEN 1 ELSE 0 END) AS wins,"
            " SUM(CASE WHEN COALESCE(profit,0) <= 0 THEN 1 ELSE 0 END) AS losses,"
            " COALESCE(SUM(profit), 0) AS realized_pnl"
            " FROM trades WHERE status='closed'"
        )
        row = dict(rows[0]) if rows else {}
        return {
            "trades": row.get("trades") or 0,
            "wins": row.get("wins") or 0,
            "losses": row.get("losses") or 0,
            "realized_pnl": row.get("realized_pnl") or 0,
        }

    # -- idempotency -----------------------------------------------------------
    def idempotency_check_and_set(self, key: str, ttl_seconds: int = 30) -> Optional[Dict]:
        """Returns the cached result if the key was seen within the TTL window."""
        now = utc_now_ms()
        with self._lock, self._conn:
            row = self._conn.execute(
                "SELECT created_at, result FROM idempotency WHERE key=?", (key,)
            ).fetchone()
            if row and now - row["created_at"] < ttl_seconds * 1000:
                return json.loads(row["result"]) if row["result"] else {"cached": True}
            self._conn.execute(
                "INSERT OR REPLACE INTO idempotency(key, created_at, result) VALUES(?,?,?)",
                (key, now, None),
            )
        return None

    def idempotency_store_result(self, key: str, result: Dict) -> None:
        self.execute("UPDATE idempotency SET result=? WHERE key=?", (json.dumps(result), key))

    # -- events ------------------------------------------------------------------
    def add_event(self, category: str, level: str, message: str, data: Dict | None = None) -> None:
        self.execute(
            "INSERT INTO events(ts, category, level, message, data) VALUES(?,?,?,?,?)",
            (utc_now_ms(), category, level, message, json.dumps(data or {})),
        )
