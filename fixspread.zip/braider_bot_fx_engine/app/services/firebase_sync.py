"""Firebase bridge between the engine and the EXISTING BRAIDER BOT FX website.

The website (already deployed by BRAIDERTECH) uses:

* Firestore ``users/{uid}``               - profile/config/bot state document
* Firestore ``users/{uid}/commands``      - pending commands the bridge watches
* Firestore ``users/{uid}/trades``        - trade documents (open/closed)
* Firestore ``users/{uid}/logs``          - {t, action, detail}
* Realtime DB ``live/{uid}``              - live account heartbeat

This adapter implements EXACTLY that contract so the website needs no
changes.  It requires a Firebase **service account** (server-side only,
never browser credentials) pointed to by ``FIREBASE_CREDENTIALS_PATH`` and
``FIREBASE_PROJECT_ID`` / ``FIREBASE_USER_UID`` in the environment.

Behaviour notes
---------------
* Commands are read with a single equality filter (status == pending) and
  sorted in Python. Combining that filter with ``order_by`` needs a
  composite Firestore index; without it every poll failed silently and NO
  command (start / stop / config) was ever processed.
* Commands older than COMMAND_MAX_AGE_MS are NOT executed if they are
  risky (start / resume / force_trade / close_all / config_update): a
  ``start`` clicked days ago must not fire when the VPS comes back.
  Safe commands (stop / pause / emergency) always run.
* The saved website settings (``users/{uid}.config``) are applied at start-up
  and re-applied automatically whenever they change, so a VPS restart never
  leaves the bot trading on default settings.
* Firestore writes are throttled (status only when it changes, or every
  60 s; only important log lines) to stay far below the free-plan quota of
  20,000 writes per day. Fast-moving data (balance, signals, limits) goes to
  the Realtime Database instead.

If Firebase is not configured the adapter disables itself and logs clearly -
the engine keeps running locally (SQLite + REST API still work).
"""

from __future__ import annotations

import json
import os
import threading
import time
from collections import deque
from typing import Any, Dict, Optional

from ..config import Config
from ..constants import BotState
from ..logging_config import get as cat_logger
from ..state_store import SetupRecord, utc_now_ms

log = cat_logger("engine")

#: Risky commands older than this are marked "expired" instead of executed.
COMMAND_MAX_AGE_MS = 120_000
_SAFE_STALE_COMMANDS = ("stop", "pause", "emergency")
#: Firestore status document: write at most this often unless it changed.
FS_STATUS_MIN_INTERVAL_MS = 60_000
#: Log lines: identical message suppressed for this long; hard rate cap.
LOG_DEDUPE_MS = 300_000
LOG_MAX_PER_MINUTE = 20


class WebSinkBase:
    """Interface the engine depends on (dependency inversion; spec 23)."""

    def push_status(self, snapshot: Dict[str, Any], cfg: Config) -> None: ...
    def push_trade(self, trade_web: Dict[str, Any]) -> None: ...
    def push_log(self, level: str, message: str, data: Optional[Dict]) -> None: ...
    def push_setup(self, setup: SetupRecord) -> None: ...
    def start(self, engine) -> None: ...
    def stop(self) -> None: ...


class FirebaseSink(WebSinkBase):
    """Firestore/RTDB sink + command watcher using firebase-admin."""

    def __init__(self, credentials_path: str, project_id: str, user_uid: str,
                 heartbeat_seconds: float = 20.0, config_poll_seconds: float = 10.0):
        self.credentials_path = credentials_path
        self.project_id = project_id
        self.uid = user_uid
        self.heartbeat_seconds = heartbeat_seconds
        self.config_poll_seconds = config_poll_seconds
        self._db = None
        self._rtdb = None
        self._watch_stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self.engine = None
        self._processed_commands: set[str] = set()
        self._last_cfg_sig: Optional[str] = None
        self._fs_last_sig: Optional[str] = None
        self._fs_last_at = 0
        self._log_seen: Dict[Any, int] = {}
        self._log_times: "deque[float]" = deque()

    # ------------------------------------------------------------------
    def _connect(self):
        import firebase_admin
        from firebase_admin import credentials, db as rtdb, firestore
        cred = credentials.Certificate(self.credentials_path)
        # Realtime DB in a non-US region has a different URL - set
        # FIREBASE_DATABASE_URL in .env in that case.
        db_url = os.environ.get("FIREBASE_DATABASE_URL", "").strip() or \
            f"https://{self.project_id}-default-rtdb.firebaseio.com"
        app = firebase_admin.initialize_app(cred, {
            "projectId": self.project_id,
            "databaseURL": db_url,
        })
        self._db = firestore.client(app)
        self._rtdb = rtdb

    # ------------------------------------------------------------------
    def start(self, engine) -> None:
        self.engine = engine
        try:
            self._connect()
        except Exception as exc:
            log.error(f"Firebase disabled (connect failed): {exc}")
            self._db = None
            return
        log.info(f"Firebase connected: project={self.project_id} uid={self.uid[:6]}***")
        # Apply the saved website settings BEFORE the engine loop can scan,
        # so a restart never trades on default settings.
        try:
            self._sync_config_once()
        except Exception as exc:
            log.warning(f"initial config sync failed (will retry): {exc}")
        self._thread = threading.Thread(target=self._watch_commands,
                                        name="bbfx-fb-commands", daemon=True)
        self._thread.start()
        self._cfg_thread = threading.Thread(target=self._watch_config,
                                            name="bbfx-fb-config", daemon=True)
        self._cfg_thread.start()
        self._hb_thread = threading.Thread(target=self._heartbeat_loop,
                                           name="bbfx-fb-heartbeat", daemon=True)
        self._hb_thread.start()

    def stop(self) -> None:
        self._watch_stop.set()

    # ------------------------------------------------------------------
    # command watcher: users/{uid}/commands where status == 'pending'
    # ------------------------------------------------------------------
    def _watch_commands(self) -> None:
        from google.cloud.firestore_v1.base_query import FieldFilter
        col = self._db.collection("users").document(self.uid).collection("commands")
        # Equality filter ONLY (automatic single-field index). Sorting is done
        # in Python - see the module docstring for why order_by is not used.
        query = col.where(filter=FieldFilter("status", "==", "pending")).limit(50)
        while not self._watch_stop.is_set():
            try:
                docs = list(query.stream())
                docs.sort(key=lambda d: (d.to_dict() or {}).get("createdAt", 0) or 0)
                for d in docs:
                    self._process_command_doc(d)
                if len(self._processed_commands) > 2000:
                    self._processed_commands.clear()
                time.sleep(2.0)
            except Exception as exc:
                log.warning(f"command watcher error: {exc}")
                time.sleep(5.0)

    def _process_command_doc(self, d) -> None:
        data = d.to_dict() or {}
        cmd_id = d.id
        if cmd_id in self._processed_commands:
            return
        self._processed_commands.add(cmd_id)
        action = str(data.get("action", "")).lower()
        payload = data.get("payload") or {}
        now = utc_now_ms()
        try:
            created = int(data.get("createdAt") or 0)
        except (TypeError, ValueError):
            created = 0
        if created and now - created > COMMAND_MAX_AGE_MS and \
                action not in _SAFE_STALE_COMMANDS:
            log.warning(f"command {action} is {int((now - created) / 1000)}s old - expired, not executed")
            d.reference.set({"status": "expired",
                             "result": "too old - not executed",
                             "processedAt": now}, merge=True)
            return
        result = self.engine.handle_command(action, payload)
        d.reference.set({
            "status": "done" if result.get("ok") else "rejected",
            "result": result.get("reason", "ok"),
            "processedAt": utc_now_ms(),
        }, merge=True)
        # Show the new state on the website immediately, not at the next beat.
        try:
            self.push_status(self.engine.status_snapshot(), self.engine.cfg)
        except Exception as exc:
            log.warning(f"post-command status push failed: {exc}")

    # ------------------------------------------------------------------
    # config watcher: users/{uid}.config -> engine (start-up + on change)
    # ------------------------------------------------------------------
    def _sync_config_once(self) -> None:
        snap = self._db.collection("users").document(self.uid).get()
        self.sync_config_doc(snap.to_dict() if snap.exists else {})

    def sync_config_doc(self, data: Optional[Dict[str, Any]]) -> bool:
        """Apply the website's saved settings if they changed since the last
        time. Returns True when something was applied."""
        cfg = (data or {}).get("config")
        if not isinstance(cfg, dict) or not cfg:
            return False
        payload = {"config": cfg, "mapping": (data or {}).get("mapping") or {}}
        sig = json.dumps(payload, sort_keys=True, default=str)
        if sig == self._last_cfg_sig:
            return False
        self._last_cfg_sig = sig
        if self.engine is None:
            return False
        self.engine.apply_web_doc(payload, source="auto-sync")
        return True

    def _watch_config(self) -> None:
        while not self._watch_stop.is_set():
            try:
                self._sync_config_once()
            except Exception as exc:
                log.warning(f"config watcher error: {exc}")
            self._watch_stop.wait(self.config_poll_seconds)

    def _heartbeat_loop(self) -> None:
        while not self._watch_stop.is_set():
            try:
                if self.engine is not None:
                    snap = self.engine.status_snapshot()
                    self.push_status(snap, self.engine.cfg)
            except Exception as exc:
                log.warning(f"heartbeat error: {exc}")
            self._watch_stop.wait(self.heartbeat_seconds)

    # ------------------------------------------------------------------
    # pushes
    # ------------------------------------------------------------------
    def push_status(self, snapshot: Dict[str, Any], cfg: Config) -> None:
        if self._db is None:
            return
        state_map = {
            BotState.RUNNING.value: "running",
            BotState.PAUSED.value: "paused",
            BotState.STOPPED.value: "stopped",
            BotState.EMERGENCY_STOP.value: "emergency",
        }
        # NOTE: map keys are the upper-case enum values. Looking them up with
        # a lower-cased state (the original code) never matched, so the website
        # was always told "stopped" - even while the bot was running.
        web_status = state_map.get(str(snapshot.get("state", "STOPPED")).upper(),
                                   "stopped")
        now = utc_now_ms()
        account = snapshot.get("account") or {}
        override = bool(snapshot.get("override"))
        config_version = int(snapshot.get("config_version") or 0)

        # --- Firestore: durable state. Written only when it CHANGES (or every
        # FS_STATUS_MIN_INTERVAL_MS) to protect the daily write quota. Fast
        # numbers (balance, P/L) are deliberately not part of the change test.
        stable_account = {k: v for k, v in account.items() if not isinstance(v, float)}
        sig = json.dumps([web_status, cfg.strategy.mode, bool(snapshot.get("emergency")),
                          override, bool(snapshot.get("connected")), config_version,
                          stable_account], sort_keys=True, default=str)
        if sig != self._fs_last_sig or now - self._fs_last_at >= FS_STATUS_MIN_INTERVAL_MS:
            doc = {
                "bot": {
                    "status": web_status,
                    "mode": cfg.strategy.mode,
                    "emergency": snapshot.get("emergency", False),
                    "override": override,
                    "lastSync": now,
                },
                "engine": {"configVersion": config_version, "online": True,
                           "lastSeen": now},
                "connected": bool(snapshot.get("connected")),
                "account": account,   # masked, no passwords
                "updatedAt": now,
            }
            self._db.collection("users").document(self.uid).set(doc, merge=True)
            self._fs_last_sig, self._fs_last_at = sig, now

        # --- Realtime DB: fast-moving live data for the dashboard.
        if self._rtdb is not None:
            ref = self._rtdb.reference(f"live/{self.uid}")
            ref.set({
                "status": web_status,
                "scanning": bool(snapshot.get("scanning")),
                "override": override,
                "configVersion": config_version,
                "balance": account.get("balance"),
                "equity": account.get("equity"),
                "floatingPL": snapshot.get("floating_pl", 0),
                "dailyPnl": snapshot.get("daily_pnl", 0),
                "openPositions": snapshot.get("open_positions", 0),
                "pendingOrders": snapshot.get("pending_orders", 0),
                "limits": snapshot.get("limits"),
                "signals": snapshot.get("signals") or [],
                "lastCycle": snapshot.get("last_cycle_ms"),
                "mt5": {"connected": bool(snapshot.get("connected"))},
                "lastUpdate": now,
            })

    def push_trade(self, trade_web: Dict[str, Any]) -> None:
        if self._db is None:
            return
        trade_id = str(trade_web.get("ticket") or
                       f"{trade_web.get('symbol')}-{trade_web.get('openedAt')}")
        self._db.collection("users").document(self.uid).collection("trades") \
            .document(trade_id).set(trade_web, merge=True)

    def push_log(self, level: str, message: str, data: Optional[Dict]) -> None:
        """Copy only IMPORTANT events to the website (trades, state changes,
        warnings/errors, explicit actions), de-duplicated and rate-capped.
        Everything is still kept in the local journal. Pushing every INFO
        line (each rejected setup, per symbol, per cycle) used to burn the
        free Firestore write quota within hours."""
        if self._db is None:
            return
        data = dict(data or {})
        cat = str(data.pop("_cat", "") or "")
        action = data.get("action")
        lvl = str(level).upper()
        important = (lvl in ("WARNING", "ERROR", "CRITICAL") or bool(action)
                     or cat == "trade" or str(message).startswith("state change"))
        if not important:
            return
        now = utc_now_ms()
        key = (lvl, str(action or ""), str(message)[:100])
        last = self._log_seen.get(key)
        if last is not None and now - last < LOG_DEDUPE_MS:
            return
        mono = time.monotonic()
        while self._log_times and mono - self._log_times[0] > 60:
            self._log_times.popleft()
        if len(self._log_times) >= LOG_MAX_PER_MINUTE:
            return
        self._log_times.append(mono)
        self._log_seen[key] = now
        if len(self._log_seen) > 500:
            self._log_seen = {k: v for k, v in self._log_seen.items()
                              if now - v < LOG_DEDUPE_MS}
        detail_data = {k: v for k, v in data.items() if k != "action"}
        self._db.collection("users").document(self.uid).collection("logs").add({
            "t": now,
            "action": str(action or f"ENGINE_{lvl}")[:40],
            "detail": f"{message} {detail_data or ''}".strip()[:400],
            "level": level,
        })

    def push_setup(self, setup: SetupRecord) -> None:
        # The website does not consume setups directly; keep local-only to
        # avoid polluting user-visible collections.  Hook point for future use.
        return None


class NullSink(WebSinkBase):
    """Used when Firebase is not configured (engine runs standalone)."""

    def __init__(self, reason: str = "firebase not configured"):
        self.reason = reason
        log.info(f"web sync disabled: {reason}")

    def push_status(self, snapshot, cfg) -> None: ...
    def push_trade(self, trade_web) -> None: ...
    def push_log(self, level, message, data=None) -> None: ...
    def push_setup(self, setup) -> None: ...
    def start(self, engine) -> None: ...
    def stop(self) -> None: ...


def build_sink_from_env() -> WebSinkBase:
    import os
    creds = os.environ.get("FIREBASE_CREDENTIALS_PATH", "").strip()
    project = os.environ.get("FIREBASE_PROJECT_ID", "").strip()
    uid = os.environ.get("FIREBASE_USER_UID", "").strip()
    if creds and project and uid:
        try:
            return FirebaseSink(creds, project, uid)
        except Exception as exc:
            log.error(f"firebase sink init failed: {exc}")
            return NullSink(f"firebase init failed: {exc}")
    return NullSink("FIREBASE_* env vars not set")
