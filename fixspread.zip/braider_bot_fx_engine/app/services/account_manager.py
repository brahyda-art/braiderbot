"""Single-user MT5 account profiles with one active trading connection.

Passwords are NEVER written to disk, Firestore or logs.  The website sends the
password only when connecting.  It is kept in this process's RAM (``_vault``)
so that "Select" can re-login to another saved account without asking again;
it is lost on engine restart, and the user then re-enters it.

Every profile carries an ``owner`` (the authenticated Firebase uid).  All reads
and writes are scoped to that owner, so one user can never see, select,
disconnect or delete another user's account.  Only one MT5 account can be the
active trading connection at a time (one MT5 terminal = one login).
"""
from __future__ import annotations

import json
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional


class AccountManager:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._vault: Dict[str, str] = {}      # account_id -> password (RAM only)
        self._data = self._load()
        # After a restart nothing is really connected: never trust stale flags.
        for a in self._data.get("accounts", []):
            a["status"] = "offline"
        self._data["active_account_id"] = None

    def _load(self) -> Dict[str, Any]:
        if not self.path.exists():
            return {"accounts": [], "active_account_id": None}
        try:
            return json.loads(self.path.read_text(encoding="utf-8"))
        except Exception:
            return {"accounts": [], "active_account_id": None}

    def _save(self) -> None:
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self._data, indent=2), encoding="utf-8")
        tmp.replace(self.path)

    @staticmethod
    def _public(a: Dict[str, Any]) -> Dict[str, Any]:
        out = {k: v for k, v in a.items() if k not in {"password", "login", "owner"}}
        out["account_id"] = a.get("id")
        out["connected"] = a.get("status") == "connected"
        login = str(a.get("login", ""))
        out["masked"] = (login[:2] + "••••" + login[-3:]) if len(login) >= 5 else "••••"
        return out

    def list_accounts(self, owner: str = "") -> Dict[str, Any]:
        with self._lock:
            mine = [a for a in self._data["accounts"] if a.get("owner", "") == owner]
            active = self._data.get("active_account_id")
            ids = {a["id"] for a in mine}
            return {"accounts": [self._public(a) for a in mine],
                    "active_account_id": active if active in ids else None}

    def add_or_update(self, label: str, login: str, server: str, broker: str = "",
                      account_type: str = "demo", owner: str = "") -> Dict[str, Any]:
        with self._lock:
            for a in self._data["accounts"]:
                if (a.get("owner", "") == owner and a["login"] == str(login)
                        and a["server"].lower() == str(server).lower()):
                    a.update({"label": label, "broker": broker, "type": account_type})
                    self._save()
                    return self._public(a)
            a = {
                "id": uuid.uuid4().hex,
                "label": label or f"MT5 {login}",
                "login": str(login), "server": str(server), "broker": broker,
                "type": account_type, "status": "offline", "owner": owner,
                "last_error": "", "created_at": datetime.now(timezone.utc).isoformat(),
            }
            self._data["accounts"].append(a)
            self._save()
            return self._public(a)

    def get(self, account_id: str, owner: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """Return the raw profile.  When ``owner`` is given, an account that
        belongs to somebody else is reported as not found."""
        a = next((a for a in self._data["accounts"] if a["id"] == account_id), None)
        if a is not None and owner is not None and a.get("owner", "") != owner:
            return None
        return a

    def public(self, account_id: str, owner: Optional[str] = None) -> Optional[Dict[str, Any]]:
        a = self.get(account_id, owner)
        return self._public(a) if a else None

    # -- RAM-only credential vault -------------------------------------------
    def remember_password(self, account_id: str, password: str) -> None:
        with self._lock:
            self._vault[account_id] = password

    def password_for(self, account_id: str) -> Optional[str]:
        with self._lock:
            return self._vault.get(account_id)

    def forget_password(self, account_id: str) -> None:
        with self._lock:
            self._vault.pop(account_id, None)

    def active_id(self) -> Optional[str]:
        return self._data.get("active_account_id")

    def set_status(self, account_id: str, status: str, error: str = "") -> Dict[str, Any]:
        with self._lock:
            a = self.get(account_id)
            if not a:
                raise KeyError(account_id)
            if status == "connected":
                # one MT5 terminal = one login: everything else is now offline
                for other in self._data["accounts"]:
                    if other["id"] != account_id and other.get("status") == "connected":
                        other["status"] = "offline"
            a["status"] = status
            a["last_error"] = error
            self._data["active_account_id"] = account_id if status == "connected" else (
                None if self._data.get("active_account_id") == account_id else self._data.get("active_account_id"))
            self._save()
            return self._public(a)

    def set_active(self, account_id: str) -> Dict[str, Any]:
        with self._lock:
            a = self.get(account_id)
            if not a:
                raise KeyError(account_id)
            if a.get("status") != "connected":
                raise ValueError("account is not connected")
            self._data["active_account_id"] = account_id
            self._save()
            return self._public(a)

    def remove(self, account_id: str) -> None:
        with self._lock:
            self._vault.pop(account_id, None)
            self._data["accounts"] = [a for a in self._data["accounts"] if a["id"] != account_id]
            if self._data.get("active_account_id") == account_id:
                self._data["active_account_id"] = None
            self._save()
