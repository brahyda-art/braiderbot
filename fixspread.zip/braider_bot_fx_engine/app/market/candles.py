"""Candle primitives and indicator helpers (pure Python, no pandas needed)."""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Iterable, List, Sequence


@dataclass
class Candle:
    time: int          # bar open time, epoch seconds (UTC)
    open: float
    high: float
    low: float
    close: float
    volume: float = 0.0

    @property
    def body(self) -> float:
        return abs(self.close - self.open)

    @property
    def bull(self) -> bool:
        return self.close > self.open

    @property
    def bear(self) -> bool:
        return self.close < self.open

    @property
    def upper_wick(self) -> float:
        return self.high - max(self.open, self.close)

    @property
    def lower_wick(self) -> float:
        return min(self.open, self.close) - self.low

    @property
    def range(self) -> float:
        return self.high - self.low if self.high >= self.low else 0.0


def validate_candles(candles: Sequence[Candle], symbol: str = "?") -> List[Candle]:
    """Drop malformed bars and enforce ascending time order (data validation
    stage of the pipeline).  Returns the cleaned list; raises nothing."""
    cleaned: List[Candle] = []
    last_t = -1
    for c in candles or []:
        if c is None:
            continue
        if any(v is None for v in (c.open, c.high, c.low, c.close)):
            continue
        if not all(math.isfinite(float(v)) for v in (c.open, c.high, c.low, c.close)):
            continue
        if c.high < max(c.open, c.close) - 1e-12 or c.low > min(c.open, c.close) + 1e-12:
            continue
        if c.high < c.low:
            continue
        if c.time <= last_t:
            continue
        last_t = c.time
        cleaned.append(c)
    return cleaned


def atr(candles: Sequence[Candle], period: int = 14) -> float:
    """Average True Range (Wilder-smoothed). Returns ATR of the last bars."""
    if len(candles) < 2:
        return 0.0
    period = max(1, min(period, len(candles) - 1))
    trs: List[float] = []
    for i in range(1, len(candles)):
        c, p = candles[i], candles[i - 1]
        trs.append(max(c.high - c.low, abs(c.high - p.close), abs(c.low - p.close)))
    trs = trs[-(period * 3):]
    alpha = 1.0 / period
    val = sum(trs[:period]) / period
    for tr in trs[period:]:
        val = val * (1 - alpha) + tr * alpha
    return val


def highest(candles: Sequence[Candle], start: int, end: int) -> float:
    return max(c.high for c in candles[start:end])


def lowest(candles: Sequence[Candle], start: int, end: int) -> float:
    return min(c.low for c in candles[start:end])


def closes(candles: Iterable[Candle]) -> List[float]:
    return [c.close for c in candles]


def sma(values: Sequence[float], period: int) -> float:
    if not values:
        return 0.0
    period = min(period, len(values))
    return sum(values[-period:]) / period


def points_to_price(points: float, point_size: float) -> float:
    return points * point_size
