"""Market data feeds.

Two implementations of one interface:

* ``BridgeFeed``  - pulls OHLC from the MT5 bridge (real broker data).
* ``CsvFeed``     - reads historical CSVs from ``data/`` (offline / paper /
  backtest use). CSV columns: time,open,high,low,close,volume with time in
  epoch seconds or ISO.  Synthetic data for mechanics testing can be created
  with ``scripts/generate_demo_data.py`` and is clearly flagged as synthetic.

Every feed result passes through ``validate_candles`` and a freshness check:
if the newest bar is too old relative to the timeframe the engine treats the
data as stale and the cycle responds "DO NOT TRADE" for that symbol
(spec section 31).
"""

from __future__ import annotations

import csv
from abc import ABC, abstractmethod
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from ..constants import TIMEFRAME_MINUTES
from ..execution.broker_client import BrokerClient
from .candles import Candle, validate_candles
from .symbol_resolution import strip_to_known_base


class DataFeed(ABC):
    @abstractmethod
    def get_rates(self, symbol: str, timeframe: str, count: int) -> List[Candle]:
        ...

    def freshness_seconds(self, symbol: str, timeframe: str, candles: List[Candle]) -> Optional[float]:
        if not candles:
            return None
        now = datetime.now(timezone.utc).timestamp()
        tf = TIMEFRAME_MINUTES[timeframe] * 60
        return max(0.0, now - (candles[-1].time + tf))

    def is_fresh(self, symbol: str, timeframe: str, candles: List[Candle],
                 max_age_bars: int = 2) -> Tuple[bool, float]:
        age_bars = self.freshness_seconds(symbol, timeframe, candles)
        if age_bars is None:
            return False, float("inf")
        tf = TIMEFRAME_MINUTES[timeframe] * 60
        return age_bars <= max_age_bars * tf, age_bars


class BridgeFeed(DataFeed):
    """Live feed backed by the MT5 bridge (real broker data)."""

    def __init__(self, broker: BrokerClient):
        self.broker = broker

    def get_rates(self, symbol: str, timeframe: str, count: int) -> List[Candle]:
        raw = self.broker.rates(symbol, timeframe, count)
        candles = [
            Candle(time=int(r["time"]), open=float(r["open"]), high=float(r["high"]),
                   low=float(r["low"]), close=float(r["close"]), volume=float(r.get("volume", 0)))
            for r in raw
        ]
        return validate_candles(candles, symbol)


class CsvFeed(DataFeed):
    """Offline feed from data/<SYMBOL>_<TF>.csv files.

    Used for paper mode without a bridge and for backtesting.  Freshness is
    evaluated against the last bar in the file; ``CsvFeed`` therefore overrides
    ``is_fresh`` semantics via the constructor flag ``require_fresh``.
    """

    def __init__(self, data_dir: str | Path = "data", require_fresh: bool = False):
        self.data_dir = Path(data_dir)
        self.require_fresh = require_fresh
        self._cache: Dict[Tuple[str, str], List[Candle]] = {}

    def _path(self, symbol: str, timeframe: str) -> Path:
        return self.data_dir / f"{symbol.upper()}_{timeframe}.csv"

    def _resolve_path(self, symbol: str, timeframe: str) -> Path:
        """Find the CSV for ``symbol``+``timeframe``, whether ``symbol`` was
        given with a broker suffix (EURUSDm) or without one (EURUSD) - matches
        it against whatever base names actually exist on disk for this
        timeframe, so paper mode isn't tied to one particular symbol-mapping
        style."""
        exact = self._path(symbol, timeframe)
        if exact.exists():
            return exact
        suffix = f"_{timeframe}.csv"
        available_bases = [
            p.name[:-len(suffix)]
            for p in self.data_dir.glob(f"*{suffix}")
        ]
        resolved = strip_to_known_base(symbol, available_bases)
        if resolved:
            return self._path(resolved, timeframe)
        return exact

    def get_rates(self, symbol: str, timeframe: str, count: int) -> List[Candle]:
        path = self._resolve_path(symbol, timeframe)
        if not path.exists():
            return []
        key = (symbol.upper(), timeframe)
        candles = self._cache.get(key)
        if candles is None:
            candles = []
            with path.open(newline="", encoding="utf-8") as fh:
                for row in csv.DictReader(fh):
                    try:
                        t = row.get("time") or row.get("timestamp")
                        if t is None:
                            continue
                        t = str(t).strip()
                        if t.replace(".", "", 1).isdigit():
                            ts = float(t)
                            if ts > 1e12:      # milliseconds
                                ts /= 1000.0
                        else:
                            ts = datetime.fromisoformat(t.replace("Z", "+00:00")).timestamp()
                        candles.append(Candle(
                            time=int(ts),
                            open=float(row["open"]), high=float(row["high"]),
                            low=float(row["low"]), close=float(row["close"]),
                            volume=float(row.get("volume", 0) or 0),
                        ))
                    except (KeyError, ValueError, TypeError):
                        continue
            candles = validate_candles(candles, symbol)
            self._cache[key] = candles
        return candles[-count:] if count else candles

    def is_fresh(self, symbol: str, timeframe: str, candles: List[Candle],
                 max_age_bars: int = 2) -> Tuple[bool, float]:
        if not self.require_fresh:
            return True, 0.0
        return super().is_fresh(symbol, timeframe, candles, max_age_bars)


def resample(candles: List[Candle], src_tf: str, dst_tf: str) -> List[Candle]:
    """Resample lower-timeframe candles up to a higher timeframe."""
    if dst_tf not in TIMEFRAME_MINUTES or src_tf not in TIMEFRAME_MINUTES:
        raise ValueError("unknown timeframe")
    src_min, dst_min = TIMEFRAME_MINUTES[src_tf], TIMEFRAME_MINUTES[dst_tf]
    if dst_min % src_min != 0 or dst_min <= src_min:
        return candles
    factor = dst_min // src_min
    out: List[Candle] = []
    for i in range(0, len(candles), factor):
        chunk = candles[i:i + factor]
        if not chunk:
            continue
        out.append(Candle(
            time=chunk[0].time,
            open=chunk[0].open,
            high=max(c.high for c in chunk),
            low=min(c.low for c in chunk),
            close=chunk[-1].close,
            volume=sum(c.volume for c in chunk),
        ))
    return out
