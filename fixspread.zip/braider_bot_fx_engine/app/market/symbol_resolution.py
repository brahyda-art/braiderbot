"""Broker symbol resolution (spec section 4 follow-up: Exness suffixes).

Different brokers (and even different account types on the same broker,
e.g. Exness "m" / "zero" / "pro") list the same instrument under different
names: ``EURUSD`` vs ``EURUSDm`` vs ``EURUSD.a`` vs ``EURUSD-ECN``.

This module is pure logic (no MetaTrader5 import) so it can be unit tested
on any machine, including this Linux dev box. The MT5 bridge
(``mt5_bridge/bridge.py``) and the standalone diagnostic
(``scripts/check_mt5_symbols.py``) both call ``resolve_symbol_name`` against
the live list of symbol names returned by ``mt5.symbols_get()`` - neither
module guesses or hard-codes a broker suffix.
"""

from __future__ import annotations

from typing import Iterable, List, Optional, Sequence

# Suffix/prefix variants seen across brokers. Order matters only in that the
# exact match is always tried first; these are tried next, in this order.
KNOWN_SUFFIXES: Sequence[str] = (
    "m", "M",              # Exness "m" (micro/cent-style) accounts
    ".a", ".r", ".raw",    # common ECN/raw suffixes
    "-ECN", "_ECN",
    ".pro", ".e",
)


def strip_to_known_base(requested: str, available_bases: Iterable[str]) -> Optional[str]:
    """Match a broker-suffixed symbol (``EURUSDm``) back to a plain local base
    name (``EURUSD``) when there's no exact match.

    Used by ``CsvFeed`` (paper mode's offline sample data) so it keeps
    working whichever way round the symbol is configured - with a broker
    suffix or without one - without needing a second copy of the data files.
    """
    if not requested:
        return None
    bases = [b for b in available_bases if b]
    by_upper = {b.upper(): b for b in bases}
    upper = requested.upper()
    if upper in by_upper:
        return by_upper[upper]
    # requested is a base name plus something extra (EURUSDM = EURUSD + "M")
    matches = sorted(
        (b for b in bases if upper.startswith(b.upper())),
        key=len, reverse=True,
    )
    if matches:
        return matches[0]
    return None


def resolve_symbol_name(requested: str, available: Iterable[str]) -> Optional[str]:
    """Return the exact broker symbol name matching ``requested``.

    ``available`` is the list of symbol names as returned live by the broker
    (e.g. ``[s.name for s in mt5.symbols_get()]``). Matching is
    case-insensitive. Resolution order:

    1. Exact (case-insensitive) match.
    2. ``requested`` + a known broker suffix (``EURUSD`` -> ``EURUSDm``).
    3. Any available symbol that *starts with* ``requested`` (case
       insensitive), shortest name wins - catches broker-specific suffixes
       not in ``KNOWN_SUFFIXES`` (e.g. a gold symbol listed as
       ``XAUUSDmicro``) without ever substituting a different instrument
       (``GBPUSD`` will never match ``GBPJPY``).

    Returns ``None`` if nothing matches - callers must fail safe, never
    silently trade a different instrument.
    """
    if not requested:
        return None
    names: List[str] = [n for n in available if n]
    by_upper = {n.upper(): n for n in names}
    upper = requested.upper()

    if upper in by_upper:
        return by_upper[upper]

    for suffix in KNOWN_SUFFIXES:
        candidate = (upper + suffix.upper())
        if candidate in by_upper:
            return by_upper[candidate]

    starts_with = sorted(
        (n for n in names if n.upper().startswith(upper)),
        key=len,
    )
    if starts_with:
        return starts_with[0]

    return None
