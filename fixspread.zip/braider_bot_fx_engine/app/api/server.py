"""Secure backend API for the BRAIDER BOT FX engine (spec sections 22, 30).

Every request that can change state requires the ``X-API-Token`` header to
match ``API_TOKEN`` from the environment.  Without a configured token all
mutating endpoints refuse (fail-closed) and the refusal is written to the
SECURITY log.  A user can never send "BUY EURUSD" through this API - the only
trading path is the strategy pipeline; commands are limited to the bot state
machine and config sync.
"""

from __future__ import annotations

import hmac
import threading
import time
from typing import Any, Callable, Dict, List, Optional

from fastapi import Depends, FastAPI, Header, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from pydantic import BaseModel, SecretStr

from ..config import Config
from ..constants import COMMAND_ACTIONS
from ..state_store import StateStore, day_key, utc_now_ms
from ..services.account_manager import AccountManager
from pathlib import Path

_rate_lock = threading.Lock()
_rate_buckets: Dict[str, List[float]] = {}


class CommandBody(BaseModel):
    action: str
    payload: Optional[Dict[str, Any]] = None


class AccountConnectBody(BaseModel):
    """MT5 credentials.  ``password`` is a SecretStr so it never shows up in
    repr()/logs; it is used once to log in and then held only in RAM."""
    account_id: Optional[str] = None
    password: SecretStr
    login: Optional[str] = None
    server: Optional[str] = None
    broker: str = ""
    type: str = "Demo"


class AccountSelectBody(BaseModel):
    account_id: str


class AccountAddBody(BaseModel):
    label: str = ""
    login: str
    server: str
    broker: str = ""
    type: str = "demo"


class _RateLimiter:
    def __init__(self, per_minute: int):
        self.per_minute = per_minute

    def check(self, key: str) -> bool:
        now = time.time()
        with _rate_lock:
            bucket = [t for t in _rate_buckets.get(key, []) if now - t < 60.0]
            if len(bucket) >= self.per_minute:
                _rate_buckets[key] = bucket
                return False
            bucket.append(now)
            _rate_buckets[key] = bucket
            return True


def _with_win_rate(row: Dict[str, Any]) -> Dict[str, Any]:
    """Attach a computed win_rate (%) to a daily_stats row (spec: win/loss rate)."""
    row = dict(row)
    wins = row.get("wins") or 0
    losses = row.get("losses") or 0
    decided = wins + losses
    row["win_rate"] = round((wins / decided) * 100, 1) if decided else None
    return row


def create_app(cfg: Config, store: StateStore,
               get_engine: Callable[[], Any],
               account_manager: Optional[AccountManager] = None) -> FastAPI:
    app = FastAPI(title="BRAIDER BOT FX Engine API", version="1.0.0",
                  docs_url=None, redoc_url=None, openapi_url=None)
    import os
    allowed_origins = [x.strip() for x in os.environ.get("BBFX_ALLOWED_ORIGINS", "*").split(",") if x.strip()]
    app.add_middleware(
        CORSMiddleware,
        allow_origins=allowed_origins,
        allow_credentials=False,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    limiter = _RateLimiter(cfg.api.rate_limit_per_minute)

    def client_ip(request: Request) -> str:
        return request.client.host if request.client else "unknown"

    def rate_read(request: Request) -> None:
        if not limiter.check(f"{client_ip(request)}:read"):
            raise HTTPException(429, "rate limit exceeded")

    def _firebase_uid_from_request(request: Request) -> Optional[str]:
        """Verify a Firebase ID token when supplied by the website.

        Static API_TOKEN remains supported for trusted server-side callers.
        Browser account operations should use the Firebase user's ID token so
        the VPS can bind requests to the authenticated Firebase workspace.
        """
        authz = request.headers.get("Authorization", "")
        if not authz.lower().startswith("bearer "):
            return None
        token = authz.split(" ", 1)[1].strip()
        if not token:
            return None
        try:
            import firebase_admin
            from firebase_admin import auth as fb_auth
            try:
                firebase_admin.get_app()
            except ValueError:
                import os
                from firebase_admin import credentials
                cred_path = os.environ.get("FIREBASE_CREDENTIALS_PATH", "").strip()
                project = os.environ.get("FIREBASE_PROJECT_ID", "").strip()
                if not cred_path:
                    return None
                kwargs = {"projectId": project} if project else {}
                firebase_admin.initialize_app(credentials.Certificate(cred_path), kwargs)
            decoded = fb_auth.verify_id_token(token)
            return str(decoded.get("uid") or "")
        except Exception:
            return None

    def _resolve_owner(request: Request, x_api_token: Optional[str]) -> str:
        """Authenticate the caller and return the workspace owner id.

        1. Firebase ID token (browser) - uid must be the uid this engine serves.
        2. Static API_TOKEN (trusted server-side caller) - acts as that same owner.
        Everything else is refused (fail-closed).
        """
        import logging
        import os
        configured_uid = os.environ.get("FIREBASE_USER_UID", "").strip()
        firebase_uid = _firebase_uid_from_request(request)
        if firebase_uid:
            if configured_uid and firebase_uid == configured_uid:
                return firebase_uid
            logging.getLogger("security").warning(
                f"rejected Firebase user from {client_ip(request)} (not this engine's user)")
            raise HTTPException(403, "this engine is not linked to your account")
        expected = (getattr(cfg, "_api_token", None) or "").strip()
        if not expected:
            logging.getLogger("security").error("API call refused: API_TOKEN not configured")
            raise HTTPException(503, "API write access is not configured")
        if not x_api_token or not hmac.compare_digest(x_api_token, expected):
            logging.getLogger("security").warning(
                f"rejected API call from {client_ip(request)} (bad token)")
            raise HTTPException(401, "unauthorized")
        return configured_uid or "local"

    def require_write_token(request: Request,
                            x_api_token: Optional[str] = Header(default=None)) -> None:
        if not limiter.check(f"{client_ip(request)}:write"):
            raise HTTPException(429, "rate limit exceeded")
        _resolve_owner(request, x_api_token)

    def current_owner(request: Request,
                      x_api_token: Optional[str] = Header(default=None)) -> str:
        """Auth + rate limit for account endpoints; returns the owner id."""
        if not limiter.check(f"{client_ip(request)}:write"):
            raise HTTPException(429, "rate limit exceeded")
        return _resolve_owner(request, x_api_token)

    @app.exception_handler(RequestValidationError)
    async def _validation_error(_request: Request, exc: RequestValidationError):
        # Default FastAPI 422 bodies echo the submitted input - that would send
        # the MT5 password straight back to the browser.  Return fields only.
        fields = [".".join(str(x) for x in e.get("loc", ()) if x != "body") + ": " + str(e.get("msg", "invalid"))
                  for e in exc.errors()]
        return JSONResponse(status_code=422, content={"detail": "invalid request", "fields": fields})

    # ------------------------------------------------------------------
    @app.get("/health")
    def health(_: None = Depends(rate_read)) -> Dict[str, Any]:
        engine = get_engine()
        return {"ok": True, "service": "braider-engine",
                "state": engine.status_snapshot()}

    @app.get("/status")
    def status(_: None = Depends(rate_read)) -> Dict[str, Any]:
        return get_engine().status_snapshot()

    @app.get("/account")
    def account(_: None = Depends(rate_read)) -> Dict[str, Any]:
        engine = get_engine()
        snap = engine.status_snapshot()
        return {"connected": snap["connected"], "account": snap["account"]}

    @app.get("/positions")
    def positions(_: None = Depends(rate_read)) -> Dict[str, Any]:
        from ..execution.broker_client import BrokerError
        engine = get_engine()
        try:
            pos = engine.broker.positions()
            return {"positions": [p.__dict__ for p in pos]}
        except BrokerError as exc:
            raise HTTPException(503, f"broker unavailable: {exc}")

    @app.get("/orders")
    def orders(_: None = Depends(rate_read)) -> Dict[str, Any]:
        from ..execution.broker_client import BrokerError
        engine = get_engine()
        try:
            ords = engine.broker.pending_orders()
            return {"orders": [o.__dict__ for o in ords]}
        except BrokerError as exc:
            raise HTTPException(503, f"broker unavailable: {exc}")

    @app.get("/trades")
    def trades(limit: int = 100, _: None = Depends(rate_read)) -> Dict[str, Any]:
        rows = store.recent_trades(min(limit, 500))
        return {"trades": [t.to_web() for t in rows]}

    @app.get("/setups")
    def setups(limit: int = 100, _: None = Depends(rate_read)) -> Dict[str, Any]:
        rows = store.query("SELECT * FROM setups ORDER BY ts DESC LIMIT ?",
                           (min(limit, 500),))
        return {"setups": [dict(r) for r in rows]}

    @app.get("/logs")
    def logs(limit: int = 200, _: None = Depends(rate_read)) -> Dict[str, Any]:
        rows = store.query("SELECT * FROM events ORDER BY id DESC LIMIT ?",
                           (min(limit, 1000),))
        return {"logs": [dict(r) for r in rows]}

    # ---------------- MT5 accounts (DEMO only) ----------------------------
    def _mt5_is_real(mode: str) -> bool:
        m = str(mode or "").strip().lower()
        return m in ("real", "2", "live")

    def _engine_busy_reason() -> Optional[str]:
        """Switching the MT5 login while the bot runs, or while positions are
        open on the current account, would orphan those positions."""
        try:
            snap = get_engine().status_snapshot()
        except Exception:
            return None
        if snap.get("state") == "RUNNING":
            return "stop the bot before changing the MT5 account"
        if (snap.get("open_positions") or 0) or (snap.get("pending_orders") or 0):
            return "the current account still has open positions or pending orders"
        return None

    def _login_and_verify(a: Dict[str, Any], password: str) -> Dict[str, Any]:
        """Log the MT5 terminal into profile ``a`` and PROVE it landed on the
        right DEMO account.  Raises HTTPException on any mismatch."""
        broker = get_engine().broker
        if not hasattr(broker, "connect_account"):
            raise HTTPException(409, "account connection requires the MT5 bridge broker")
        try:
            broker.connect_account(a["login"], password, a["server"])
            info = broker.account()
        except Exception as exc:
            # str(exc) comes from the bridge; the password is never part of it.
            raise HTTPException(400, f"MT5 login failed: {exc}")
        if str(info.login) != str(a["login"]):
            _safe_disconnect(broker)
            raise HTTPException(409, "MT5 reported a different login than requested")
        if info.server and info.server.strip().lower() != str(a["server"]).strip().lower():
            _safe_disconnect(broker)
            raise HTTPException(409, "MT5 reported a different server than requested")
        if _mt5_is_real(info.mode):
            _safe_disconnect(broker)
            raise HTTPException(403, "this is a REAL account; only DEMO accounts are allowed")
        return {"currency": info.currency or "USD", "server": info.server or a["server"],
                "mode": str(info.mode)}

    def _safe_disconnect(broker: Any) -> None:
        try:
            if hasattr(broker, "disconnect_account"):
                broker.disconnect_account()
        except Exception:
            pass

    @app.get("/accounts")
    def accounts(owner: str = Depends(current_owner)) -> Dict[str, Any]:
        if account_manager is None:
            return {"accounts": [], "active_account_id": None}
        return account_manager.list_accounts(owner)

    @app.post("/accounts/connect")
    def accounts_connect_direct(body: AccountConnectBody,
                                owner: str = Depends(current_owner)) -> Dict[str, Any]:
        """One-step DEMO connect used by the website form."""
        if account_manager is None:
            raise HTTPException(503, "account manager unavailable")
        login = str(body.login or "").strip()
        server = str(body.server or "").strip()
        password = body.password.get_secret_value()
        if not login.isdigit() or not (5 <= len(login) <= 10):
            raise HTTPException(422, "login must be 5-10 digits")
        if not server or len(server) > 64:
            raise HTTPException(422, "server is required")
        if not password:
            raise HTTPException(422, "password is required")
        if str(body.type).lower() == "live":
            raise HTTPException(403, "LIVE account connection is disabled; use DEMO")
        prev_id = account_manager.active_id()
        profile = account_manager.add_or_update(
            label=f"{body.broker or 'MT5'} {login[:2]}••••{login[-3:]}",
            login=login, server=server, broker=body.broker,
            account_type="Demo", owner=owner)
        if prev_id and prev_id != profile["id"]:
            busy = _engine_busy_reason()
            if busy:
                raise HTTPException(409, busy)
        try:
            result = _login_and_verify(account_manager.get(profile["id"], owner), password)
        except HTTPException as exc:
            account_manager.set_status(profile["id"], "offline", str(exc.detail))
            raise
        account_manager.remember_password(profile["id"], password)
        pub = account_manager.set_status(profile["id"], "connected")
        return {
            "ok": True, "account_id": profile["id"], "connected": True,
            "currency": result["currency"], "type": "Demo",
            "masked": pub.get("masked"), "broker": body.broker,
            "server": result["server"], "mt5_mode": result["mode"],
        }

    @app.post("/accounts/select")
    def accounts_select(body: AccountSelectBody,
                        owner: str = Depends(current_owner)) -> Dict[str, Any]:
        """Make one saved account the live MT5 connection (re-logs the terminal)."""
        if account_manager is None:
            raise HTTPException(503, "account manager unavailable")
        a = account_manager.get(body.account_id, owner)
        if not a:
            raise HTTPException(404, "account not found")
        if account_manager.active_id() == a["id"] and a.get("status") == "connected":
            return {"ok": True, "account_id": a["id"], "connected": True, "switched": False}
        busy = _engine_busy_reason()
        if busy:
            raise HTTPException(409, busy)
        pw = account_manager.password_for(a["id"])
        if not pw:
            raise HTTPException(409, "password needed: re-enter it in Add account (it is never stored on disk)")
        try:
            result = _login_and_verify(a, pw)
        except HTTPException as exc:
            account_manager.set_status(a["id"], "offline", str(exc.detail))
            raise
        pub = account_manager.set_status(a["id"], "connected")
        return {"ok": True, "account_id": a["id"], "connected": True, "switched": True,
                "currency": result["currency"], "type": pub.get("type", "Demo"),
                "masked": pub.get("masked"), "server": result["server"]}

    @app.post("/accounts/{account_id}/disconnect")
    def accounts_disconnect(account_id: str, owner: str = Depends(current_owner)) -> Dict[str, Any]:
        """Stop using the account.  The broker account itself is untouched."""
        if account_manager is None:
            raise HTTPException(503, "account manager unavailable")
        a = account_manager.get(account_id, owner)
        if not a:
            raise HTTPException(404, "account not found")
        if account_manager.active_id() == a["id"]:
            busy = _engine_busy_reason()
            if busy:
                raise HTTPException(409, busy)
            broker = get_engine().broker
            if hasattr(broker, "disconnect_account"):
                try:
                    broker.disconnect_account()
                except Exception as exc:
                    raise HTTPException(409, f"bridge disconnect failed: {exc}")
        account_manager.forget_password(a["id"])
        pub = account_manager.set_status(a["id"], "offline")
        return {"ok": True, "account_id": a["id"], "connected": False, "account": pub,
                "message": "disconnected; the broker account was not changed"}

    @app.delete("/accounts/{account_id}")
    def accounts_delete(account_id: str, owner: str = Depends(current_owner)) -> Dict[str, Any]:
        """Remove the account from the workspace (never touches the broker)."""
        if account_manager is None:
            raise HTTPException(503, "account manager unavailable")
        a = account_manager.get(account_id, owner)
        if not a:
            raise HTTPException(404, "account not found")
        if account_manager.active_id() == a["id"]:
            busy = _engine_busy_reason()
            if busy:
                raise HTTPException(409, busy)
            _safe_disconnect(get_engine().broker)
        account_manager.remove(a["id"])
        return {"ok": True, "removed": a["id"], "message": "removed from workspace; the broker account was not changed"}

    @app.get("/config")
    def get_config(_: None = Depends(rate_read)) -> Dict[str, Any]:
        import dataclasses
        cfg = get_engine().cfg
        return dataclasses.asdict(cfg)

    @app.post("/config/sync")
    def config_sync(body: Dict[str, Any],
                    _: None = Depends(require_write_token)) -> Dict[str, Any]:
        engine = get_engine()
        applied = engine.handle_command("config_update", {"web": body})
        return applied

    @app.post("/command")
    def command(body: CommandBody,
                _: None = Depends(require_write_token)) -> Dict[str, Any]:
        if body.action not in COMMAND_ACTIONS:
            raise HTTPException(400, f"unsupported action: {body.action}")
        engine = get_engine()
        return engine.handle_command(body.action, body.payload or {})

    @app.get("/risk/today")
    def risk_today(_: None = Depends(rate_read)) -> Dict[str, Any]:
        day = day_key()
        return {"day": day, "stats": _with_win_rate(store.get_daily(day))}

    @app.get("/stats/daily")
    def stats_daily(days: int = 30, _: None = Depends(rate_read)) -> Dict[str, Any]:
        """Per-day trades/wins/losses/win_rate/realized_pnl (spec: record wins/losses
        and win rate for trades taken each day)."""
        rows = store.recent_daily(min(max(days, 1), 365))
        return {"days": [_with_win_rate(r) for r in rows]}

    @app.get("/stats/overall")
    def stats_overall(_: None = Depends(rate_read)) -> Dict[str, Any]:
        """All-time win rate across every closed trade, not just today - the
        frontend's overall win-rate figure should call this, not /risk/today."""
        return _with_win_rate(store.overall_stats())

    @app.get("/market/prices")
    def market_prices(_: None = Depends(rate_read)) -> Dict[str, Any]:
        """Live bid/ask/spread for every watched symbol (spec: update market data
        for the frontend). Per-symbol failures don't fail the whole response -
        each symbol reports its own error so one bad feed doesn't blank the page."""
        from ..execution.broker_client import BrokerError
        engine = get_engine()
        out: Dict[str, Any] = {}
        for canonical in engine.cfg.symbols.watched:
            broker_symbol = engine.cfg.symbols.mapping.get(canonical, canonical)
            try:
                tick = engine.broker.tick(broker_symbol)
                out[canonical] = {"ok": True, "symbol": broker_symbol, **tick}
            except BrokerError as exc:
                out[canonical] = {"ok": False, "symbol": broker_symbol, "error": str(exc)}
        return {"ts": utc_now_ms(), "prices": out}

    return app
