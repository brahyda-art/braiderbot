"""Structured logging with separate files per category (spec section 20).

Categories: engine (INFO/DEBUG/WARNING/ERROR -> engine.log), trades.log,
risk.log, security.log.  Secrets are never passed to log calls; as a defence
in depth measure ``_redact`` scrubs obvious credential key/value patterns.
"""

from __future__ import annotations

import logging
import logging.handlers
import re
import sys
from pathlib import Path

_REDACT_PATTERNS = [
    re.compile(r"(password|passwd|pwd|secret|token|api[_-]?key)\s*[=:]\s*\S+", re.IGNORECASE),
]


def _redact(message: str) -> str:
    for pattern in _REDACT_PATTERNS:
        message = pattern.sub(r"\1=***REDACTED***", message)
    return message


class RedactingFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:  # noqa: A003
        try:
            record.msg = _redact(str(record.msg))
            if record.args:
                record.args = tuple(
                    _redact(str(a)) if isinstance(a, str) else a for a in record.args
                )
        except Exception:
            pass
        return True


_category_loggers: dict[str, logging.Logger] = {}


def setup_logging(level: str = "INFO", log_dir: str = "logs",
                  max_file_mb: int = 20, backup_count: int = 10) -> None:
    root = Path(log_dir)
    root.mkdir(parents=True, exist_ok=True)

    fmt = logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    def _file_handler(name: str) -> logging.Handler:
        fh = logging.handlers.RotatingFileHandler(
            root / name, maxBytes=max_file_mb * 1024 * 1024,
            backupCount=backup_count, encoding="utf-8",
        )
        fh.setFormatter(fmt)
        fh.addFilter(RedactingFilter())
        return fh

    console = logging.StreamHandler(sys.stdout)
    console.setFormatter(fmt)
    console.addFilter(RedactingFilter())

    logging.basicConfig(level=getattr(logging, level.upper(), logging.INFO), handlers=[])

    for category, filename in (
        ("engine", "engine.log"),
        ("trade", "trades.log"),
        ("risk", "risk.log"),
        ("security", "security.log"),
    ):
        lg = logging.getLogger(category)
        lg.handlers = [_file_handler(filename), console]
        lg.propagate = False

    # Quiet noisy third-party loggers.
    for noisy in ("urllib3", "uvicorn.access", "firebase", "google"):
        logging.getLogger(noisy).setLevel(logging.WARNING)


def get(category: str = "engine") -> logging.Logger:
    """Return a category logger ('engine'|'trade'|'risk'|'security')."""
    if category not in _category_loggers:
        _category_loggers[category] = logging.getLogger(category if category != "engine" else "engine")
    return _category_loggers[category]
