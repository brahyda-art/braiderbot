"""Stop-loss validation (spec section 15).

A stop loss is valid only when ALL of these hold:

1. It exists (SL is MANDATORY - no configuration can disable this).
2. It is on the correct side of the entry (below entry for buys, above for
   sells).
3. It is at a *logical* location: beyond one of - the liquidity-sweep
   extreme, the protected swing, the zone boundary, or the measured pullback
   extreme.  A fixed-pip stop is only allowed when the mode explicitly
   enables it (``allow_fixed_pip_sl``) AND it still respects min/max limits.
4. Distance respects the configured min/max (points) and the broker
   stops_level.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence


@dataclass
class SLValidation:
    ok: bool
    reason: str = ""
    distance: float = 0.0


def validate_stop_loss(direction: str, entry: float, sl: float,
                       logical_levels: Sequence[float],
                       min_stop_price: float = 0.0,
                       max_stop_price: float = 0.0,
                       broker_min_distance: float = 0.0,
                       allow_fixed_pip_sl: bool = False) -> SLValidation:
    if sl is None or sl <= 0:
        return SLValidation(False, "stop loss missing (SL is mandatory)")
    if entry <= 0:
        return SLValidation(False, "entry price invalid")
    distance = abs(entry - sl)
    if direction == "buy":
        if sl >= entry:
            return SLValidation(False, "buy SL must be below entry", distance)
    elif direction == "sell":
        if sl <= entry:
            return SLValidation(False, "sell SL must be above entry", distance)
    else:
        return SLValidation(False, "unknown direction", distance)

    if min_stop_price > 0 and distance < min_stop_price:
        return SLValidation(False,
                            f"stop distance {distance} below minimum {min_stop_price}",
                            distance)
    if max_stop_price > 0 and distance > max_stop_price:
        return SLValidation(False,
                            f"stop distance {distance} above maximum {max_stop_price}",
                            distance)
    if broker_min_distance > 0 and distance < broker_min_distance:
        return SLValidation(False,
                            f"stop distance below broker stops_level {broker_min_distance}",
                            distance)

    if logical_levels and not allow_fixed_pip_sl:
        # The stop must sit BEYOND at least one structural anchor that lies
        # between the entry and the stop (zone edge, sweep extreme, swing).
        if direction == "buy":
            anchor_ok = any(level >= sl and level < entry
                            for level in logical_levels if level)
        else:
            anchor_ok = any(level <= sl and level > entry
                            for level in logical_levels if level)
        if not anchor_ok:
            return SLValidation(
                False,
                "SL is not beyond any structural anchor "
                f"(anchors={list(logical_levels)})", distance)

    return SLValidation(True, "ok", distance)
