"""Risk-based position sizing (spec section 16).

Formula (works for ANY instrument because it is driven by broker specs):

    risk_amount     = equity * risk_pct / 100
    loss_per_lot    = stop_distance_price / tick_size * tick_value
    lots_raw        = risk_amount / loss_per_lot
    lots            = normalize(lots_raw, volume_min, volume_max, volume_step)

EURUSD, XAUUSD and BTCUSD differ in tick size / tick value / contract size -
all of that arrives in ``SymbolSpec`` from the broker.  If any required spec
is missing, zero or inconsistent -> sizing REFUSES (returns 0 lots) and the
trade is rejected (spec: "if position sizing cannot be calculated reliably:
DO NOT TRADE").
"""

from __future__ import annotations

import math
from dataclasses import dataclass

#: The smallest lot the engine will ever produce or accept, whatever the
#: broker reports. A calculated 0.008 is never sent as 0.008: it is either
#: brought up to 0.01 (only when 0.01 still fits the configured risk ceiling)
#: or the trade is refused.
ABSOLUTE_MIN_LOT = 0.01


@dataclass
class SymbolSpec:
    symbol: str
    tick_size: float            # price increment of one tick
    tick_value: float           # account-currency value of one tick per 1.0 lot
    volume_min: float = 0.01
    volume_max: float = 100.0
    volume_step: float = 0.01
    contract_size: float = 100000.0
    point: float = 0.00001
    stops_level_points: float = 0.0   # broker min stop distance in points

    @property
    def value_per_price_unit_per_lot(self) -> float:
        """Account currency gained/lost per 1.0 lot for a 1.0 price move."""
        if not self.tick_size or not self.tick_value:
            return 0.0
        return self.tick_value / self.tick_size


def min_volume(spec: "SymbolSpec") -> float:
    """Effective minimum lot: the broker minimum, but never below 0.01."""
    try:
        broker_min = float(spec.volume_min)
    except (TypeError, ValueError):
        broker_min = ABSOLUTE_MIN_LOT
    if not math.isfinite(broker_min) or broker_min <= 0:
        broker_min = ABSOLUTE_MIN_LOT
    return max(broker_min, ABSOLUTE_MIN_LOT)


@dataclass
class SizingResult:
    ok: bool
    lots: float = 0.0
    risk_amount: float = 0.0
    loss_per_lot: float = 0.0
    actual_risk_amount: float = 0.0
    reason: str = ""


def normalize_volume(lots: float, spec: SymbolSpec) -> float:
    """Floor to the broker volume step and cap at volume_max.

    NOTE: this function itself never clamps UP to volume_min - a raw size
    below volume_min normalizes here to 0. The caller (compute_lot_size)
    decides what to do with that: it may use volume_min anyway, but only
    after explicitly verifying the ACTUAL monetary risk at volume_min still
    fits the user's configured risk ceiling. This function never makes that
    risk judgment itself.
    """
    if spec.volume_step <= 0:
        return lots
    steps = math.floor((lots + 1e-12) / spec.volume_step)
    vol = steps * spec.volume_step
    vol = min(spec.volume_max, vol)
    # Round to a sane number of decimals from the step.
    decimals = 0
    s = spec.volume_step
    while s < 1.0 and decimals < 8:
        s *= 10
        decimals += 1
    return round(vol, decimals)


def compute_lot_size(equity: float, risk_pct: float, entry: float, sl: float,
                     spec: SymbolSpec) -> SizingResult:
    res = SizingResult(ok=False)
    min_vol = min_volume(spec)
    if equity <= 0 or risk_pct <= 0 or risk_pct > 100:
        res.reason = f"invalid equity/risk (equity={equity}, risk={risk_pct}%)"
        return res
    if entry <= 0 or sl <= 0:
        res.reason = "invalid entry/sl price"
        return res
    stop_distance = abs(entry - sl)
    if stop_distance <= 0:
        res.reason = "stop distance is zero"
        return res
    vpu = spec.value_per_price_unit_per_lot
    if vpu <= 0:
        res.reason = "symbol tick_size/tick_value missing or zero"
        return res
    loss_per_lot = stop_distance * vpu
    if loss_per_lot <= 0 or not math.isfinite(loss_per_lot):
        res.reason = "loss-per-lot not computable"
        return res
    risk_amount = equity * risk_pct / 100.0
    lots_raw = risk_amount / loss_per_lot
    lots = normalize_volume(lots_raw, spec)
    if lots < min_vol:
        # The calculated size rounds below what the broker allows. Do NOT
        # silently refuse just because the raw number is small - the SL is
        # structurally correct and may simply be wide relative to a small
        # account. Check what the ACTUAL monetary risk would be if we used
        # the broker's own minimum volume at this exact (unmoved) stop:
        #
        #   actual_risk_at_min = volume_min * loss_per_lot
        #
        # If that actual risk still fits inside the user's configured risk
        # ceiling, the broker minimum is allowed - the user is not exposed
        # to more than they authorized. If even the broker minimum would
        # exceed the configured risk ceiling, refuse (fail-closed). Either
        # way the stop itself is never moved and the configured risk_pct is
        # never silently raised.
        actual_risk_at_min = min_vol * loss_per_lot
        if actual_risk_at_min <= risk_amount + 1e-9:
            res.ok = True
            res.lots = min_vol
            res.risk_amount = risk_amount
            res.loss_per_lot = loss_per_lot
            res.actual_risk_amount = actual_risk_at_min
            res.reason = (f"computed volume {lots_raw:.4f} below broker minimum "
                          f"{min_vol}; using broker minimum since its "
                          f"actual risk {actual_risk_at_min:.2f} is within the "
                          f"configured risk budget {risk_amount:.2f}")
            return res
        res.reason = (f"computed volume {lots_raw:.4f} below broker minimum "
                      f"{min_vol}, and broker-minimum risk "
                      f"{actual_risk_at_min:.2f} exceeds configured risk budget "
                      f"{risk_amount:.2f} ({risk_pct}% of {equity:.2f}) for stop "
                      f"{stop_distance}")
        res.risk_amount, res.loss_per_lot = risk_amount, loss_per_lot
        return res
    res.ok = True
    res.lots = lots
    res.risk_amount = risk_amount
    res.loss_per_lot = loss_per_lot
    res.actual_risk_amount = lots * loss_per_lot
    return res


def fixed_lot_size(requested_lots: float, spec: SymbolSpec) -> SizingResult:
    """Validate a user-selected fixed lot size against broker constraints.

    The value is floored to the broker step and is never silently raised to
    the broker minimum.  This prevents a configuration error from increasing
    exposure unexpectedly.
    """
    res = SizingResult(ok=False)
    min_vol = min_volume(spec)
    if requested_lots <= 0 or not math.isfinite(requested_lots):
        res.reason = "fixed lot size must be greater than zero"
        return res
    if requested_lots > spec.volume_max:
        res.reason = f"fixed lot size {requested_lots} exceeds broker maximum {spec.volume_max}"
        return res
    lots = normalize_volume(requested_lots, spec)
    if lots < min_vol:
        res.reason = f"fixed lot size {requested_lots} is below broker minimum {min_vol}"
        return res
    res.ok = True
    res.lots = lots
    return res


def raw_volume(equity: float, risk_pct: float, entry: float, sl: float,
               spec: SymbolSpec) -> float:
    """Un-normalized volume (used by tests and sanity tooling)."""
    stop_distance = abs(entry - sl)
    vpu = spec.value_per_price_unit_per_lot
    if stop_distance <= 0 or vpu <= 0 or equity <= 0:
        return 0.0
    return (equity * risk_pct / 100.0) / (stop_distance * vpu)


def sl_respects_broker_stops(entry: float, sl: float, spec: SymbolSpec,
                             side: str) -> bool:
    """True when the stop is far enough for the broker's stops_level."""
    if spec.stops_level_points <= 0 or not spec.point:
        return True
    min_dist = spec.stops_level_points * spec.point
    if side == "buy":
        return sl < entry - min_dist
    return sl > entry + min_dist
