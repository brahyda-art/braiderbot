"""Trade validation pipeline (spec section 18).

Every candidate setup travels through the exact stages advertised:

    DATA -> HTF CONTEXT -> ZONES -> SR/TRENDLINE -> LIQUIDITY ->
    CONFIRMATION -> ENTRY -> STOP LOSS -> POSITION SIZE -> RISK ->
    SPREAD -> EXPOSURE -> FINAL APPROVAL

The confluence engine has already merged the analysis stages into a scored
setup; this pipeline re-verifies the hard, non-negotiable stages (SL, sizing,
risk, spread, exposure) with FRESH live data and produces a final verdict.
The first failing stage rejects the trade and is journaled with its reason.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Dict

from ..config import Config
from ..constants import Direction
from ..risk.position_sizing import SymbolSpec, compute_lot_size, fixed_lot_size, sl_respects_broker_stops
from ..risk.risk_engine import RiskContext, RiskEngine
from ..risk.stop_loss import validate_stop_loss
from ..strategy.confluence import Setup

STAGES = [
    "data_validation", "htf_context", "structure", "supply_demand",
    "support_resistance", "trendline", "liquidity", "pullback_confirmation",
    "entry_validation", "stop_loss_validation", "position_size", "risk_check",
    "spread_check", "exposure_check", "final_approval",
]

# BTCUSD/XAUUSD point/tick specs differ too much from standard FX pairs for
# a raw point-count threshold to mean anything (e.g. a 1000-point BTCUSD
# spread can be cheaper than a 25-point EURUSD spread). These two symbols
# use a monetary (account-currency) cap instead; every other symbol keeps
# the existing point-based rule exactly as before. Must match the same
# constants in app/risk/risk_engine.py, which applies the identical rule
# inside pre_trade_check (both locations re-verify the same value).
MONEY_CAPPED_SYMBOLS = ("BTCUSD", "XAUUSD")
MAX_SPREAD_COST = 0.50   # USD - max acceptable monetary cost of the spread
MAX_SL_RISK = 2.00       # USD - max acceptable monetary risk on the technical SL


@dataclass
class PipelineResult:
    approved: bool
    stage: str
    reason: str
    lots: float = 0.0
    metrics: Dict = field(default_factory=dict)


class TradePipeline:
    def __init__(self, cfg: Config, risk_engine: RiskEngine,
                 get_symbol_spec: Callable[[str], SymbolSpec]):
        self.cfg = cfg
        self.risk = risk_engine
        self.get_spec = get_symbol_spec

    # ------------------------------------------------------------------
    def run(self, setup: Setup, ctx: RiskContext, spread_points: float,
            tick_size: float, spec: SymbolSpec) -> PipelineResult:
        risk_cfg = self.cfg.effective_risk()

        # -- entry validation -------------------------------------------------
        if setup.entry <= 0 or setup.direction is Direction.NONE:
            return PipelineResult(False, "entry_validation", "entry price invalid")

        # -- stop loss validation ----------------------------------------------
        point = spec.point or tick_size or 0.00001
        min_stop_price = risk_cfg.min_stop_points * point if risk_cfg.min_stop_points else 0.0
        max_stop_price = risk_cfg.max_stop_points * point if risk_cfg.max_stop_points else 0.0
        logical = []
        thesis = setup.thesis or {}
        z = thesis.get("zone") or {}
        if z:
            logical += [z.get("lower"), z.get("upper")]
        if thesis.get("invalidation_level"):
            logical.append(thesis["invalidation_level"])
        if thesis.get("sweep"):
            logical.append(thesis["sweep"].get("extreme"))
        logical = [float(v) for v in logical if v]

        sl_check = validate_stop_loss(
            setup.direction.value, setup.entry, setup.sl, logical,
            min_stop_price=min_stop_price, max_stop_price=max_stop_price,
            broker_min_distance=(spec.stops_level_points * point
                                 if spec.stops_level_points and point else 0.0),
        )
        if not sl_check.ok:
            return PipelineResult(False, "stop_loss_validation", sl_check.reason,
                                  metrics={"sl_distance": sl_check.distance})
        if not sl_respects_broker_stops(setup.entry, setup.sl, spec,
                                        setup.direction.value):
            return PipelineResult(False, "stop_loss_validation",
                                  "stop violates broker stops_level")

        # -- position size ---------------------------------------------------------
        equity = ctx.equity or 0.0
        mode = str(getattr(risk_cfg, "lot_sizing_mode", "risk_percent")).lower()
        if mode == "fixed_lot":
            requested_lots = float(getattr(risk_cfg, "fixed_lot_size", 0.01))
            sizing = fixed_lot_size(requested_lots, spec)
        elif mode == "per_symbol":
            table = getattr(risk_cfg, "fixed_lot_sizes", {}) or {}
            requested_lots = float(table.get(setup.symbol, getattr(risk_cfg, "fixed_lot_size", 0.01)))
            sizing = fixed_lot_size(requested_lots, spec)
        else:
            sizing = compute_lot_size(equity, risk_cfg.per_trade_risk_pct,
                                      setup.entry, setup.sl, spec)
        if not sizing.ok:
            return PipelineResult(False, "position_size", sizing.reason,
                                  metrics={"risk_amount": sizing.risk_amount, "lot_sizing_mode": mode})
        lots = sizing.lots

        # -- SL monetary risk cap (BTCUSD/XAUUSD only) -----------------------------
        # Money-based, not point-based - see MONEY_CAPPED_SYMBOLS above. This does
        # NOT move or recompute the technical SL from sl_check/setup.sl above; it
        # only measures that SL's monetary cost at the proposed (broker-normalized)
        # volume and rejects the setup if that cost is too large. Computed directly
        # from entry/sl/spec rather than sizing.actual_risk_amount, because that
        # field is only populated by the risk_percent sizing mode (compute_lot_size)
        # - fixed_lot/per_symbol modes leave it at 0.0, which would silently pass.
        spread_cost = None
        if setup.symbol in MONEY_CAPPED_SYMBOLS:
            vpu = spec.value_per_price_unit_per_lot
            if vpu <= 0:
                return PipelineResult(False, "position_size",
                                      f"{setup.symbol} rejected: cannot verify SL risk "
                                      f"(symbol tick_size/tick_value missing or zero)")
            sl_risk = abs(setup.entry - setup.sl) * vpu * lots
            if sl_risk > MAX_SL_RISK:
                return PipelineResult(False, "position_size",
                                      f"{setup.symbol} rejected: SL risk ${sl_risk:.2f} "
                                      f"> ${MAX_SL_RISK:.2f} maximum",
                                      metrics={"sl_risk_amount": round(sl_risk, 2)})
            if spread_points is not None:
                spread_cost = spread_points * point * vpu * lots

        # -- risk check ---------------------------------------------------------------
        risk_decision = self.risk.pre_trade_check(ctx, setup.symbol, lots, setup.id,
                                                   spread_cost=spread_cost)
        if not risk_decision.allowed:
            return PipelineResult(False, risk_decision.stage, risk_decision.reason,
                                  metrics=risk_decision.metrics)

        # -- spread ------------------------------------------------------------------
        if spread_points is None:
            return PipelineResult(False, "spread_check", "spread unavailable")
        if setup.symbol in MONEY_CAPPED_SYMBOLS:
            if spread_cost is None:
                return PipelineResult(False, "spread_check",
                                      f"{setup.symbol} spread cost unavailable")
            if spread_cost > MAX_SPREAD_COST:
                return PipelineResult(False, "spread_check",
                                      f"{setup.symbol} rejected at spread_check: spread "
                                      f"cost ${spread_cost:.2f} > ${MAX_SPREAD_COST:.2f} "
                                      f"maximum",
                                      metrics={"spread_cost": round(spread_cost, 4)})
        elif spread_points > risk_cfg.max_spread_points:
            return PipelineResult(False, "spread_check",
                                  f"spread {spread_points} > {risk_cfg.max_spread_points}")

        # -- final approval -------------------------------------------------------------
        metrics = {
            "risk_amount": round(sizing.risk_amount, 2),
            "actual_risk_amount": round(sizing.actual_risk_amount, 2),
            "loss_per_lot": sizing.loss_per_lot,
            "sl_distance": sl_check.distance,
            "score": setup.score,
            "spread_points": spread_points,
        }
        if spread_cost is not None:
            metrics["spread_cost"] = round(spread_cost, 4)
        return PipelineResult(True, "final_approval", "approved", lots=lots,
                              metrics=metrics)
