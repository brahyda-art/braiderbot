"""BRAIDER BOT FX engine entrypoint.

Boot order (spec sections 2, 25, 31):
    load config -> setup logging -> open SQLite -> build broker/feed ->
    VERIFY safety gates -> start API + Firebase sink -> engine loop.

SAFETY: execution mode 'live' is refused unless BOTH
    config execution.mode == live   AND   env LIVE_TRADING_ENABLED=true
    AND a reachable MT5 bridge is configured.  Default = paper.
"""

from __future__ import annotations

import logging
import os
import signal
import threading

from dotenv import load_dotenv

load_dotenv()

from .config import load_config
from .engine import Engine
from .execution.broker_client import BridgeBroker, BrokerClient, BrokerError
from .execution.paper_broker import PaperBroker
from .journal.journal import Journal
from .logging_config import setup_logging
from .market.data_feed import BridgeFeed, CsvFeed
from .services.firebase_sync import build_sink_from_env
from .services.account_manager import AccountManager
from .state_store import StateStore

PROJECT_ROOT = __import__("pathlib").Path(__file__).resolve().parent.parent


def build_broker(cfg) -> BrokerClient:
    mode = cfg.execution.mode
    if mode == "paper":
        feed = CsvFeed(PROJECT_ROOT / "data", require_fresh=False)
        return PaperBroker(
            feed, cfg.execution.paper_spread_points,
            start_balance=cfg.execution.paper_balance,
        )
    token = os.environ.get("BRIDGE_TOKEN", "").strip()
    if not token:
        raise SystemExit(
            "execution.mode=%s requires BRIDGE_TOKEN in the environment "
            "(see .env.example). Refusing to start." % mode)
    return BridgeBroker(cfg.execution.bridge_url, token,
                        cfg.execution.bridge_timeout_seconds)


def verify_safety_gates(cfg, broker: BrokerClient, journal: Journal) -> None:
    """Demo/live starts must pass explicit, auditable gates."""
    if cfg.execution.mode == "live":
        if os.environ.get("LIVE_TRADING_ENABLED", "").lower() != "true":
            journal.log_security("ERROR",
                                 "LIVE mode requested but LIVE_TRADING_ENABLED != true "
                                 "- refusing to start (demo-first policy)")
            raise SystemExit(
                "Live trading blocked: set LIVE_TRADING_ENABLED=true explicitly "
                "after your demo period. Default is safe.")
        journal.log_security("WARNING",
                             "LIVE TRADING ENABLED - real money at risk", {})
    if cfg.execution.mode in ("demo", "live"):
        try:
            health = broker.health()
        except BrokerError as exc:
            journal.log_security("ERROR", f"bridge health check failed: {exc}", {})
            raise SystemExit(f"MT5 bridge not reachable at {cfg.execution.bridge_url}: {exc}")
        journal.log_event("engine", "INFO",
                          f"bridge healthy: {health}")


def main() -> None:
    cfg = load_config(os.environ.get("BBFX_CONFIG"))
    setup_logging(cfg.logging.level, cfg.logging.dir,
                  cfg.logging.max_file_mb, cfg.logging.backup_count)
    log = logging.getLogger("engine")

    store = StateStore(PROJECT_ROOT / "data" / "braider.db")
    journal = Journal(store)

    sink = build_sink_from_env()
    journal.firebase = sink

    # API token is passed through to the API via cfg attribute (not stored).
    cfg._api_token = os.environ.get("API_TOKEN", "")

    try:
        broker = build_broker(cfg)
    except SystemExit:
        raise
    except Exception as exc:
        log.error(f"broker init failed: {exc}")
        return

    verify_safety_gates(cfg, broker, journal)

    feed = broker.feed if isinstance(broker, PaperBroker) else BridgeFeed(broker)
    engine = Engine(cfg, broker, feed, store, journal, web_sink=sink)

    # --- API server (threaded) ---------------------------------------------
    stop_event = threading.Event()
    if cfg.api.enabled:
        from .api.server import create_app
        import uvicorn
        account_manager = AccountManager(PROJECT_ROOT / "data" / "accounts.json")
        app = create_app(cfg, store, get_engine=lambda: engine, account_manager=account_manager)
        uv_cfg = uvicorn.Config(app, host=cfg.api.host, port=cfg.api.port,
                                log_level="warning", access_log=False)
        server = uvicorn.Server(uv_cfg)
        api_thread = threading.Thread(target=server.run, daemon=True,
                                      name="bbfx-api")
        api_thread.start()
        log.info(f"API listening on {cfg.api.host}:{cfg.api.port}")

    sink.start(engine)

    # --- graceful shutdown -----------------------------------------------------
    def _shutdown(signum, _frame):
        log.info(f"signal {signum} received - shutting down")
        stop_event.set()
        sink.stop()

    signal.signal(signal.SIGTERM, _shutdown)
    signal.signal(signal.SIGINT, _shutdown)

    log.info(f"BRAIDER BOT FX engine ready | mode={cfg.execution.mode} "
             f"symbols={cfg.symbols.watched}")
    engine.run_forever(stop_event)
    store.close()
    log.info("engine stopped cleanly")


if __name__ == "__main__":
    main()
