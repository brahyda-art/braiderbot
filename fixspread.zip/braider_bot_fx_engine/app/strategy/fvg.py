"""Fair Value Gap (imbalance) detection.

A Fair Value Gap is a 3-candle displacement pattern: the middle candle moves
so decisively that candle[i-1] and candle[i+1] don't overlap, leaving a gap
in price that the market printed through without trading. This is treated
as an *area of imbalance* the market is statistically likely to revisit.

Definition (objective, no discretion):

* Bullish FVG at index i: candles[i-1].high < candles[i+1].low.
  Gap zone = [candles[i-1].high, candles[i+1].low].
* Bearish FVG at index i: candles[i-1].low > candles[i+1].high.
  Gap zone = [candles[i+1].high, candles[i-1].low].

Quality filters (both configurable, both required - a gap failing either is
not returned at all, it's noise, not a real FVG for this system):

* ``min_displacement_body_ratio`` - candle[i]'s body must be at least this
  fraction of its own range. A gap punched by a doji/small-body candle isn't
  real displacement.
* ``min_gap_atr_mult`` - the gap height must be at least this multiple of
  ATR. Filters out the many tiny, meaningless gaps M1 noise produces.

Lifecycle, mirroring the zone module's vocabulary so the confluence engine
can treat FVGs consistently with zones:

* FRESH     - price has not traded back into the gap since it formed.
* TESTED    - price traded into the gap but did not close through the far
              edge (partial fill).
* FILLED    - a candle body closed through the far edge - the imbalance is
              considered resolved and is no longer tradeable confluence.

Fresh/tested FVGs are active; filled ones are dropped from the active set,
same convention as zones.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence

from ..market.candles import Candle


@dataclass
class FVG:
    kind: str                       # "bullish" | "bearish"
    upper: float
    lower: float
    displacement_index: int         # index of candle[i], the displacement bar
    displacement_time: int
    displacement_body_ratio: float
    size_atr: float                 # gap height / ATR at creation
    status: str = "fresh"           # fresh | tested | filled
    fill_index: Optional[int] = None

    @property
    def height(self) -> float:
        return self.upper - self.lower

    def contains(self, price: float, buffer: float = 0.0) -> bool:
        return (self.lower - buffer) <= price <= (self.upper + buffer)

    def to_dict(self) -> Dict:
        return {
            "kind": self.kind, "upper": self.upper, "lower": self.lower,
            "displacement_time": self.displacement_time,
            "size_atr": round(self.size_atr, 3), "status": self.status,
            "body_ratio": round(self.displacement_body_ratio, 3),
        }


@dataclass
class FVGAnalysis:
    gaps: List[FVG]

    def active(self, kind: Optional[str] = None) -> List[FVG]:
        return [g for g in self.gaps
                if g.status in ("fresh", "tested") and (kind is None or g.kind == kind)]

    def nearest_active(self, price: float, kind: str,
                       max_distance: Optional[float] = None) -> Optional[FVG]:
        best, best_d = None, float("inf")
        for g in self.active(kind):
            if g.contains(price):
                return g
            d = min(abs(price - g.lower), abs(price - g.upper))
            if d < best_d and (max_distance is None or d <= max_distance):
                best, best_d = g, d
        return best


def detect_fvgs(candles: Sequence[Candle], atr_value: float,
                min_gap_atr_mult: float = 0.15,
                min_displacement_body_ratio: float = 0.5,
                max_age_bars: int = 150) -> List[FVG]:
    """Scan for 3-candle FVGs and build their fill lifecycle by walking
    forward through the remaining candles - same walk-forward convention
    ``zones/detector.py`` uses, so the two modules behave predictably
    together for anyone reading both."""
    n = len(candles)
    if n < 5 or atr_value <= 0:
        return []

    gaps: List[FVG] = []
    for i in range(1, n - 1):
        prev, disp, nxt = candles[i - 1], candles[i], candles[i + 1]
        disp_range = disp.range or 1e-12
        body_ratio = disp.body / disp_range

        kind = None
        upper = lower = 0.0
        if prev.high < nxt.low:
            kind, upper, lower = "bullish", nxt.low, prev.high
        elif prev.low > nxt.high:
            kind, upper, lower = "bearish", prev.low, nxt.high
        if kind is None:
            continue

        size = upper - lower
        if size < min_gap_atr_mult * atr_value:
            continue
        if body_ratio < min_displacement_body_ratio:
            continue

        gap = FVG(
            kind=kind, upper=round(upper, 8), lower=round(lower, 8),
            displacement_index=i, displacement_time=disp.time,
            displacement_body_ratio=round(body_ratio, 4),
            size_atr=size / atr_value,
        )

        # Walk forward: tested (partial trade-in) vs filled (body closes
        # through the far edge - the edge furthest from where price came
        # from before the gap formed).
        for j in range(i + 2, n):
            c = candles[j]
            in_gap = c.low <= gap.upper and c.high >= gap.lower
            if in_gap and gap.status == "fresh":
                gap.status = "tested"
            if gap.kind == "bullish":
                filled = c.close < gap.lower
            else:
                filled = c.close > gap.upper
            if filled:
                gap.status = "filled"
                gap.fill_index = j
                break

        if n - 1 - i > max_age_bars:
            continue
        gaps.append(gap)

    return gaps


def analyze_fvgs(candles: Sequence[Candle], atr_value: float, cfg) -> FVGAnalysis:
    """cfg: app.config.StrategyConfig (reads fvg_* fields)."""
    gaps = detect_fvgs(
        candles, atr_value,
        min_gap_atr_mult=getattr(cfg, "fvg_min_gap_atr_mult", 0.15),
        min_displacement_body_ratio=getattr(cfg, "fvg_min_displacement_body_ratio", 0.5),
        max_age_bars=getattr(cfg, "fvg_max_age_bars", 150),
    )
    return FVGAnalysis(gaps=gaps)
