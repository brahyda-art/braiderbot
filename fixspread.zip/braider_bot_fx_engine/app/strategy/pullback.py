"""Pullback and confirmation-candle detection (spec sections 12, 13).

Pullback (objective): after an impulse in the setup direction, price retraces
between ``min_retracement`` and ``max_retracement`` of the impulse leg and
trades back into a zone/level area.

Confirmation candles (any enabled pattern, measured on the *closed*
confirmation timeframe):

* ``engulfing``       - bullish/bearish engulfing of the previous candle.
* ``pin_bar``         - rejection wick >= 2x body, close in the correct third.
* ``momentum_close``  - close beyond the previous candle's extreme in the
  setup direction with body >= 60% of range.
* ``mss``             - a confirmed CHoCH/MSS structure event on the entry
  timeframe (handled by the structure module, surfaced here).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional, Sequence

from ..constants import Direction
from ..market.candles import Candle


@dataclass
class PullbackResult:
    is_pullback: bool = False
    retracement: float = 0.0        # fraction of impulse leg
    impulse_start: Optional[float] = None
    impulse_end: Optional[float] = None
    pullback_extreme: Optional[float] = None


@dataclass
class ConfirmationResult:
    confirmed: bool = False
    patterns: List[str] = None      # type: ignore[assignment]

    def __post_init__(self):
        if self.patterns is None:
            self.patterns = []


def measure_pullback(candles: Sequence[Candle], direction: Direction,
                     lookback: int = 30, min_ret: float = 0.236,
                     max_ret: float = 0.85) -> PullbackResult:
    """Measure whether the recent window shows a valid pullback of the
    dominant impulse leg (impulse leg = extreme-to-extreme move)."""
    res = PullbackResult()
    window = candles[-lookback:] if candles and len(candles) >= 5 else []
    if not window:
        return res
    if direction is Direction.LONG:
        impulse_start = min(w.low for w in window[:-1])
        impulse_end = max(w.high for w in window[:-1])
        leg = impulse_end - impulse_start
        if leg <= 0:
            return res
        extreme = window[-1].low
        ret = (impulse_end - extreme) / leg
    else:
        impulse_start = max(w.high for w in window[:-1])
        impulse_end = min(w.low for w in window[:-1])
        leg = impulse_start - impulse_end
        if leg <= 0:
            return res
        extreme = window[-1].high
        ret = (extreme - impulse_end) / leg
    res.retracement = round(ret, 4)
    res.impulse_start, res.impulse_end, res.pullback_extreme = impulse_start, impulse_end, extreme
    res.is_pullback = min_ret <= ret <= max_ret
    return res


def detect_confirmation(candles: Sequence[Candle], direction: Direction,
                        patterns: Sequence[str]) -> ConfirmationResult:
    """Evaluate the last CLOSED candle(s) for confirmation patterns."""
    res = ConfirmationResult()
    if len(candles) < 3:
        return res
    c = candles[-1]
    p = candles[-2]

    if direction is Direction.LONG:
        if "engulfing" in patterns and c.bull and c.close > p.high and c.open <= p.close:
            res.patterns.append("engulfing")
        body = c.body or 1e-12
        if "pin_bar" in patterns and c.bull and \
                c.lower_wick >= 2.0 * body and \
                c.close >= c.low + 0.66 * c.range:
            res.patterns.append("pin_bar")
        if "momentum_close" in patterns and c.bull and \
                c.close > p.high and c.body >= 0.6 * c.range:
            res.patterns.append("momentum_close")
    else:
        if "engulfing" in patterns and c.bear and c.close < p.low and c.open >= p.close:
            res.patterns.append("engulfing")
        body = c.body or 1e-12
        if "pin_bar" in patterns and c.bear and \
                c.upper_wick >= 2.0 * body and \
                c.close <= c.high - 0.66 * c.range:
            res.patterns.append("pin_bar")
        if "momentum_close" in patterns and c.bear and \
                c.close < p.low and c.body >= 0.6 * c.range:
            res.patterns.append("momentum_close")

    res.confirmed = len(res.patterns) > 0
    return res
