"""Support / Resistance levels and previous-day levels.

Levels are built from swing-point clusters (objective rule): swings of the
same kind within ``cluster_tolerance_atr`` x ATR of each other form a level;
levels need ``min_touches`` distinct swing touches.  Confidence is graded by
touch count, recency and number of distinct sessions touched.  Levels are
context/confirmation only - they never trigger trades by themselves
(spec section 8).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence

from ..market.candles import Candle, atr
from .swings import Swing

SECONDS_PER_DAY = 86_400


@dataclass
class Level:
    price: float
    kind: str                       # support | resistance
    touches: int
    first_time: int
    last_time: int
    confidence: float               # 0..1
    source: str = "swing_cluster"   # swing_cluster | prev_day


@dataclass
class SRAnalysis:
    levels: List[Level] = field(default_factory=list)
    prev_day: Dict[str, Optional[float]] = field(default_factory=dict)


def cluster_levels(candles: Sequence[Candle], swings: List[Swing],
                   atr_value: float, tolerance_atr: float = 0.35,
                   min_touches: int = 2, max_levels: int = 12,
                   last_price: float | None = None) -> List[Level]:
    if not swings or len(candles) == 0:
        return []
    tol = max(tolerance_atr * atr_value, 1e-9)
    sorted_swings = sorted(swings, key=lambda s: s.price)
    clusters: List[List[Swing]] = []
    for s in sorted_swings:
        if clusters and abs(s.price - clusters[-1][-1].price) <= tol:
            clusters[-1].append(s)
        else:
            clusters.append([s])

    levels: List[Level] = []
    for cluster in clusters:
        highs = sum(1 for s in cluster if s.kind == "high")
        lows = sum(1 for s in cluster if s.kind == "low")
        touches = len(cluster)
        if touches < min_touches:
            continue
        price = sum(s.price for s in cluster) / touches
        kind = "resistance" if highs >= lows else "support"
        if last_price is not None:
            kind = "resistance" if price > last_price else "support"
        span_days = max(1, (cluster[-1].time - cluster[0].time) // SECONDS_PER_DAY + 1)
        recency = cluster[-1].index / max(1, len(candles))
        confidence = min(1.0, 0.25 * touches + 0.15 * span_days + 0.15 * recency)
        levels.append(Level(
            price=round(price, 6), kind=kind, touches=touches,
            first_time=cluster[0].time, last_time=cluster[-1].time,
            confidence=round(confidence, 3),
        ))
    levels.sort(key=lambda l: abs(l.price - (last_price if last_price else l.price)))
    return levels[:max_levels]


def previous_day_levels(d1_candles: Sequence[Candle]) -> Dict[str, Optional[float]]:
    """PDH / PDL / PDO / PDC from the most recent *completed* D1 candle."""
    if not d1_candles:
        return {"high": None, "low": None, "open": None, "close": None}
    prev = d1_candles[-1]
    return {
        "high": prev.high, "low": prev.low,
        "open": prev.open, "close": prev.close,
    }


def analyze_sr(candles: Sequence[Candle], swings: List[Swing],
               d1_candles: Sequence[Candle] = (), atr_period: int = 14,
               tolerance_atr: float = 0.35, min_touches: int = 2) -> SRAnalysis:
    res = SRAnalysis()
    if not candles:
        return res
    res.levels = cluster_levels(
        candles, swings, atr(candles, atr_period), tolerance_atr, min_touches,
        last_price=candles[-1].close,
    )
    res.prev_day = previous_day_levels(d1_candles)
    return res
