"""SMC-pullback scalping (separate from the swing confluence engine).

This is a DISTINCT method from ``confluence.build_setups`` - it is used only
when Scalping mode is enabled, and it never mixes with the swing-trading
concepts (Supply & Demand zones, Support & Resistance levels, FVGs, general
liquidity-sweep scoring). When scalping is on, this module is the only
source of setups for that symbol; when it is off, this module is never
called. Nothing here reads ``StrategyConfig.enabled_concepts`` - that switch
governs the swing engine only.

Method (Smart Money Concepts, scalping variant - see spec references below):

1.  A market structure shift (MSS) or confirmed CHoCH must have JUST fired
    on the scalping entry timeframe. This is smart money "flipping the
    script" - the reason to be interested in a pullback at all.
2.  Wait for price to retrace back toward the ORIGIN of the impulse that
    caused the shift - the zone institutional orders are still resting in.
    The retracement must fall inside the OTE band (62%-79% of the impulse
    leg, i.e. the golden-ratio pullback zone), not just "any pullback".
3.  Place a RESTING LIMIT ORDER at the OTE level (buy_limit below current
    price for longs, sell_limit above for shorts) rather than chasing price
    with a market order. This is what makes it "scalping through limit
    orders" - the fill happens automatically if/when price returns to the
    zone, without a market-price entry that erodes the tight stop.
4.  Stop-loss sits just beyond the structural invalidation point (the swing
    that, if broken, means the MSS was false) - never a fixed pip value.
5.  Quick, fixed reward:risk exit (ScalpingConfig.tp_rr) - scalping targets
    a fast, modest multiple of risk, not a swing-length target.

The order is never sent from here - build_scalp_setups() only returns Setup
objects with order_type set to buy_limit/sell_limit and a computed limit
price; sizing, gating and actual order placement stay in pipeline.py /
executor.py exactly as for swing setups, so every existing safety check
(mandatory SL, risk ceiling, broker minimum handling, duplicate guard)
applies identically to scalping trades.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from typing import List, Optional, Sequence

from ..constants import Direction, SetupKind, StructureEventKind
from ..market.candles import Candle
from ..strategy import pullback as pb
from ..strategy.confluence import Setup, _rr, _sl_for_long, _sl_for_short
from ..strategy.structure import StructureAnalysis, StructureEvent

# OTE (optimal trade entry) band: the 62%-79% retracement of the impulse
# leg, the classic SMC "golden zone" for a pullback entry at the origin.
OTE_MIN_RETRACEMENT = 0.62
OTE_MAX_RETRACEMENT = 0.79

#: How many bars back an MSS/CHoCH may have fired and still count as "the
#: reason" for the current pullback. Too old and the setup is stale.
STRUCTURE_EVENT_MAX_AGE_BARS = 10


@dataclass
class ScalpCandidate:
    """Intermediate result before Setup construction - kept small and
    inspectable so tests can assert on the OTE math without constructing a
    full Setup each time."""
    direction: Direction
    structure_event: StructureEvent
    impulse_start: float
    impulse_end: float
    retracement: float
    ote_price: float          # the exact limit price: origin-zone retracement level
    protective_level: float   # beyond this = MSS was false, SL anchors here


def _find_recent_shift(structure: StructureAnalysis, direction: Direction,
                       total_bars: int) -> Optional[StructureEvent]:
    """Most recent MSS (or confirmed CHoCH) in `direction`, still within the
    freshness window. A plain BOS never qualifies - scalping needs an actual
    change of character, not mere trend continuation, because the whole
    method depends on smart money having just reversed intent."""
    for ev in reversed(structure.events):
        if ev.direction is not direction:
            continue
        if ev.kind not in (StructureEventKind.MSS, StructureEventKind.CHOCH):
            continue
        if ev.index < total_bars - STRUCTURE_EVENT_MAX_AGE_BARS:
            return None  # events are time-ordered; nothing newer qualifies either
        return ev
    return None


def _ote_level(impulse_start: float, impulse_end: float, direction: Direction,
              retracement: float) -> float:
    """Price at a given retracement fraction back into the impulse leg."""
    leg = impulse_end - impulse_start
    if direction is Direction.LONG:
        return impulse_end - retracement * leg
    return impulse_end + retracement * leg


def find_scalp_candidate(candles: Sequence[Candle], direction: Direction,
                         structure: StructureAnalysis) -> Optional[ScalpCandidate]:
    """Core detection: recent MSS/CHoCH + current pullback sitting inside
    the OTE band of that same impulse leg. Returns None the instant any
    required piece is missing - never guesses a substitute level."""
    if len(candles) < 15:
        return None
    event = _find_recent_shift(structure, direction, len(candles))
    if event is None:
        return None

    pull = pb.measure_pullback(candles, direction,
                               min_ret=OTE_MIN_RETRACEMENT,
                               max_ret=OTE_MAX_RETRACEMENT)
    if not pull.is_pullback or pull.impulse_start is None or pull.impulse_end is None:
        return None

    ote_price = _ote_level(pull.impulse_start, pull.impulse_end, direction,
                           pull.retracement)

    # Structural invalidation: the swing that, if traded through, proves the
    # MSS was false. For a long this is the low the impulse departed from
    # (or the structure's protected low, whichever is deeper/safer); for a
    # short, the mirrored high.
    if direction is Direction.LONG:
        protective = min(pull.impulse_start,
                         structure.protected_low or pull.impulse_start)
    else:
        protective = max(pull.impulse_start,
                         structure.protected_high or pull.impulse_start)

    return ScalpCandidate(
        direction=direction, structure_event=event,
        impulse_start=pull.impulse_start, impulse_end=pull.impulse_end,
        retracement=pull.retracement, ote_price=ote_price,
        protective_level=protective,
    )


def build_scalp_setups(candles: Sequence[Candle], symbol: str, entry_tf: str,
                       structure: StructureAnalysis, atr_value: float,
                       scalp_cfg) -> List[Setup]:
    """Scan both directions for an SMC-pullback scalp setup. Mirrors
    confluence.build_setups()'s contract (gates_failed populated on
    candidates so the journal always records why nothing traded) but never
    touches zones/SR/FVG/general sweep scoring - a completely separate
    method, per user requirement that scalping never blends with the swing
    strategies."""
    setups: List[Setup] = []
    if atr_value <= 0 or len(candles) < 15:
        return setups
    last = candles[-1]
    buffer = getattr(scalp_cfg, "sl_buffer_atr", 0.15) * atr_value

    for direction in (Direction.LONG, Direction.SHORT):
        gates_failed: List[str] = []
        reasons: List[str] = []
        candidate = find_scalp_candidate(candles, direction, structure)
        if candidate is None:
            gates_failed.append("no_recent_structure_shift_or_ote_pullback")
            setup = Setup(
                id=f"su-{uuid.uuid4().hex[:12]}", symbol=symbol, direction=direction,
                kind=SetupKind.SCALP_CONFIRMATION, score=0.0, entry=last.close,
                sl=0.0, tp=0.0, order_type="none", entry_tf=entry_tf,
                gates_failed=gates_failed,
                thesis={"method": "smc_scalp_pullback"},
            )
            setups.append(setup)
            continue

        reasons.append(f"structure_shift:{candidate.structure_event.kind.value}")
        reasons.append(f"ote_pullback:{int(candidate.retracement * 100)}%")

        entry = round(candidate.ote_price, 8)
        if direction is Direction.LONG:
            sl_valid = candidate.protective_level < entry
            sl = _sl_for_long(candidate.protective_level, candidate.protective_level,
                              buffer) if sl_valid else 0.0
            order_type = "buy_limit" if entry < last.close else "market"
        else:
            sl_valid = candidate.protective_level > entry
            sl = _sl_for_short(candidate.protective_level, candidate.protective_level,
                               buffer) if sl_valid else 0.0
            order_type = "sell_limit" if entry > last.close else "market"

        if not sl_valid:
            gates_failed.append("no_valid_sl_location")

        tp = 0.0
        rr = 0.0
        if sl_valid:
            risk = abs(entry - sl)
            tp_rr = getattr(scalp_cfg, "tp_rr", 1.5)
            tp = entry + tp_rr * risk if direction is Direction.LONG else entry - tp_rr * risk
            rr = _rr(entry, sl, tp, direction)
            if rr <= 0:
                gates_failed.append("invalid_rr_calculation")

        # Scalping has its own (typically lower) confluence bar: structure
        # shift + a clean OTE pullback IS the setup - there is no additional
        # weighted score to accumulate the way the swing engine does, since
        # zone/SR/FVG/general-sweep evidence is deliberately excluded here.
        score = getattr(scalp_cfg, "min_confluence_score", 5.0) if not gates_failed else 0.0

        setup = Setup(
            id=f"su-{uuid.uuid4().hex[:12]}", symbol=symbol, direction=direction,
            kind=SetupKind.SCALP_CONFIRMATION, score=score, entry=entry,
            sl=round(sl, 8) if sl_valid else 0.0,
            tp=round(tp, 8) if sl_valid else 0.0,
            order_type=order_type, entry_tf=entry_tf,
            reasons=reasons, gates_failed=gates_failed,
            structure_event={
                "kind": candidate.structure_event.kind.value,
                "direction": candidate.structure_event.direction.value,
                "level": candidate.structure_event.level,
                "time": candidate.structure_event.time,
            },
            thesis={
                "method": "smc_scalp_pullback",
                "structure_shift": candidate.structure_event.kind.value,
                "impulse_start": candidate.impulse_start,
                "impulse_end": candidate.impulse_end,
                "retracement": candidate.retracement,
                "ote_price": candidate.ote_price,
                "invalidation_level": candidate.protective_level,
                "rr": round(rr, 2),
            },
        )
        setups.append(setup)

    return setups
