"""Higher-timeframe context: directional bias for the confluence engine.

Bias rules (SMC-based, no indicators):

* The bias of a timeframe is the trend of its confirmed structure, refined by
  the last confirmed structure event (BOS reinforces, CHoCH/MSS flips).
* HTF bias is BULLISH when the highest configured timeframe is bullish and no
  lower HTF is confirmed-bearish; mirrored for bearish; NEUTRAL otherwise.
* The engine Vetoes trades against a confirmed opposing HTF bias when
  ``require_htf_alignment`` is on.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence

from ..constants import Direction, StructureEventKind, Trend
from ..strategy.structure import StructureEvent, analyze_structure
from ..market.candles import Candle


@dataclass
class TFContext:
    timeframe: str
    trend: Trend
    last_event: Optional[StructureEvent] = None
    protected_low: Optional[float] = None
    protected_high: Optional[float] = None

    def effective_direction(self) -> Trend:
        """Structure trend refined by the most recent confirmed event."""
        ev = self.last_event
        if not ev:
            return self.trend
        if ev.kind is StructureEventKind.BOS:
            # Continuation: event direction agrees with trend (or refines it).
            return Trend.BULLISH if ev.direction is Direction.LONG else Trend.BEARISH
        if ev.kind in (StructureEventKind.CHOCH, StructureEventKind.MSS):
            return Trend.BULLISH if ev.direction is Direction.LONG else Trend.BEARISH
        return self.trend


@dataclass
class HTFContext:
    frames: List[TFContext] = field(default_factory=list)
    bias: Trend = Trend.NEUTRAL
    details: Dict[str, str] = field(default_factory=dict)

    def allows(self, direction: Direction) -> bool:
        if self.bias is Trend.NEUTRAL:
            return True
        return self.bias.matches(direction)


def _frame_context(candles: Sequence[Candle], timeframe: str, strength: int,
                   atr_period: int, mss_mult: float) -> TFContext:
    a = analyze_structure(candles, strength=strength, atr_period=atr_period,
                          mss_body_atr_mult=mss_mult)
    ctx = TFContext(
        timeframe=timeframe,
        trend=a.trend,
        last_event=a.last_event,
        protected_low=a.protected_low,
        protected_high=a.protected_high,
    )
    return ctx


def build_htf_context(data_by_tf: Dict[str, List[Candle]], timeframes: List[str],
                      swing_strength: int = 2, atr_period: int = 14,
                      mss_body_atr_mult: float = 0.5,
                      require_alignment: bool = True) -> HTFContext:
    """`data_by_tf` maps timeframe -> candles (highest first in `timeframes`)."""
    ctx = HTFContext()
    directions: List[Trend] = []
    for tf in timeframes:
        candles = data_by_tf.get(tf) or []
        frame = _frame_context(candles, tf, swing_strength, atr_period, mss_body_atr_mult)
        ctx.frames.append(frame)
        eff = frame.effective_direction()
        directions.append(eff)
        ctx.details[tf] = f"{frame.trend.value}/event:{eff.value}"
        ctx.bias = eff  # start with highest tf

    # Alignment check: any confirmed opposite direction among HTFs -> neutral
    # (conflict = no trade, conservative default).
    if require_alignment and directions:
        bull = any(d is Trend.BULLISH for d in directions)
        bear = any(d is Trend.BEARISH for d in directions)
        if bull and bear:
            ctx.bias = Trend.NEUTRAL
        elif bull:
            ctx.bias = Trend.BULLISH
        elif bear:
            ctx.bias = Trend.BEARISH
        else:
            ctx.bias = Trend.NEUTRAL
    return ctx
