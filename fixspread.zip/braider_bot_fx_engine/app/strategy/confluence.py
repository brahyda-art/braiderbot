"""Confluence decision engine (spec sections 12, 15).

This module is where the "smarts" live.  A setup is NEVER created because a
single concept is present.  Every candidate must pass MANDATORY GATES first
(any failure = no trade), and must then accumulate a weighted confluence
score >= ``min_confluence_score``.

Mandatory gates (configurable on/off where safe):
  G1  HTF bias does not oppose the setup direction
  G2  price interacts with an active demand/supply zone, S/R level or
      previous-day level (a *reason* for price to turn here)
  G3  entry-timeframe confirmation: pullback + confirmation candle and/or
      confirmed structure event in setup direction
  G4  a technically valid stop-loss location exists beyond structure
  G5  reward:risk >= min_rr
  G6  risk engine pre-checks pass (handled in the pipeline, not here)
  G7  session allowed & data fresh (pipeline)

Score components (weights from config): fresh/respected/tested zone,
liquidity sweep at the zone, structure confirmation (CHoCH/MSS or BOS),
valid pullback shape, confirmation candle, S/R confluence, trendline
confluence, previous-day level confluence.

Setups are recorded in the journal even when rejected, with the exact stage
and reason (spec section 19).
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence

from ..constants import (Decision, Direction, SetupKind, StructureEventKind,
                         Trend, ZoneKind, ZoneStatus)
from ..liquidity.sweeps import Sweep, latest_sweep
from ..market.candles import Candle
from ..strategy import pullback as pb
from ..strategy.fvg import FVG, FVGAnalysis
from ..strategy.levels import SRAnalysis
from ..strategy.structure import StructureAnalysis
from ..strategy.trendlines import Trendline
from ..zones.detector import Zone, ZoneAnalysis


@dataclass
class AnalysisBundle:
    """Everything the confluence engine needs for one symbol at one moment."""
    symbol: str
    entry_tf: str
    entry_candles: Sequence[Candle]
    htf_bias: Trend
    zones: ZoneAnalysis
    sr: SRAnalysis
    entry_structure: StructureAnalysis
    sweeps: List[Sweep]
    trendlines: List[Trendline]
    atr: float
    fvgs: List[FVG] = field(default_factory=list)
    point_size: float = 0.00001        # broker point size (from symbol specs)
    digest: Dict[str, object] = field(default_factory=dict)


@dataclass
class Setup:
    id: str
    symbol: str
    direction: Direction
    kind: SetupKind
    score: float
    entry: float
    sl: float
    tp: float
    order_type: str                     # market | buy_limit | sell_limit
    entry_tf: str
    reasons: List[str] = field(default_factory=list)
    gates_failed: List[str] = field(default_factory=list)
    zone: Optional[Dict] = None
    sweep: Optional[Dict] = None
    structure_event: Optional[Dict] = None
    thesis: Dict[str, object] = field(default_factory=dict)
    created_ms: int = 0

    def to_journal(self, decision: Decision, stage: Optional[str] = None,
                   reason: Optional[str] = None) -> Dict[str, object]:
        return {
            "id": self.id, "symbol": self.symbol, "direction": self.direction.value,
            "kind": self.kind.value, "score": round(self.score, 2),
            "entry": self.entry, "sl": self.sl, "tp": self.tp,
            "order_type": self.order_type, "decision": decision.value,
            "reject_stage": stage, "reject_reason": reason,
            "reasons": self.reasons, "gates_failed": self.gates_failed,
            "thesis": self.thesis,
        }


def _rr(entry: float, sl: float, tp: float, direction: Direction) -> float:
    risk = abs(entry - sl)
    reward = abs(tp - entry)
    if risk <= 0:
        return 0.0
    # For market entries with directional TP the RR is straightforward.
    if direction is Direction.LONG:
        return reward / risk if tp > entry else 0.0
    return reward / risk if tp < entry else 0.0


def _sl_for_long(price_area_low: float, protective_level: float,
                 buffer: float) -> float:
    """Stop goes beyond the deeper of zone low / structural low, minus buffer."""
    base = min(price_area_low, protective_level)
    return base - buffer


def _sl_for_short(price_area_high: float, protective_level: float,
                  buffer: float) -> float:
    base = max(price_area_high, protective_level)
    return base + buffer


def _zone_score(zone: Optional[Zone], w) -> float:
    """Base score by lifecycle status, scaled by the zone's departure
    quality (strength = impulse_size / ATR at creation). Previously the
    zone's strength was computed and stored but never actually used in
    scoring - a zone left by a barely-qualifying impulse and one left by a
    violent displacement scored identically. Capped so one outlier zone
    can't dominate the whole score."""
    if zone is None:
        return 0.0
    if zone.status is ZoneStatus.FRESH:
        base = w.fresh_zone
    elif zone.status is ZoneStatus.RESPECTED:
        base = w.respected_zone
    elif zone.status is ZoneStatus.TESTED:
        base = w.tested_zone
    else:
        return 0.0
    quality = min(1.4, max(0.7, 0.6 + 0.2 * zone.strength))
    return base * quality


def _fvg_score(fvg: Optional[FVG], w) -> float:
    """Fresh gaps count more than already-tested ones; larger, higher-quality
    displacement (bigger body ratio, bigger gap relative to ATR) counts more,
    capped the same way zone strength is."""
    if fvg is None:
        return 0.0
    base = w.fvg_confluence if fvg.status == "fresh" else w.fvg_confluence * 0.6
    quality = min(1.3, max(0.7, 0.5 + 0.3 * fvg.size_atr + 0.3 * fvg.displacement_body_ratio))
    return base * quality


def build_setups(bundle: AnalysisBundle, cfg) -> List[Setup]:
    """Scan both directions and return fully-constructed setups that passed
    the confluence gates.  Candidates failing gates are still returned with
    ``gates_failed`` populated so the journal records WHY nothing traded."""
    st = cfg.strategy if hasattr(cfg, "strategy") else cfg
    w = st.weights
    candles = bundle.entry_candles
    if len(candles) < 30 or bundle.atr <= 0:
        return []
    last = candles[-1]
    setups: List[Setup] = []

    # Which swing concepts may contribute at all this scan. Falls back to
    # "all enabled" for any config object that predates this field (keeps
    # old configs/tests behaving exactly as before).
    enabled = set(getattr(st, "enabled_concepts", None) or STRATEGY_CONCEPTS)
    use_sd = "supply_demand" in enabled
    use_sr = "support_resistance" in enabled
    use_fvg = "fair_value_gap" in enabled
    use_sweep = "liquidity_sweep" in enabled

    for direction in (Direction.LONG, Direction.SHORT):
        reasons: List[str] = []
        gates_failed: List[str] = []
        score = 0.0

        # ---- G1: HTF bias ------------------------------------------------
        bias_ok = (bundle.htf_bias is Trend.NEUTRAL) or bundle.htf_bias.matches(direction)
        if not bias_ok:
            gates_failed.append("htf_bias_opposes")

        # ---- interest area: zone / level / PD level -----------------------
        # Each concept below only participates - in the interest-area gate
        # AND in scoring - when the user has enabled it. A disabled concept
        # is treated as if it doesn't exist for this scan, not merely
        # down-weighted, so strategies never silently blend.
        zone = None
        price_near_zone = False
        if use_sd:
            zone_kind = ZoneKind.DEMAND if direction is Direction.LONG else ZoneKind.SUPPLY
            zone = bundle.zones.nearest_active(
                last.close, zone_kind,
                max_distance=2.0 * bundle.atr,
            )
            # Also accept a zone price recently traded INTO (interaction window).
            interaction_window = candles[-5:]
            touched_zone = zone is not None and any(
                z.contains(c.low) or z.contains(c.high)
                for z in ([zone] if zone else []) for c in interaction_window
            ) if zone else False
            price_near_zone = zone is not None and (
                zone.contains(last.close) or touched_zone or
                (zone.contains(min(c.low for c in interaction_window)) or
                 zone.contains(max(c.high for c in interaction_window)))
            )
        else:
            interaction_window = candles[-5:]

        level = None
        pd_price = None
        if use_sr:
            for lv in bundle.sr.levels:
                if abs(last.close - lv.price) <= 1.0 * bundle.atr and \
                        ((direction is Direction.LONG and lv.kind == "support") or
                         (direction is Direction.SHORT and lv.kind == "resistance")):
                    level = lv
                    break

            pd = bundle.sr.prev_day or {}
            if direction is Direction.LONG:
                for key in ("low", "open"):
                    v = pd.get(key)
                    if v and abs(last.close - v) <= 1.0 * bundle.atr:
                        pd_price = v
                        break
            else:
                for key in ("high", "open"):
                    v = pd.get(key)
                    if v and abs(last.close - v) <= 1.0 * bundle.atr:
                        pd_price = v
                        break

        has_area = price_near_zone or level is not None or pd_price is not None
        # ---- FVG as an alternative area of interest (spec: FVGs especially
        # matter for XAUUSD/BTCUSD M1/M5 scalping) -------------------------
        fvg = None
        if use_fvg and bundle.fvgs:
            fvg_kind = "bullish" if direction is Direction.LONG else "bearish"
            fvg = FVGAnalysis(gaps=list(bundle.fvgs)).nearest_active(
                last.close, fvg_kind, max_distance=1.5 * bundle.atr)
        if fvg is not None:
            has_area = True
        if not has_area:
            gates_failed.append("no_zone_or_level_interaction")

        # ---- sweep in setup direction near the area ----------------------
        sweep = None
        recent_sweep = None
        if use_sweep:
            area_price = zone.lower if (zone and direction is Direction.LONG) else \
                zone.upper if zone else (level.price if level else last.close)
            sweep = latest_sweep(
                bundle.sweeps, direction, since_time=candles[-30].time,
                near_price=area_price, max_distance_atr=2.0, atr_value=bundle.atr,
            )
            recent_sweep = latest_sweep(bundle.sweeps, direction,
                                        since_time=candles[-8].time)

        # ---- entry-TF structure confirmation -----------------------------
        struct_event = None
        if bundle.entry_structure.events:
            for ev in reversed(bundle.entry_structure.events):
                if ev.direction is direction and ev.index >= len(candles) - 12:
                    struct_event = ev
                    break
        structure_confirmed = struct_event is not None
        if not structure_confirmed:
            gates_failed.append("no_entry_structure_confirmation")

        # ---- pullback & confirmation candle ------------------------------
        pull = pb.measure_pullback(candles, direction,
                                   min_ret=st.pullback_min_retracement,
                                   max_ret=st.pullback_max_retracement)
        confirm = pb.detect_confirmation(candles, direction, st.confirmation_patterns)
        confirmation_ok = confirm.confirmed or structure_confirmed
        if not confirmation_ok:
            gates_failed.append("no_confirmation")

        # ---- scoring ------------------------------------------------------
        zs = _zone_score(zone if price_near_zone else None, w)
        if zs:
            score += zs
            reasons.append(f"zone:{zone.status.value}:{zone.kind.value}@{zone.timeframe}")
        # Liquidity evidence: "zone had a sweep", "a sweep happened near the
        # area", and "a sweep happened recently" can all describe the SAME
        # underlying event. Previously all three could add independently -
        # up to 2.2x liquidity_sweep for one sweep. Take the single best
        # piece of evidence once instead.
        liq_candidates = []
        if price_near_zone and zone and zone.liquidity_swept:
            liq_candidates.append((w.liquidity_sweep * 0.5, "zone_had_liquidity_sweep"))
        if sweep is not None:
            liq_candidates.append(
                (w.liquidity_sweep, f"liquidity_sweep@{sweep.timeframe} lvl={sweep.swept_level}"))
        elif recent_sweep is not None:
            liq_candidates.append(
                (w.liquidity_sweep * 0.7, f"recent_sweep@{recent_sweep.timeframe}"))
        if liq_candidates:
            best_liq_score, best_liq_reason = max(liq_candidates, key=lambda t: t[0])
            score += best_liq_score
            reasons.append(best_liq_reason)
        if structure_confirmed:
            if struct_event.kind is StructureEventKind.BOS:
                score += w.structure_bos
            else:
                score += w.structure_confirmation
            reasons.append(f"structure:{struct_event.kind.value}")
        # Sequence bonus: a sweep immediately followed by a same-direction
        # structure shift is a distinct, stronger signal than either fact
        # alone - "the sweep is what triggered the reversal" (spec: evaluate
        # what happens AFTER the sweep, not just that it happened).
        if sweep is not None and struct_event is not None and \
                0 <= struct_event.index - sweep.index <= st.sweep_to_shift_max_bars:
            score += w.sweep_to_shift_sequence
            reasons.append("sweep_to_shift_sequence")
        fvs = _fvg_score(fvg, w)
        if fvs:
            score += fvs
            reasons.append(f"fvg:{fvg.status}:{fvg.kind}")
        if pull.is_pullback:
            score += w.pullback_valid
            reasons.append(f"pullback:{int(pull.retracement * 100)}%")
        if confirm.confirmed:
            score += w.confirmation_candle
            reasons.append(f"confirm:{'+'.join(confirm.patterns)}")
        if level is not None:
            score += w.sr_confluence * max(0.5, level.confidence)
            reasons.append(f"sr:{level.kind}@{level.price} x{level.touches}")
        tl = bundle.trendlines[-1] if bundle.trendlines else None
        if tl is not None:
            aligned = (direction is Direction.LONG and tl.direction == "bullish") or \
                      (direction is Direction.SHORT and tl.direction == "bearish")
            near_line = abs(last.close - tl.current_value) <= 1.5 * bundle.atr
            if aligned:
                score += w.trendline_confluence
                reasons.append(f"trendline:{tl.direction}")
                if near_line:
                    reasons.append("price_at_trendline")
        if pd_price is not None:
            score += w.pd_level_confluence
            reasons.append(f"pd_level:{pd_price}")

        # ---- stop loss & target -------------------------------------------
        buffer = st.sl_buffer_atr * bundle.atr
        if direction is Direction.LONG:
            protective = None
            candidates = []
            if zone is not None:
                candidates.append(zone.lower)
            if bundle.entry_structure.protected_low:
                candidates.append(bundle.entry_structure.protected_low)
            if sweep is not None and direction is Direction.LONG:
                candidates.append(sweep.sweep_price)
            if pull.pullback_extreme:
                candidates.append(pull.pullback_extreme)
            protective = min(candidates) if candidates else None
            sl_valid = protective is not None and protective < last.close
            sl = _sl_for_long(protective, protective, buffer) if sl_valid else 0.0
        else:
            candidates = []
            if zone is not None:
                candidates.append(zone.upper)
            if bundle.entry_structure.protected_high:
                candidates.append(bundle.entry_structure.protected_high)
            if recent_sweep is not None and direction is Direction.SHORT:
                candidates.append(recent_sweep.sweep_price)
            if pull.pullback_extreme:
                candidates.append(pull.pullback_extreme)
            protective = max(candidates) if candidates else None
            sl_valid = protective is not None and protective > last.close
            sl = _sl_for_short(protective, protective, buffer) if sl_valid else 0.0

        if not sl_valid:
            gates_failed.append("no_valid_sl_location")

        # Entry / TP / RR
        entry = last.close
        order_type = "market"
        tp = 0.0
        rr = 0.0
        if sl_valid:
            risk = abs(entry - sl)
            tp = entry + st.tp_rr * risk if direction is Direction.LONG \
                else entry - st.tp_rr * risk
            rr = _rr(entry, sl, tp, direction)
            if rr < st_min_rr(cfg):
                gates_failed.append("rr_below_minimum")

        passed = (not gates_failed) and score >= st.min_confluence_score
        if passed and rr <= 0:
            gates_failed.append("invalid_rr_calculation")
            passed = False

        kind = SetupKind.SCALP_CONFIRMATION if st.mode == "scalping" else \
            SetupKind.SWEEP_REVERSAL if sweep is not None else SetupKind.TREND_PULLBACK_ZONE

        setup = Setup(
            id=f"su-{uuid.uuid4().hex[:12]}",
            symbol=bundle.symbol,
            direction=direction,
            kind=kind,
            score=score,
            entry=round(entry, 8),
            sl=round(sl, 8) if sl_valid else 0.0,
            tp=round(tp, 8) if sl_valid else 0.0,
            order_type=order_type,
            entry_tf=bundle.entry_tf,
            reasons=reasons,
            gates_failed=gates_failed,
            zone=zone.to_dict() if (zone and price_near_zone) else None,
            sweep=sweep.to_dict() if sweep else None,
            structure_event={
                "kind": struct_event.kind.value,
                "direction": struct_event.direction.value,
                "level": struct_event.level,
                "time": struct_event.time,
            } if struct_event else None,
            thesis={
                "htf_bias": bundle.htf_bias.value,
                "zone": zone.to_dict() if zone else None,
                "fvg": fvg.to_dict() if fvg else None,
                "sweep": sweep.to_dict() if sweep else (recent_sweep.to_dict() if recent_sweep else None),
                "structure": struct_event.kind.value if struct_event else None,
                "confirmation": confirm.patterns,
                "pullback": pull.retracement,
                "invalidation_level": protective,
            },
            created_ms=0,
        )
        setups.append(setup)

    # Keep at most one setup per direction, and overall prefer the strongest.
    return setups


def st_min_rr(cfg) -> float:
    risk = getattr(cfg, "risk", None)
    return getattr(risk, "min_rr", 1.5)
