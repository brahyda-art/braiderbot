"""Trendline context module.

A trendline is only meaningful when at least ``min_touches`` swing points fit
a line through two anchor swings within ``touch_tolerance_atr`` x ATR.
Bullish: ascending line through higher lows.  Bearish: descending line through
lower highs.  Trendlines are context only and never trigger a trade alone
(spec section 9).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional, Sequence

from ..market.candles import Candle, atr
from .swings import Swing


@dataclass
class Trendline:
    direction: str            # bullish | bearish
    slope: float              # price units per bar
    intercept: float
    touches: int
    first_index: int
    last_index: int
    last_touch_index: int
    current_value: float      # line value at the newest bar

    def value_at(self, index: int) -> float:
        return self.slope * index + self.intercept


@dataclass
class TrendlineAnalysis:
    lines: List[Trendline] = None  # type: ignore[assignment]

    def __post_init__(self):
        if self.lines is None:
            self.lines = []

    def nearest_active(self, price: float, candles: Sequence[Candle],
                       interaction_atr_mult: float) -> Optional[Trendline]:
        if not candles:
            return None
        a = atr(candles) or 0.0
        best = None
        best_dist = None
        for line in self.lines:
            dist = abs(price - line.current_value)
            if a > 0 and dist <= interaction_atr_mult * a:
                if best_dist is None or dist < best_dist:
                    best, best_dist = line, dist
        return best


def _fit_through(p1: Swing, p2: Swing) -> Trendline:
    slope = (p2.price - p1.price) / max(1, (p2.index - p1.index))
    intercept = p1.price - slope * p1.index
    return Trendline(
        direction="bullish" if slope > 0 else "bearish",
        slope=slope, intercept=intercept,
        touches=2, first_index=p1.index, last_index=p2.index,
        last_touch_index=p2.index,
        current_value=slope * p2.index + intercept,
    )


def find_trendlines(candles: Sequence[Candle], swings: List[Swing],
                    atr_value: float, min_touches: int = 3,
                    touch_tolerance_atr: float = 0.30,
                    max_lines: int = 4) -> List[Trendline]:
    """Fit candidate lines through swing pairs of matching direction and keep
    those with >= min_touches touches within tolerance."""
    if len(candles) < 10 or len(swings) < min_touches:
        return []
    tol = max(touch_tolerance_atr * atr_value, 1e-9)
    n = len(candles)
    candidates: List[Trendline] = []

    lows = [s for s in swings if s.kind == "low"]
    highs = [s for s in swings if s.kind == "high"]

    def try_pairs(points: List[Swing], want_dir: str) -> None:
        m = len(points)
        for i in range(m - 1):
            for j in range(i + 1, m):
                line = _fit_through(points[i], points[j])
                if line.direction != want_dir:
                    continue
                # Count touches across all swings of this kind.
                touches = 0
                last_touch = points[j].index
                for s in points:
                    if s.index < points[i].index or s.index > n - 1:
                        continue
                    line_val = line.value_at(s.index)
                    if abs(s.price - line_val) <= tol:
                        touches += 1
                        last_touch = max(last_touch, s.index)
                if touches >= min_touches:
                    line.touches = touches
                    line.last_touch_index = last_touch
                    line.current_value = line.value_at(n - 1)
                    candidates.append(line)

    try_pairs(lows, "bullish")      # ascending support through higher lows
    try_pairs(highs, "bearish")     # descending resistance through lower highs

    # Deduplicate near-identical lines, keep strongest (most touches, latest).
    candidates.sort(key=lambda l: (-l.touches, -l.last_touch_index))
    kept: List[Trendline] = []
    for line in candidates:
        if all(abs(line.current_value - k.current_value) > tol
               or line.direction != k.direction for k in kept):
            kept.append(line)
        if len(kept) >= max_lines:
            break
    return kept


def analyze_trendlines(candles: Sequence[Candle], swings: List[Swing],
                       atr_period: int = 14, min_touches: int = 3,
                       touch_tolerance_atr: float = 0.30) -> List[Trendline]:
    if not candles:
        return []
    return find_trendlines(candles, swings, atr(candles, atr_period),
                           min_touches, touch_tolerance_atr)
