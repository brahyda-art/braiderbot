"""Market structure: HH/HL/LH/LL labelling, BOS, CHoCH and MSS.

Definitions (deterministic and documented):

* Trend labels are derived from consecutive swing points of the same kind:
  a higher high (HH) means a swing high whose price exceeds the previous
  swing high; likewise HL / LH / LL.
* **BOS** (break of structure, continuation): a candle *close* beyond the
  most recent swing high in a bullish context (or swing low in bearish),
  in the direction of the prevailing trend.
* **CHoCH** (change of character): the first *close* against the prevailing
  trend - e.g. a close below the last protected higher low while the trend
  was bullish.
* **MSS** (market structure shift): a CHoCH whose breaking candle body
  closes beyond the level by at least ``mss_body_atr_mult`` x ATR - i.e. a
  confirmed, strong CHoCH rather than a marginal close.

Every event carries the level broken, the confirming candle and direction.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional, Sequence

from ..constants import Direction, StructureEventKind, Trend
from ..market.candles import Candle, atr
from .swings import Swing, find_swings


@dataclass
class StructureLabel:
    index: int
    time: int
    price: float
    kind: str            # swing kind: high | low
    label: str           # HH | HL | LH | LL | H | L


@dataclass
class StructureEvent:
    kind: StructureEventKind
    direction: Direction          # direction of the BREAK (bullish break = long sign)
    level: float
    index: int
    time: int
    close: float


@dataclass
class StructureAnalysis:
    trend: Trend = Trend.NEUTRAL
    labels: List[StructureLabel] = field(default_factory=list)
    events: List[StructureEvent] = field(default_factory=list)
    last_swing_high: Optional[Swing] = None
    last_swing_low: Optional[Swing] = None
    last_event: Optional[StructureEvent] = None
    # Last protected high/low = the swing whose break would flip structure.
    protected_low: Optional[float] = None
    protected_high: Optional[float] = None


def label_swings(swings: List[Swing]) -> List[StructureLabel]:
    labels: List[StructureLabel] = []
    prev_high: Optional[Swing] = None
    prev_low: Optional[Swing] = None
    for s in swings:
        if s.kind == "high":
            if prev_high is None:
                lab = "H"
            elif s.price > prev_high.price:
                lab = "HH"
            elif s.price < prev_high.price:
                lab = "LH"
            else:
                lab = "H"
            labels.append(StructureLabel(s.index, s.time, s.price, "high", lab))
            prev_high = s
        else:
            if prev_low is None:
                lab = "L"
            elif s.price > prev_low.price:
                lab = "HL"
            elif s.price < prev_low.price:
                lab = "LL"
            else:
                lab = "L"
            labels.append(StructureLabel(s.index, s.time, s.price, "low", lab))
            prev_low = s
    return labels


def detect_trend(labels: List[StructureLabel], min_points: int = 2) -> Trend:
    """Bullish iff the most recent swing sequence shows HH and HL dominance;
    bearish for LH/LL dominance; neutral when mixed or sparse."""
    recent = [l for l in labels if l.label in ("HH", "HL", "LH", "LL")][-4:]
    if len(recent) < min_points:
        return Trend.NEUTRAL
    bull = sum(1 for l in recent if l.label in ("HH", "HL"))
    bear = sum(1 for l in recent if l.label in ("LH", "LL"))
    if bull > bear:
        return Trend.BULLISH
    if bear > bull:
        return Trend.BEARISH
    return Trend.NEUTRAL


def _close_beyond(candle: Candle, level: float, direction: Direction) -> bool:
    return candle.close > level if direction is Direction.LONG else candle.close < level


def detect_structure_events(candles: Sequence[Candle], swings: List[Swing],
                            trend: Trend, atr_value: float,
                            mss_body_atr_mult: float = 0.5) -> List[StructureEvent]:
    """Scan candle closes against the most recent swing levels to emit BOS /
    CHoCH / MSS events.  Only *confirmed closes* count (spec: no wick breaks)."""
    events: List[StructureEvent] = []
    if len(swings) < 2 or not candles:
        return events
    swing_highs = [s for s in swings if s.kind == "high"]
    swing_lows = [s for s in swings if s.kind == "low"]

    for i, candle in enumerate(candles):
        # Track the most recent swing level formed BEFORE this candle.
        prior_highs = [s for s in swing_highs if s.index < i - 0]
        prior_lows = [s for s in swing_lows if s.index < i - 0]
        if not prior_highs or not prior_lows:
            continue
        last_high = prior_highs[-1]
        last_low = prior_lows[-1]

        # Determine the local trend just before this candle (from labels).
        # A bullish break of the last swing high:
        if _close_beyond(candle, last_high.price, Direction.LONG):
            opposing = trend is Trend.BEARISH
            # Is the broken high the most recent high? If price has already
            # broken a later high, this is just continuation of continuation.
            kind = StructureEventKind.CHOCH if opposing else StructureEventKind.BOS
            events.append(StructureEvent(
                kind, Direction.LONG, last_high.price, i, candle.time, candle.close))
        elif _close_beyond(candle, last_low.price, Direction.SHORT):
            opposing = trend is Trend.BULLISH
            kind = StructureEventKind.CHOCH if opposing else StructureEventKind.BOS
            events.append(StructureEvent(
                kind, Direction.SHORT, last_low.price, i, candle.time, candle.close))

    # Upgrade strong counter-trend CHoCH breaks to MSS.
    upgraded: List[StructureEvent] = []
    for ev in events:
        if ev.kind is StructureEventKind.CHOCH and atr_value > 0:
            body_pen = abs(ev.close - ev.level)
            if body_pen >= mss_body_atr_mult * atr_value:
                ev = StructureEvent(StructureEventKind.MSS, ev.direction, ev.level,
                                    ev.index, ev.time, ev.close)
        upgraded.append(ev)
    return upgraded


def analyze_structure(candles: Sequence[Candle], strength: int = 2,
                      atr_period: int = 14,
                      mss_body_atr_mult: float = 0.5) -> StructureAnalysis:
    res = StructureAnalysis()
    if len(candles) < strength * 2 + 3:
        return res
    swings = find_swings(candles, strength)
    res.labels = label_swings(swings)
    res.trend = detect_trend(res.labels)
    res.atr = atr(candles, atr_period)
    highs = [s for s in swings if s.kind == "high"]
    lows = [s for s in swings if s.kind == "low"]
    res.last_swing_high = highs[-1] if highs else None
    res.last_swing_low = lows[-1] if lows else None
    res.events = detect_structure_events(candles, swings, res.trend,
                                         res.atr, mss_body_atr_mult)
    res.last_event = res.events[-1] if res.events else None
    # Protected levels: the last swing that would flip the current trend.
    if res.trend is Trend.BULLISH:
        res.protected_low = res.last_swing_low.price if res.last_swing_low else None
        res.protected_high = res.last_swing_high.price if res.last_swing_high else None
    elif res.trend is Trend.BEARISH:
        res.protected_high = res.last_swing_high.price if res.last_swing_high else None
        res.protected_low = res.last_swing_low.price if res.last_swing_low else None
    else:
        res.protected_low = res.last_swing_low.price if res.last_swing_low else None
        res.protected_high = res.last_swing_high.price if res.last_swing_high else None
    return res


def latest_event_since(events: List[StructureEvent], since_time: int,
                       direction: Direction, kinds: tuple | None = None) -> Optional[StructureEvent]:
    """Most recent confirming event in `direction` after `since_time`."""
    for ev in reversed(events):
        if ev.time >= since_time and ev.direction is direction:
            if kinds is None or ev.kind in kinds:
                return ev
    return None
