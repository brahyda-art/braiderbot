"""Fractal swing-point detection (objective, documented rule).

A swing high at bar ``i`` requires its high to be strictly greater than the
``strength`` bars on the left and greater-or-equal on the right (ties resolve
to the earliest bar).  Mirror logic for swing lows.  No other bar qualifies -
this keeps the count deterministic and backtestable.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Sequence

from ..market.candles import Candle


@dataclass
class Swing:
    index: int          # index into the candle list
    time: int
    price: float
    kind: str           # "high" | "low"


def find_swings(candles: Sequence[Candle], strength: int = 2) -> List[Swing]:
    """Return swings ordered by index.  The final ``strength`` bars can never
    contain a confirmed swing (not enough right-hand bars)."""
    n = len(candles)
    if strength < 1 or n < strength * 2 + 1:
        return []
    swings: List[Swing] = []
    for i in range(strength, n - strength):
        window_high = candles[i - strength:i]
        window_right = candles[i + 1:i + 1 + strength]
        h = candles[i].high
        l = candles[i].low
        if all(h > c.high for c in window_high) and all(h >= c.high for c in window_right):
            swings.append(Swing(i, candles[i].time, h, "high"))
        if all(l < c.low for c in window_high) and all(l <= c.low for c in window_right):
            swings.append(Swing(i, candles[i].time, l, "low"))
    return swings


def last_swing_before(swings: List[Swing], index: int, kind: str) -> Swing | None:
    for s in reversed(swings):
        if s.index < index and s.kind == kind:
            return s
    return None
