"""Shared constants and enumerations for the BRAIDER BOT FX engine."""

from __future__ import annotations

from enum import Enum


# ---------------------------------------------------------------------------
# Engine / bot states (section 21 of the specification)
# ---------------------------------------------------------------------------
class BotState(str, Enum):
    STOPPED = "STOPPED"
    RUNNING = "RUNNING"
    PAUSED = "PAUSED"
    EMERGENCY_STOP = "EMERGENCY_STOP"


class EngineMode(str, Enum):
    PAPER = "paper"
    DEMO = "demo"
    LIVE = "live"


# Commands understood from the web app (`users/{uid}/commands` documents or REST API).
COMMAND_ACTIONS = ("start", "pause", "stop", "emergency", "resume", "close_all", "demo_test_order", "close_position")

# ---------------------------------------------------------------------------
# Timeframes
# ---------------------------------------------------------------------------
VALID_TIMEFRAMES = ("M1", "M5", "M15", "M30", "H1", "H4", "D1", "W1")

TIMEFRAME_MINUTES = {
    "M1": 1,
    "M5": 5,
    "M15": 15,
    "M30": 30,
    "H1": 60,
    "H4": 240,
    "D1": 1440,
    "W1": 10080,
}

# ---------------------------------------------------------------------------
# Trading sessions (UTC hours). Windows are configurable in config.yaml;
# these are only the defaults used when the config file omits them.
# ---------------------------------------------------------------------------
DEFAULT_SESSIONS = {
    "sydney": {"start": 21, "end": 6},
    "tokyo": {"start": 0, "end": 9},
    "london": {"start": 7, "end": 16},
    "newyork": {"start": 12, "end": 21},
}

# ---------------------------------------------------------------------------
# Analysis / trade-direction helpers
# ---------------------------------------------------------------------------
class Direction(str, Enum):
    LONG = "buy"
    SHORT = "sell"
    NONE = "none"

    @property
    def opposing(self) -> "Direction":
        if self is Direction.LONG:
            return Direction.SHORT
        if self is Direction.SHORT:
            return Direction.LONG
        return Direction.NONE


class Trend(str, Enum):
    BULLISH = "bullish"
    BEARISH = "bearish"
    NEUTRAL = "neutral"

    def matches(self, direction: Direction) -> bool:
        if self is Trend.BULLISH:
            return direction is Direction.LONG
        if self is Trend.BEARISH:
            return direction is Direction.SHORT
        return False


class StructureEventKind(str, Enum):
    BOS = "BOS"          # break of structure (continuation)
    CHOCH = "CHoCH"      # change of character (first counter-trend break)
    MSS = "MSS"          # market structure shift (confirmed, strong CHoCH)


class ZoneKind(str, Enum):
    DEMAND = "demand"
    SUPPLY = "supply"


class ZoneStatus(str, Enum):
    FRESH = "fresh"              # never returned to since creation
    TESTED = "tested"            # touched at least once, still intact
    RESPECTED = "respected"      # touched and produced a qualifying reaction
    INVALIDATED = "invalidated"  # candle body closed through the zone
    CONSUMED = "consumed"        # price traded far beyond the zone


class SetupKind(str, Enum):
    TREND_PULLBACK_ZONE = "trend_pullback_zone"     # HTF trend + zone + confirmation
    SWEEP_REVERSAL = "sweep_reversal"               # liquidity sweep + structure shift
    SCALP_CONFIRMATION = "scalp_confirmation"       # scalping-mode candle pullback
    STRUCTURE_BREAK_RETEST = "structure_break_retest"


class Decision(str, Enum):
    EXECUTED = "executed"
    APPROVED = "approved"
    REJECTED = "rejected"
    SKIPPED = "skipped"


class ExitReason(str, Enum):
    STOP_LOSS = "stop_loss"
    TAKE_PROFIT = "take_profit"
    EMERGENCY_CLOSE = "emergency_close"
    RISK_SHUTDOWN = "risk_shutdown"
    THESIS_INVALIDATED = "thesis_invalidated"
    STRUCTURAL_EARLY_EXIT = "structural_early_exit"
    PARTIAL_TAKE_PROFIT = "partial_take_profit"
    BREAK_EVEN = "break_even"
    TRAIL_STOP = "trail_stop"
    MANUAL = "manual"
    PENDING_EXPIRED = "pending_expired"
    PENDING_INVALIDATED = "pending_invalidated"
    END_OF_BACKTEST = "end_of_backtest"


class ManagementSignal(str, Enum):
    """Severity ladder for early-exit evaluation (spec section 35)."""
    NONE = "none"
    WARNING = "warning"
    DETERIORATED = "deteriorated"
    INVALIDATED = "invalidated"


# SQLite file names
DB_MAIN = "braider.db"

# Engine magic number default (configurable via config.yaml / env)
DEFAULT_MAGIC = 777001
