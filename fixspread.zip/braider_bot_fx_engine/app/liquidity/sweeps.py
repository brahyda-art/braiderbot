"""Liquidity sweep detection (spec section 10).

A sweep is NOT every wick.  Rule (all measurable):

1. A reference liquidity level exists: a prior swing low/high, or an
   equal-highs / equal-lows pool (>= 2 swings within ``pool_tolerance_atr``
   x ATR of each other).
2. A later candle penetrates the level by at least ``min_penetration_atr``
   x ATR (excess = wick beyond the level).
3. The same candle CLOSES back on the original side of the level, or the
   next candle does (close-back confirmation).
4. Optionally the sweep must occur near a supply/demand zone to count as
   zone-associated (handled by the confluence engine, not here).

Sweeping sell-side liquidity (lows) with a close back above is a BULLISH
signal; sweeping buy-side liquidity (highs) is BEARISH.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence

from ..constants import Direction
from ..market.candles import Candle, atr
from ..strategy.swings import Swing


@dataclass
class Sweep:
    swept_level: float
    sweep_price: float          # extreme reached during the sweep
    direction: Direction        # signal direction (sweep of lows => bullish)
    timeframe: str
    index: int
    time: int                   # confirmation candle time
    penetration: float
    pool_size: int              # number of swings in the swept pool
    is_pool: bool

    def to_dict(self) -> Dict:
        return {
            "level": self.swept_level, "extreme": self.sweep_price,
            "direction": self.direction.value, "timeframe": self.timeframe,
            "time": self.time, "penetration": round(self.penetration, 8),
            "pool": self.pool_size,
        }


def _pools(swings: List[Swing], kind: str, atr_value: float,
           tolerance_atr: float) -> List[tuple]:
    """Equal-high/low pools: consecutive swings of same kind within tolerance."""
    tol = tolerance_atr * atr_value if atr_value > 0 else 0.0
    same = [s for s in swings if s.kind == kind]
    pools: List[tuple] = []
    i = 0
    while i < len(same):
        j = i
        group = [same[i]]
        while j + 1 < len(same) and abs(same[j + 1].price - group[-1].price) <= max(tol, 1e-12):
            j += 1
            group.append(same[j])
        if len(group) >= 2:
            pools.append((sum(s.price for s in group) / len(group), len(group)))
            i = j + 1
        else:
            i += 1
    return pools


def detect_sweeps(candles: Sequence[Candle], swings: List[Swing], timeframe: str,
                  min_penetration_atr: float = 0.10,
                  pool_tolerance_atr: float = 0.10,
                  atr_period: int = 14) -> List[Sweep]:
    if len(candles) < 5 or len(swings) < 2:
        return []
    atr_value = atr(candles, atr_period)
    min_pen = min_penetration_atr * atr_value if atr_value > 0 else 0.0
    sweeps: List[Sweep] = []

    # Reference levels from swings formed before each candle.
    swing_lows = [s for s in swings if s.kind == "low"]
    swing_highs = [s for s in swings if s.kind == "high"]
    low_pools = _pools(swings, "low", atr_value, pool_tolerance_atr)
    high_pools = _pools(swings, "high", atr_value, pool_tolerance_atr)

    for i in range(1, len(candles)):
        c = candles[i]
        prior_lows = [s for s in swing_lows if s.index < i]
        prior_highs = [s for s in swing_highs if s.index < i]

        # ---- sell-side liquidity (lows) swept => bullish signal
        best_low = None
        for s in prior_lows[-8:]:
            pen = s.price - c.low
            if pen > min_pen:
                if best_low is None or s.price > best_low[0].price:
                    best_low = (s, pen)
        if best_low is not None and c.close > best_low[0].price:
            close_back = True
            if not close_back and i + 1 < len(candles):
                close_back = candles[i + 1].close > best_low[0].price
            if close_back:
                pool = next(((lvl, n) for lvl, n in low_pools
                             if abs(lvl - best_low[0].price) <= max(min_pen, 1e-12)), None)
                sweeps.append(Sweep(
                    swept_level=best_low[0].price,
                    sweep_price=c.low,
                    direction=Direction.LONG,
                    timeframe=timeframe,
                    index=i, time=c.time,
                    penetration=best_low[1],
                    pool_size=pool[1] if pool else 1,
                    is_pool=pool is not None,
                ))

        # ---- buy-side liquidity (highs) swept => bearish signal
        best_high = None
        for s in prior_highs[-8:]:
            pen = c.high - s.price
            if pen > min_pen:
                if best_high is None or s.price < best_high[0].price:
                    best_high = (s, pen)
        if best_high is not None and c.close < best_high[0].price:
            pool = next(((lvl, n) for lvl, n in high_pools
                         if abs(lvl - best_high[0].price) <= max(min_pen, 1e-12)), None)
            sweeps.append(Sweep(
                swept_level=best_high[0].price,
                sweep_price=c.high,
                direction=Direction.SHORT,
                timeframe=timeframe,
                index=i, time=c.time,
                penetration=best_high[1],
                pool_size=pool[1] if pool else 1,
                is_pool=pool is not None,
            ))

    return sweeps


def latest_sweep(sweeps: List[Sweep], direction: Direction,
                 since_time: int, near_price: float | None = None,
                 max_distance_atr: float | None = None,
                 atr_value: float | None = None) -> Optional[Sweep]:
    """Most recent sweep in `direction` after `since_time`, optionally near a
    zone/level price (within max_distance_atr x ATR)."""
    best = None
    for s in sweeps:
        if s.direction is not direction or s.time < since_time:
            continue
        if near_price is not None and atr_value and max_distance_atr:
            if abs(s.swept_level - near_price) > max_distance_atr * atr_value:
                continue
        if best is None or s.time > best.time:
            best = s
    return best
